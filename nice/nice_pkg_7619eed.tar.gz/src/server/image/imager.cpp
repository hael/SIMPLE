#include <imager.h>

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

std::vector<unsigned char> JpegBuffer;
std::mutex JpegBufferLock;

Imager::Imager (std::string thumbnail_uid) {
    this->type          = FAILED;
    pqxx::result thumbnail = sql_nontx_result(std::string_view{"SELECT blob FROM thumbnails WHERE uid='" + thumbnail_uid + "';"});

    if(thumbnail.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retreive thumbnail from database");
        return;
    }

    if(thumbnail[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - thumbnail blob is null");
        return;
    }

    std::basic_string<std::byte> blob = thumbnail[0][0].as<std::basic_string<std::byte>>();

    this->binary_data = new char[blob.length()];
    this->datalength = blob.length();
    memcpy(this->binary_data, blob.data(), blob.length());
    this->thumbnail_uid = thumbnail_uid;
    this->type          = THUMBNAIL_JPEG;
}

Imager::Imager (int i, std::string path, std::string boxfile) {
    this->type = FAILED;

    if(!fileExists(path)){
        if(i == 0){}
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image path does not exist " + path);
        return;
    }

    if(extension(path) == ".mrc"){
       MRCFileHeader* header = new MRCFileHeader();
       if(MRCReadHeader(path, header)){
            // will only read 1st in stack (ie micrograph)
            int datalength = header->nx * header->ny;
            float* data = new float[datalength];
            if(MRCReadData(path, header, 0, data)){
                unsigned char* pixels = new unsigned char[datalength];
                nlohmann::ordered_json jpeg_comment;
                if(this->maxMinNormalize2Char(datalength, data, pixels)){
                    if(boxfile != "" && fileExists(boxfile)){
                        int box_idxs[5] = {0,1,2,3,5};
                        nlohmann::json boxes = readBoxFileInt(boxfile, box_idxs, 5);
                        jpeg_comment["boxes"] = {};
                        jpeg_comment["boxes"]["manual"] = {};
        
                        nlohmann::ordered_json manual;

                        for (nlohmann::ordered_json boxit : boxes["boxes"]){
                            jpeg_comment["boxes"]["manual"].push_back(boxit);
                        }
                    }

                    JpegBufferLock.lock();
                    JpegBuffer.clear();
                    int ok = TooJpeg::writeJpeg(this->AppendJpegByte, pixels, header->nx, header->ny, false, 90, false, "");
                    this->binary_data = new char[JpegBuffer.size()];
                    this->datalength = JpegBuffer.size();
                    memcpy(this->binary_data, JpegBuffer.data(), JpegBuffer.size());
                    this->type = THUMBNAIL_JPEG;
                    JpegBuffer.clear();
                    JpegBufferLock.unlock();

                    if(jpeg_comment.empty()){
                        JpegBufferLock.lock();
                        JpegBuffer.clear();
                        int ok = TooJpeg::writeJpeg(this->AppendJpegByte, pixels, header->nx, header->ny, false, 90, false, "");
                        this->binary_data = new char[JpegBuffer.size()];
                        this->datalength = JpegBuffer.size();
                        memcpy(this->binary_data, JpegBuffer.data(), JpegBuffer.size());
                        this->type = THUMBNAIL_JPEG;
                        JpegBuffer.clear();
                        JpegBufferLock.unlock();
                    }else{
                        std::basic_string<std::byte> blob;
                        JpegBufferLock.lock();
                        JpegBuffer.clear();
                        int ok = TooJpeg::writeJpeg(this->AppendJpegByte, pixels, header->nx, header->ny, false, 90, false, "");
                        blob.resize(JpegBuffer.size());
                        memcpy(blob.data(), JpegBuffer.data(), JpegBuffer.size());
                        JpegBuffer.clear();
                        JpegBufferLock.unlock();
                        std::string com_json = jpeg_comment.dump(0);
                        std::vector<std::uint8_t> msgpack = nlohmann::ordered_json::to_msgpack(jpeg_comment);

                        // insert json string into com section of jpeg
                        if(blob[0] == std::byte{0xff} && blob[1] == std::byte{0xd8} && blob[2] == std::byte{0xff} && blob[3] == std::byte{0xe0}){
                            unsigned short app0_len = Decode16((unsigned char*) &blob[4]);
                            int read_from = 4 + app0_len;
                            int insert_at = read_from;
                            //
                            int section_max = UINT16_MAX - 2;
                            int napp = (int) std::ceil((float) msgpack.size() / (float) section_max);
                            //app1 section
                            JPEG_App1_Section app1_section;
                            app1_section.app         = be_word(0xffe1);
                            app1_section.app_len     = be_word(sizeof(app1_section) - 2);
                            app1_section.napp        = napp;
                            app1_section.payload_len = msgpack.size();
                            // create output blob
                            this->datalength = blob.length() + sizeof(app1_section) + (napp * 4) + msgpack.size();
                            this->binary_data = new char[this->datalength];
                            // write 1st part of header
                            memcpy(&this->binary_data[0], blob.data(), read_from);
                            // write app1
                            memcpy(&this->binary_data[insert_at], (void*)&app1_section, sizeof(app1_section));
                            insert_at = insert_at + sizeof(app1_section);
                            // write napp app sections
                            for(int i = 0; i < napp; i++){
                                int msgpack_start = i * section_max;
                                uint16_t appn_length;
                                if(i == napp - 1){
                                    appn_length = msgpack.size() - msgpack_start;
                                }else{
                                    appn_length = section_max;
                                }
                                JPEG_Section_Header appn_header;
                                if(i == 0){
                                    appn_header.com = be_word(0xffe2);
                                }else if(i == 1){
                                    appn_header.com = be_word(0xffe3);
                                }else if(i == 2){
                                    appn_header.com = be_word(0xffe4);
                                }else if(i == 3){
                                    appn_header.com = be_word(0xffe5);
                                }else if(i == 4){
                                    appn_header.com = be_word(0xffe6);
                                }else if(i == 5){
                                    appn_header.com = be_word(0xffe7);
                                }else if(i == 6){
                                    appn_header.com = be_word(0xffe8);
                                }else if(i == 7){
                                    appn_header.com = be_word(0xffe9);
                                }
                                appn_header.com_len = be_word(appn_length + 2);
                                memcpy(&this->binary_data[insert_at], (void*)&appn_header, sizeof(appn_header));
                                memcpy(&this->binary_data[insert_at + sizeof(appn_header)], &msgpack[msgpack_start], appn_length);
                                insert_at = insert_at + appn_length + sizeof(appn_header);
                            }
                            // insert rest of blob
                            memcpy(&this->binary_data[insert_at], &blob.data()[read_from], blob.length() - read_from);
                            this->type = THUMBNAIL_JPEG;
                            }
                        blob.clear();
                    }
                }
                delete [] pixels;
            }
            delete [] data;
       }
       delete header;
    }else{
        // get and check file size
        std::uintmax_t file_size = fileSize(path);
        if(file_size == 0){
            spdlog::get("Core")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file has zero size");
            return;
        }

        // declare blob
        std::basic_string<std::byte> blob;
        blob.resize(file_size);
        // read binary image
        std::ifstream image_file;
        image_file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
        try{
            image_file.open(path, std::ios_base::binary);
            image_file.read(reinterpret_cast<char*>(blob.data()), file_size);
            image_file.close();
        }catch (std::ifstream::failure e) {
            spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fstream failure to open image file");
            return;
        }

        this->binary_data = new char[blob.length()];
        this->datalength = blob.length();
        memcpy(this->binary_data, blob.data(), blob.length());
        if(i == 1){
            this->type = THUMBNAIL_JPEG;
        }else if(i == 2){
            this->type = BINARY;
        }
   }
    
}

bool Imager::maxMinNormalize2Char(int datalength, float* data, unsigned char* pixels){
    
    float   normal;
    float   pixelrange;
    
    float max = *std::max_element(data , data + datalength);
    float min = *std::min_element(data , data + datalength);
    pixelrange = (max - min) / 256;
    
    #pragma omp parallel num_threads(4)
    {
        #pragma omp for
        for(int i = 0; i < datalength; i++){
            normal = (data[i] - min) / pixelrange;
            if (normal > 255){
                pixels[i] = 255;
            }else if(normal < 0){
                pixels[i] = 0;
            }else{
                pixels[i] = floor(normal);
            }
        }
    }
    
    return true;
}

void Imager::AppendJpegByte(unsigned char byte) {
    JpegBuffer.push_back(byte);

}
#include "imager.hpp"

Imager::Imager(Core* core){
	this->core = core;
	this->core->logInfo("initialising imager instance");
	this->core->logInfo("imager instance initialisation complete");
}

Imager::~Imager(){
	this->core->logInfo("destroying imager instance");
	
	if(this->fh.is_open()){
		this->fh.close();
	}

	if(this->data && this->datatype != ""){
		if(this->datatype == "uchar"){
			unsigned char* data = (unsigned char*) this->data;
			delete [] data;
		}else if(this->datatype == "float"){
			float* data = (float*) this->data;
			delete [] data;
		}else{
			this->core->logError("Imager::destructor : unhandled data type");
		}
		
	}

	this->core->logInfo("imager instance destruction complete");
}

bool Imager::open(){

	if(!fileExists(this->path)){
		this->core->logError("Imager::open : file does not exist");
		return false;
	}

	this->fh.open(this->path, std::ios::binary);

	return(this->fh.is_open());
}

bool Imager::read(std::string filename, int targetheight, int stkindex, int xsprite, int nxsprite){

	if(!fileExists(filename)){
		this->core->logError("Imager::read : file does not exist");
		return false;
	}

	this->path = filename;
	this->stkindex = stkindex;
	this->xsprite = xsprite;
	this->nxsprite = nxsprite;

	if(!this->open()){
		this->core->logError("Imager::read : failed to open file");
		return false;
	}

	std::string imgextension = extension(filename);

	if(imgextension == ".mrc" || imgextension == ".mrcs"){

		this->type = "mrc";

		if(!readMRCHeader()){
			this->core->logError("Imager::read : failed to read MRC header");
			return false;
		}

		if(!readMRCData()){
			this->core->logError("Imager::read : failed to read MRC data");
			return false;
		}

	
	} else if(imgextension == ".jpg" || imgextension == ".jpeg"){

		this->type = "jpg";

		if(!readJPGHeader()){
			this->core->logError("Imager::read : failed to read JPG header");
			return false;
		}

		if(!readJPGData()){
			this->core->logError("Imager::read : failed to read JPG data");
			return false;
		}
	}else{
		this->core->logError("Imager::read : unsupported extension " + imgextension);
		return false;
	}

	this->targetheight = targetheight;

	return true;
}

bool Imager::readMRCHeader(){
	
	MRCFileHeader* header = new MRCFileHeader();
	
	if(!this->fh.is_open()){
		this->core->logError("Imager::readMRCHeader : file is not open");
		return false;
	}

	if(!this->fh.read((char*)header, 1024)){
		this->core->logError("Imager::readMRCHeader : failed to read header");
		return false;
	}
	
	this->header = header;
	this->sourcenx = header->nx;
	this->sourceny = header->ny;
	
	return true;
}

bool Imager::readJPGHeader(){
	
	JPEGFileHeader* header = new JPEGFileHeader();
	unsigned char* buffer;
	
	if(!this->fh.is_open()){
		this->core->logError("Imager::readJPGHeader : file is not open");
		return false;
	}

	this->fh.seekg (0, std::ios::end);	
	int buffersize = this->fh.tellg();
	this->fh.seekg (0, std::ios::beg);

	buffer = new unsigned char[buffersize];

	if(!this->fh.read((char*)buffer, buffersize)){
		this->core->logError("Imager::readJPGHeader : failed to read header");
		delete [] buffer;
		return false;
	}

	Jpeg::Decoder decoder(buffer, buffersize);

	if (decoder.GetResult() != Jpeg::Decoder::OK){
       this->core->logError("Imager::readJPGHeader : failed to read header");
		delete [] buffer;
		return false;
	}

	header->nx = decoder.GetWidth();
	header->ny = decoder.GetHeight();

	this->header = header;
	this->sourcenx = header->nx;
	this->sourceny = header->ny;
	this->datalength = decoder.GetImageSize();

	unsigned char* data = new unsigned char[this->datalength];
	memcpy (data, decoder.GetImage(), this->datalength);

	this->data = data;
	this->datatype = "uchar";

	delete [] buffer;

	return true;
}

bool Imager::readMRCData(){
	
	MRCFileHeader* header = (MRCFileHeader*) this->header;
	int	datalength;
	
	if(header->mode == 2){
		this->datalength = header->nx * header->ny;
		float* data = new float[this->datalength];
		datalength = this->datalength * 4;
		this->fh.seekg (1024 + header->nsymbt + (datalength * this->stkindex), std::ios::beg); //should be frame not 0
		this->fh.read ((char*)data, datalength);
		this->data = data;
		this->datatype = "float";
	}

	return true;
}

bool Imager::readJPGData(){

	JPEGFileHeader* header = (JPEGFileHeader*) this->header;
	unsigned char* data = (unsigned char*) this->data;
	// read handled in read header
	if(this->nxsprite > 1 || this->nysprite > 1){

		int spritenx   = std::floor(header->nx / this->nxsprite);
		int spriteny   = std::floor(header->ny / this->nysprite);

		int spriteoffx = spritenx * this->xsprite;
		int spriteoffy = spriteny * this->ysprite;

		unsigned char* spritedata = new unsigned char[spritenx * spriteny * 3];

		for(int x = 0; x < spritenx; x++){
			for(int y = 0; y < spriteny; y++){
				int orix = x + spriteoffx;
				int oriy = y + spriteoffy;
				int datapos = 3 * (orix + (oriy * header->nx));
				int spritepos = 3 * (x + (y * spritenx));
		
				spritedata[spritepos] = data[datapos];
				spritedata[spritepos + 1] = data[datapos + 1];
				spritedata[spritepos + 2] = data[datapos + 2];
			}
		}

		delete [] data;
		this->data = spritedata;
		this->datalength = spritenx * spriteny * 3;
		header->nx = spritenx;
		header->ny = spriteny;
	}

	return true;
}

bool Imager::maxMinNormalize(){

	if(this->type == "mrc"){
		if(!this->maxMinNormalizeMRC()){
			this->core->logError("Imager::maxMinNormalize : failed to normalise mrc data");
			return false;
		}
	}else if(this->type == "jpg"){
		if(!this->maxMinNormalizeJPG()){
			this->core->logError("Imager::maxMinNormalize : failed to normalise jpg data");
			return false;
		}
	}

	return true;
}

bool Imager::maxMinNormalizeMRC(){
	
	MRCFileHeader *header = (MRCFileHeader*) this->header;
	float* data = (float*) this->data;
	
	float	normal;
	float 	pixelrange;
	unsigned char* pixels;
	
	pixels = new unsigned char[this->datalength];
	this->max = *std::max_element(data , data + this->datalength);
	this->min = *std::min_element(data , data + this->datalength);
	pixelrange = (this->max - this->min) / 256;
	
	this->mean = 0;
	
	#pragma omp parallel num_threads(4)
	{
		#pragma omp for
		for(int i = 0; i < this->datalength; i++){
			normal = (data[i] - this->min) / pixelrange;
			if (normal > 255){
				pixels[i] = 255;
			}else if(normal < 0){
				pixels[i] = 0;
			}else{
				pixels[i] = floor(normal);
			}
			this->mean += pixels[i];
		}
	}
	
	this->mean /= this->datalength;
	
	this->sd = 0;

	#pragma omp parallel num_threads(4)
	{
		#pragma omp for
		for(int i = 0; i < this->datalength; i++){
			this->sd += pow(pixels[i] - this->mean, 2);
		}
	}
	
	this->sd = sqrt(this->sd / this->datalength);
	
	delete [] data;
	this->data = pixels;
	this->datatype = "uchar";

	return true;
}

bool Imager::maxMinNormalizeJPG(){
	//assumed already normalised

	JPEGFileHeader *header = (JPEGFileHeader*) this->header;
	unsigned char* data = (unsigned char*) this->data;
	
	this->mean = 0;
	
	#pragma omp parallel num_threads(4)
	{
		#pragma omp for
		for(int i = 0; i < this->datalength; i++){
			this->mean += data[i];
		}
	}
	
	this->mean /= this->datalength;
	
	this->sd = 0;
	
	#pragma omp parallel num_threads(4)
	{
		#pragma omp for
		for(int i = 0; i < this->datalength; i++){
			this->sd += pow(data[i] - this->mean, 2);
		}
	}
	
	this->sd = sqrt(this->sd / this->datalength);
	
	return true;
}

bool Imager::reduceSize(){

	if(this->targetheight == 0) return true; //Native sampling

	if(this->type == "mrc"){
		if(!this->reduceSizeMRC()){
			this->core->logError("Imager::reduceSize : failed to resize mrc data");
			return false;
		}
	}else if(this->type == "jpg"){
		if(!this->reduceSizeJPG()){
			this->core->logError("Imager::reduceSize : failed to resize jpg data");
			return false;
		}
	}

	return true;
}

bool Imager::reduceSizeMRC(){

	MRCFileHeader *header = (MRCFileHeader*) this->header;

	int nextsizex = std::floor(header->nx/2);
	int nextsizey = std::floor(header->ny/2);
	int nextsizez = std::floor(header->nz/2);
	
	while(nextsizey >= this->targetheight){
		
		this->core->logInfo("Resampling image from " + std::to_string(header->nx) + "x" + std::to_string(header->ny)+ " to " + std::to_string(nextsizex) + "x" + std::to_string(nextsizey));
		
		float* data = (float*) this->data;
		float* datareduced = new float[nextsizex * nextsizey];
		
		for ( int y = 0; y < nextsizey ; y++ ) {
			for ( int x = 0; x < nextsizex ; x++ ) {
				
				// index of pixel in reduced image
				int newindex = x + y*nextsizex;
				
				// indices of pixels in original
				int index1 = (2*x) + (2*y*header->nx);
				int index2 = index1 + 1;
				int index3 = index1 + header->nx;
				int index4 = index1 + 1 + header->nx;
				
				if(index1 < this->datalength && index2 < this->datalength && index3 < this->datalength && index4 < this->datalength){
					float newpixelvalue = data[index1] + data[index2] + data[index3] + data[index4];
					datareduced[newindex] = newpixelvalue / 4;
				}
			}
		}

		header->nx = nextsizex;
		header->ny = nextsizey;
		header->nz = nextsizez;
				
		delete [] data;
		
		this->data = datareduced;
		this->datalength = nextsizex * nextsizey;
		nextsizex = std::floor(nextsizex/2);
		nextsizey = std::floor(nextsizey/2);
	}
	
	return true;
}

bool Imager::reduceSizeJPG(){

	JPEGFileHeader* header = (JPEGFileHeader*) this->header;

	int nextsizex = std::floor(header->nx/2);
	int nextsizey = std::floor(header->ny/2);
	
	while(nextsizey >= this->targetheight){
		
		this->core->logInfo("Resampling image from " + std::to_string(header->nx) + "x" + std::to_string(header->ny)+ " to " + std::to_string(nextsizex) + "x" + std::to_string(nextsizey));
		
		unsigned char* data = (unsigned char*) this->data;
		unsigned char* datareduced = new unsigned char[nextsizex * nextsizey * 3];
		
		for ( int y = 0; y < nextsizey ; y++ ) {
			for ( int x = 0; x < nextsizex ; x++ ) {
				
				// index of pixel in reduced image
				int newindex = (x + y*nextsizex) * 3;
				
				
				// indices of pixels in original
				int index1 = (2*x*3) + (2*y*header->nx*3);
				int index2 = index1 + 3;
				int index3 = index1 + (header->nx * 3);
				int index4 = index1 + 3 + (header->nx * 3);
				
				int index5 = (2*x*3) + (2*y*header->nx*3) + 1;
				int index6 = index5 + 3;
				int index7 = index5 + (header->nx * 3);
				int index8 = index5 + 3 + (header->nx * 3);
				
				int index9 = (2*x*3) + (2*y*header->nx*3) + 2;
				int index10 = index9 + 3;
				int index11 = index9 + (header->nx * 3);
				int index12 = index9 + 3 + (header->nx * 3);
				
				float newpixelvalueR = (data[index1] + data[index2] + data[index3] + data[index4]) / 4;
				float newpixelvalueG = (data[index5] + data[index6] + data[index7] + data[index8]) / 4;
				float newpixelvalueB = (data[index9] + data[index10] + data[index11] + data[index12]) / 4;
		
				if(newpixelvalueR > 255){
					datareduced[newindex] = 255;
				}else if(newpixelvalueR < 0){
					datareduced[newindex] = 0;
				}else{
					datareduced[newindex] = std::floor(newpixelvalueR);
				}

				if(newpixelvalueG > 255){
					datareduced[newindex + 1] = 255;
				}else if(newpixelvalueG < 0){
					datareduced[newindex + 1] = 0;
				}else{
					datareduced[newindex + 1] = std::floor(newpixelvalueG);
				}

				if(newpixelvalueB > 255){
					datareduced[newindex + 2] = 255;
				}else if(newpixelvalueB < 0){
					datareduced[newindex + 2] = 0;
				}else{
					datareduced[newindex + 2] = std::floor(newpixelvalueB);
				}

			}
		}

		header->nx = nextsizex;
		header->ny = nextsizey;
				
		delete [] data;
		
		this->data = datareduced;
		this->datalength = nextsizex * nextsizey * 3;
		nextsizex = std::floor(nextsizex/2);
		nextsizey = std::floor(nextsizey/2);
	}

	return true;
}

nlohmann::ordered_json Imager::pack(){

	nlohmann::ordered_json returnjson;

	if(this->type == "mrc"){
		
		MRCFileHeader *header = (MRCFileHeader*) this->header;

		returnjson["nx"] = header->nx;
		returnjson["ny"] = header->ny;
		returnjson["sourcenx"] = this->sourcenx;
		returnjson["sourceny"] = this->sourceny;
		returnjson["apix"] = header->cellx / header->nx;
		returnjson["type"] = "raw";
		returnjson["targetheight"] = this->targetheight;
		returnjson["mean"] = this->mean;
		returnjson["sd"] = this->sd;
		returnjson["data"] = nlohmann::ordered_json::binary(this->packMRCData());

	}else if(this->type == "jpg"){
		
		JPEGFileHeader *header = (JPEGFileHeader*) this->header;

		returnjson["nx"] = header->nx;
		returnjson["ny"] = header->ny;
		returnjson["sourcenx"] = this->sourcenx;
		returnjson["sourceny"] = this->sourceny;
		returnjson["type"] = "rgb";
		returnjson["targetheight"] = this->targetheight;
		returnjson["mean"] = this->mean;
		returnjson["sd"] = this->sd;
		returnjson["data"] = nlohmann::ordered_json::binary(this->packJPGData());

	}

	return returnjson;
	
}

std::vector<uint8_t> Imager::packMRCData(){

	MRCFileHeader *header = (MRCFileHeader*) this->header;
	unsigned char* pixels = (unsigned char*) this->data;

	std::vector<uint8_t> image(this->datalength);
	memcpy(&image[0], pixels, this->datalength);
  
	delete [] pixels;

	this->data = NULL;
	this->datatype = "";

	return image;

}

std::vector<uint8_t> Imager::packJPGData(){

	JPEGFileHeader *header = (JPEGFileHeader*) this->header;
	unsigned char* pixels = (unsigned char*) this->data;

	std::vector<uint8_t> image(this->datalength);
	memcpy(&image[0], pixels, this->datalength);
  
	delete [] pixels;

	this->data = NULL;
	this->datatype = "";

	return image;

}
#ifndef TSQUEUE
#define TSQUEUE

#include <mutex>
#include <queue>

// Thread-safe queue
template <typename T>
class TSQueue {
	private:
	    std::queue<T> m_queue;
	    std::mutex m_mutex;

	public:
	    void push(T item){
	    	m_mutex.lock();
	        m_queue.push(item);
	        m_mutex.unlock();
	    }

	    T pop(){
	    	m_mutex.lock();
	    	T item;
	    	if(! m_queue.empty()){
	    		item = m_queue.front();
	    		m_queue.pop();
	    	}
	    	m_mutex.unlock();
	        return item;
	    }
	    
};

#endif
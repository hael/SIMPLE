#include "core.hpp"
#include "star.hpp"
#include "socket.hpp"
#include "handler.hpp"

bool Core::CRYOSPARC_test(){

	std::string nicecsserver;
	
	if(!this->getConfigValue ("nicecsserver", nicecsserver)){
		this->logError("failed to retrieve nicecsserver from config. CRYOSPARC disabled");
		return false;
	}

	std::string nicecsport;
	
	if(!this->getConfigValue ("nicecsport", nicecsport)){
		this->logError("failed to retrieve nicecsport from config. CRYOSPARC disabled");
		return false;
	}

	nlohmann::ordered_json request;
	request["querytype"] = "cstest";

	std::string response;

	if(!send_socket_msg(request.dump(), response)){
		this->logInfo("communication with CRYOSPARC instance failed");
		this->logInfo("CRYOSPARC disabled");
		return false;
	}

	nlohmann::ordered_json responsejson = nlohmann::ordered_json::parse(response);

	if(responsejson.contains("messages")){
		for(std::string message : responsejson["messages"]){
			this->logInfo(message);
		}
	}

	if(responsejson.contains("status") && responsejson["status"].is_boolean() && responsejson["status"].get<bool>()){
		this->logInfo("CRYOSPARC enabled");
		return true;
	}

	this->logInfo("CRYOSPARC disabled");
	return false;

}

void Core::CRYOSPARC_export2instance(std::string jobfolder, std::string projectname, std::string workspacename, std::string username, std::string micsstar, std::string ptclsstar){

	std::string nicecsserver;
	
	if(!this->getConfigValue ("nicecsserver", nicecsserver)){
		this->logError("failed to retrieve nicecsserver from config. CRYOSPARC disabled");
		return;
	}

	std::string nicecsport;
	
	if(!this->getConfigValue ("nicecsport", nicecsport)){
		this->logError("failed to retrieve nicecsport from config. CRYOSPARC disabled");
		return;
	}

	nlohmann::ordered_json request;
	request["querytype"]     = "csimport";
	request["user"]          = username;
	request["project"]       = projectname;
	request["projectfolder"] = parentPath(parentPath(jobfolder));
	request["workspace"]     = workspacename;

	if(micsstar != "") {
		
		request["micdataroot"]  = parentPath(parentPath(micsstar));

		nlohmann::ordered_json mics = readSTAR(micsstar);
		nlohmann::ordered_json fastoptics = {};

		if(mics.contains("data_optics") && mics["data_optics"].contains("loop") && mics["data_optics"]["loop"].is_array()){
			// find largest optics group
			int maxopt = 0;
			for(auto optics : mics["data_optics"]["loop"]){
				if(optics.contains("_rlnOpticsGroup")){
					int opt = std::stoi(optics["_rlnOpticsGroup"].get<std::string>());
					if(opt > maxopt) maxopt = opt;
				}
			}

			
			for(int i = 0; i <= maxopt; i++){
				fastoptics.push_back({});
			}

			for(auto optics : mics["data_optics"]["loop"]){
				if(optics.contains("_rlnOpticsGroup")){
					int opt = std::stoi(optics["_rlnOpticsGroup"].get<std::string>());
					fastoptics[opt] = optics;
				}
			}

		}

		if(mics.contains("data_micrographs") && mics["data_micrographs"].contains("loop") && mics["data_micrographs"]["loop"].is_array()){
			std::vector<std::string> microots;
			std::vector<std::string> micapix;
			std::vector<std::string> mickv;
			std::vector<std::string> miccs;
			std::vector<std::string> micdose;

			for(auto micrograph : mics["data_micrographs"]["loop"]){
				if(micrograph.contains("_rlnMicrographName")){

					std::string micname = micrograph["_rlnMicrographName"].get<std::string>();
					std::string testroot = parentPath(micname);
					std::string wildcard = "/*." + extension(micname);

					if(micname.find("_intg.mrc") != std::string::npos){
						wildcard = "/*_intg.mrc";
					}
					
					testroot = testroot + wildcard;
					
					if (!std::any_of(microots.begin(), microots.end(), [testroot](std::string y) { return testroot == y; })){
					
						microots.push_back(testroot);

						if(micrograph.contains("_rlnOpticsGroup")){

							nlohmann::ordered_json opticsinfo = fastoptics[std::stoi(micrograph["_rlnOpticsGroup"].get<std::string>())];

							if(opticsinfo.contains("_rlnImagePixelSize")){
								micapix.push_back(opticsinfo["_rlnImagePixelSize"].get<std::string>());
							}else{
								micapix.push_back("0");
							}

							if(opticsinfo.contains("_rlnVoltage")){
								mickv.push_back(opticsinfo["_rlnVoltage"].get<std::string>());
							}else{
								mickv.push_back("0");
							}

							if(opticsinfo.contains("_rlnSphericalAberration")){
								miccs.push_back(opticsinfo["_rlnSphericalAberration"].get<std::string>());
							}else{
								miccs.push_back("0");
							}

							// need to handle this one better!!!
							if(opticsinfo.contains("_rlnImageDose")){
								micdose.push_back(opticsinfo["_rlnImageDose"].get<std::string>());
							}else{
								micdose.push_back("30"); 
							}
						}else{
							micapix.push_back("0");
							mickv.push_back("0");
							miccs.push_back("0");
							micdose.push_back("0");
						}

					}

				}
			}
			request["microots"] = microots;
			request["micapix"]  = micapix;
			request["mickv"]    = mickv;
			request["miccs"]    = miccs;
			request["micdose"]  = micdose;
		}

	}

	if(ptclsstar != ""){
		request["ptclsstar"] = ptclsstar;
		request["ptcldataroot"]  = parentPath(parentPath(ptclsstar));
	}

	std::string response;

	if(!send_socket_msg(request.dump(), response)){
		this->logInfo("communication with CRYOSPARC instance failed");
		this->logInfo("CRYOSPARC disabled");
		return;
	}

	nlohmann::ordered_json responsejson = nlohmann::ordered_json::parse(response);

	std::string logfile = jobfolder + "/nice.log";

	if(folderExists(jobfolder) && responsejson.contains("messages")){

		std::ofstream logout (logfile.c_str(), std::ofstream::app);

		for(std::string message : responsejson["messages"]){
			logout << message << std::endl;
		}

		logout.close();
	}

	/*if(responsejson.contains("status") && responsejson["status"].is_boolean() && responsejson["status"].get<bool>()){
		this->logInfo("CRYOSPARC enabled");
		return true;
	}*/

}

nlohmann::ordered_json Handler::CRYOSPARC_link(nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("module")){
		this->core->logError("CRYOSPARC_link : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		return returnjson;
	}

	if(!requestjson->contains("version")){
		this->core->logError("CRYOSPARC_link : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		return returnjson;
	}

	if(!requestjson->contains("type")){
		this->core->logError("CRYOSPARC_link : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("CRYOSPARC_link : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("CRYOSPARC_link : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		return returnjson;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("CRYOSPARC_link : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		return returnjson;
	}

	std::string module     (requestjson->at("module").get<std::string>());
	std::string version    (requestjson->at("version").get<std::string>());
	std::string jobtype    (requestjson->at("type").get<std::string>());

	returnjson = this->CreateJob(requestjson);
	//returnjson = this->CreateInteractiveJob(requestjson);

	if(returnjson["success"] == false){
		this->core->logError("CRYOSPARC_link : server failed to reply: failed to create job");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to create job";
		return returnjson;
	}
/*
	std::string micsstar;

	if(fileExists(returnjson["parentfolder"].get<std::string>() + "/micrographs.star")){
		micsstar = returnjson["jobfolder"].get<std::string>() + "/micrographs.star";
		copyFile(returnjson["parentfolder"].get<std::string>() + "/micrographs.star", micsstar);
	}

	std::string ptclsstar;

	if(fileExists(returnjson["parentfolder"].get<std::string>() + "/particles3D.star")){
		ptclsstar = returnjson["jobfolder"].get<std::string>() + "/particles3D.star";
		copyFile(returnjson["parentfolder"].get<std::string>() + "/particles3D.star", ptclsstar);
	}else if(fileExists(returnjson["parentfolder"].get<std::string>() + "/particles2D.star")){
		ptclsstar = returnjson["jobfolder"].get<std::string>() + "/particles2D.star";
		copyFile(returnjson["parentfolder"].get<std::string>() + "/particles2D.star", ptclsstar);
	}

	this->core->CRYOSPARC_export2instance(returnjson["jobfolder"].get<std::string>(), returnjson["projectname"].get<std::string>(), returnjson["workspacename"].get<std::string>(), returnjson["username"].get<std::string>(), micsstar, ptclsstar);*/

	return returnjson;
}


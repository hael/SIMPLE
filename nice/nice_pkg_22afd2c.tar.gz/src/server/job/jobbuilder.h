#ifndef JOBBUILDER_H
#define JOBBUILDER_H

#include <iostream>
#include <fstream>
#include <json.hpp>
#include <spdlog/spdlog.h>

// temporarily here

class JobBuilder {
	public:
		JobBuilder();
		nlohmann::ordered_json joblist;
		nlohmann::ordered_json jobargs;
		std::string module;
	//	nlohmann::ordered_json listAvailable();

};

#endif
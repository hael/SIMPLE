#include "core.hpp"
#include "simple_stream.hpp"

void Core::dispatchWorker(){
	while(true){
		usleep(5000000);
		this->logInfo("starting dispatch worker cycle");
		this->dispatchCycle();
		this->logInfo("completed dispatch worker cycle");
	}

}

void Core::dispatchFail(int jobid){

	std::string sql = "UPDATE jobs SET status='failed' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::dispatchSubmitted(int jobid, std::string submitcommand, std::string cancelcommand, std::string statuscommand){

	std::string sql = "UPDATE jobs SET status='submitted',"
									  "submitcommand='" + submitcommand + "',"
									  "cancelcommand='" + cancelcommand + "',"
									  "statuscommand='" + statuscommand + "',"
									  "starttime=CURRENT_TIMESTAMP"
					   " WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchSubmitted : sql query failed");
		return;
	}
}

void Core::dispatchCycle(){

	std::string sql = "SELECT * FROM jobs WHERE status='queued';";
	
	std::vector<std::map<std::string, std::string>> queuedjobs;

	if(!this->queryDB(sql, &queuedjobs)){
		this->logError("dispatchCycle : server failed to reply: sql query failed");
		return;
	}

	for(auto &job : queuedjobs){

		if(job.find("id") == job.end()){
			this->logError("dispatchCycle : id missing for job");
			continue;
		}

		int jobid = std::stoi(job["id"]);

		if(job.find("workspaceid") == job.end()){
			this->logError("dispatchCycle : workspaceid missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		int workspaceid = std::stoi(job["workspaceid"]);

		std::map<std::string, std::string> workspace;

		if(!this->getWorkspace(workspaceid, "", "admin", &workspace)){
			this->logError("dispatchCycle : failed to retrieve workspace");
			this->dispatchFail(jobid);
			continue;
		}

		if(workspace.find("project") == workspace.end()){
			this->logError("dispatchCycle : project missing for workspace");
			this->dispatchFail(jobid);
			continue;
		}

		int projectid = std::stoi(workspace["project"]);

		std::map<std::string, std::string> project;

		if(!this->getProject(projectid, "", "admin", &project)){
			this->logError("dispatchCycle : failed to retrieve project");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("subfolder") == job.end()){
			this->logError("dispatchCycle : subfolder missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("module") == job.end()){
			this->logError("dispatchCycle : module missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("version") == job.end()){
			this->logError("dispatchCycle : version missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("jobtype") == job.end()){
			this->logError("dispatchCycle : jobtype missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("jobtypeid") == job.end()){
			this->logError("dispatchCycle : jobtypeid missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("arguments") == job.end()){
			this->logError("dispatchCycle : arguments missing for job");
			this->dispatchFail(jobid);
			continue;
		}
		
		if(job.find("parentid") == job.end()){
			this->logError("dispatchCycle : parentid missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("owner") == job.end()){
			this->logError("dispatchCycle : owner missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(workspace.find("subfolder") == workspace.end()){
			this->logError("dispatchCycle : subfolder missing for workspace");
			this->dispatchFail(jobid);
			continue;
		}

		if(workspace.find("name") == workspace.end()){
			this->logError("dispatchCycle : name missing for workspace");
			this->dispatchFail(jobid);
			continue;
		}
		
		if(project.find("folder") == project.end()){
			this->logError("dispatchCycle : folder missing for project");
			this->dispatchFail(jobid);
			continue;
		}

		if(project.find("name") == project.end()){
			this->logError("dispatchCycle : name missing for project");
			this->dispatchFail(jobid);
			continue;
		}

		std::string jobfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + job["subfolder"];

		if(!ensureFolder(jobfolder)){
			this->logError("dispatchCycle : failed to create job folder");
			this->dispatchFail(jobid);
			continue;
		}

		std::string parentsubfolder;

		int parentid = std::stoi(job["parentid"]);

		if(parentid >= 0){
			
			sql = "SELECT * FROM jobs WHERE id=" + std::to_string(parentid) + ";";
			
			std::vector<std::map<std::string, std::string>> parent;
			
			if(!this->queryDB(sql, &parent)){
				this->logError("dispatchCycle : failed to obtain parent");
				this->dispatchFail(jobid);
				continue;
			}

			if(parent.size() != 1){
				this->logError("dispatchCycle : parent incorrect length");
				this->dispatchFail(jobid);
				continue;
			}

			if(parent[0].find("status") == parent[0].end()){
				this->logError("dispatchCycle : status missing from parent");
				this->dispatchFail(jobid);
				continue;
			}

			if(parent[0]["status"] == "failed"){
				this->dispatchFail(jobid);
				continue;
			}else if(parent[0]["status"] != "finished" && parent[0]["status"] != "interactive" ){
				continue;
			}

			if(parent[0].find("subfolder") == parent[0].end()){
				this->logError("dispatchCycle : subfolder missing from parent");
				this->dispatchFail(jobid);
				continue;
			}

			parentsubfolder = parent[0]["subfolder"];

		}

		std::string module  = job["module"];
		std::string version = job["version"];
		std::string jobtype = job["jobtype"];
		int jobtypeid = std::stoi(job["jobtypeid"]);

		if(jobtype == "link_cryosparc"){

			this->collectRunning(jobid);

			std::string micsstar;
			std::string parentfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + parentsubfolder;

			if(fileExists(parentfolder + "/micrographs.star")){
				micsstar = jobfolder + "/micrographs.star";
				copyFile(parentfolder + "/micrographs.star", micsstar);
			}

			std::string ptclsstar;

			if(fileExists(parentfolder + "/particles3D.star")){
				ptclsstar = jobfolder + "/particles3D.star";
				copyFile(parentfolder + "/particles3D.star", ptclsstar);
			}else if(fileExists(parentfolder + "/particles2D.star")){
				ptclsstar = jobfolder + "/particles2D.star";
				copyFile(parentfolder + "/particles2D.star", ptclsstar);
			}

			this->CRYOSPARC_export2instance(jobfolder, project["name"], workspace["name"], job["owner"], micsstar, ptclsstar);
			
			this->collectFinish(jobid);
			continue;
		}

		nlohmann::ordered_json jobargs = nlohmann::ordered_json::parse(job["arguments"]);

		if(!jobargs.contains("nicecluster")){
			this->logError("dispatchCycle : nicecluster missing from job arguments");
			this->dispatchFail(jobid);
			continue;
		}

		if(!jobargs["nicecluster"].is_string()){
			this->logError("dispatchCycle : nicecluster is not a string");
			this->dispatchFail(jobid);
			continue;
		}

		std::string nicecluster = jobargs["nicecluster"].get<std::string>();

		nlohmann::ordered_json clusterlist;

		if(module == "SIMPLE"){
			this->SIMPLE_getClusters(&clusterlist);
		}else if(module == "RELION"){
			this->RELION_getClusters(&clusterlist);
		}

		if(!clusterlist.contains("clusters")){
			this->logError("dispatchCycle: clusters missing from clusterlist");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"].is_array()){
			this->logError("dispatchCycle: clusters is not an array");
			this->dispatchFail(jobid);
			continue;
		}

		int clusterid = -1;

		if(nicecluster == "default"){
			clusterid = 0;
		}else{
			for(int i = 0; i < clusterlist["clusters"].size(); i++){
				if(clusterlist["clusters"][i].contains("name") && clusterlist["clusters"][i]["name"].is_string() && clusterlist["clusters"][i]["name"].get<std::string>() == nicecluster){
					clusterid = i;
					break;
				}
			}
		}

		if(clusterid < 0){
			this->logError("dispatchCycle: cluster missing from clusterlist");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"][clusterid].contains("template")){
			this->logError("dispatchCycle: template missing from cluster");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"][clusterid]["template"].is_string()){
			this->logError("dispatchCycle: template is not a string");
			this->dispatchFail(jobid);
			continue;
		}

		std::string clustertemplate = clusterlist["clusters"][clusterid]["template"].get<std::string>();

		if(!fileExists(jobfolder + "/nice.script")){
			if(module == "SIMPLE"){
				if(!this->SIMPLE_jobInit(version, jobtype, jobfolder, clustertemplate, jobargs, parentsubfolder)){
					this->logError("dispatchCycle : failed to init SIMPLE job");
					this->dispatchFail(jobid);
					continue;
				}
			}else if(module == "RELION"){
				if(!this->RELION_jobInit(version, jobtype, jobtypeid, jobfolder, clustertemplate, jobargs, parentsubfolder)){
					this->logError("dispatchCycle : failed to init RELION job");
					this->dispatchFail(jobid);
					continue;
				}
			}
		}

		if(!clusterlist["clusters"][clusterid].contains("submitcommand")){
			this->logError("dispatchCycle: submitcommand missing from cluster");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"][clusterid]["submitcommand"].is_string()){
			this->logError("dispatchCycle: submitcommand is not a string");
			this->dispatchFail(jobid);
			continue;
		}

		std::string submitcommand = clusterlist["clusters"][clusterid]["submitcommand"].get<std::string>();

		if(!clusterlist["clusters"][clusterid].contains("statuscommand")){
			this->logError("dispatchCycle: statuscommand missing from cluster");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"][clusterid]["statuscommand"].is_string()){
			this->logError("dispatchCycle: statuscommand is not a string");
			this->dispatchFail(jobid);
			continue;
		}

		std::string statuscommand = clusterlist["clusters"][clusterid]["statuscommand"].get<std::string>();

		if(!clusterlist["clusters"][clusterid].contains("cancelcommand")){
			this->logError("dispatchCycle: cancelcommand missing from cluster");
			this->dispatchFail(jobid);
			continue;
		}

		if(!clusterlist["clusters"][clusterid]["cancelcommand"].is_string()){
			this->logError("dispatchCycle: cancelcommand is not a string");
			this->dispatchFail(jobid);
			continue;
		}

		std::string cancelcommand = clusterlist["clusters"][clusterid]["cancelcommand"].get<std::string>();
		this->statusAddCommand(statuscommand);

		std::string systemcmd = submitcommand + " ./nice.script &";
		pid_t c_pid = fork(); 
		
		if (c_pid == -1) { 
        	this->logError("dispatchCycle: cancelcommand is not a string");
			this->dispatchFail(jobid);
			continue;
    	} else if (c_pid > 0) { 
       		this->logInfo("dispatchCycle: submitting job " + jobfolder + " " + std::to_string(jobid));
			
  			this->logInfo("dispatchCycle: submitted job " + std::to_string(jobid));

			this->dispatchSubmitted(jobid, submitcommand, cancelcommand, statuscommand);
    	} else { 
			chdir(jobfolder.c_str());
			int a = std::system(systemcmd.c_str());
	       	exit(0);
    	} 
		
	}

	sql = "SELECT * FROM jobs WHERE status='interactive';";

	std::vector<std::map<std::string, std::string>> interactivejobs;

	if(!this->queryDB(sql, &interactivejobs)){
		this->logError("dispatchCycle : server failed to reply: sql query failed");
		return;
	}

	for(auto &job : interactivejobs){
		if(job.find("id") == job.end()){
			this->logError("dispatchCycle : id missing for job");
			continue;
		}

		int jobid = std::stoi(job["id"]);

		if(job.find("workspaceid") == job.end()){
			this->logError("dispatchCycle : workspaceid missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("jobtype") == job.end()){
			this->logError("dispatchCycle : jobtype missing for job");
			continue;
		}

		int workspaceid = std::stoi(job["workspaceid"]);

		std::map<std::string, std::string> workspace;

		if(!this->getWorkspace(workspaceid, "", "admin", &workspace)){
			this->logError("dispatchCycle : failed to retrieve workspace");
			this->dispatchFail(jobid);
			continue;
		}

		if(workspace.find("project") == workspace.end()){
			this->logError("dispatchCycle : project missing for workspace");
			this->dispatchFail(jobid);
			continue;
		}

		int projectid = std::stoi(workspace["project"]);

		std::map<std::string, std::string> project;

		if(!this->getProject(projectid, "", "admin", &project)){
			this->logError("dispatchCycle : failed to retrieve project");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("subfolder") == job.end()){
			this->logError("dispatchCycle : subfolder missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("module") == job.end()){
			this->logError("dispatchCycle : module missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("version") == job.end()){
			this->logError("dispatchCycle : version missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("jobtype") == job.end()){
			this->logError("dispatchCycle : jobtype missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(job.find("status") == job.end()){
			this->logError("dispatchCycle : status missing for job");
			this->dispatchFail(jobid);
			continue;
		}

		if(workspace.find("subfolder") == workspace.end()){
			this->logError("dispatchCycle : subfolder missing for workspace");
			this->dispatchFail(jobid);
			continue;
		}
		
		if(project.find("folder") == project.end()){
			this->logError("dispatchCycle : folder missing for project");
			this->dispatchFail(jobid);
			continue;
		}

		std::string jobfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + job["subfolder"];

		std::string module  = job["module"];
		std::string version = job["version"];
		std::string jobtype = job["jobtype"];
		std::string status  = job["status"];

		if(status == "interactive"){
			if(!folderExists(jobfolder)){
				this->logError("dispatchCycle : folder missing for interactive job");
				this->dispatchFail(jobid);
				continue;
			}
			if(module == "SIMPLE" && job["jobtype"] == "stream"){

				SIMPLE_Stream* simple_stream = new SIMPLE_Stream(this, jobfolder, jobid);

				if(!simple_stream->Dispatch()){
					this->logError("dispatchCycle : simple_stream dispatch failed");
					this->dispatchFail(jobid);		
				}

				delete simple_stream;

			}
		}

	}

}
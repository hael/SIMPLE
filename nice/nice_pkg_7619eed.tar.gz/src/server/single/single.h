#ifndef SINGLE_H
#define SINGLE_H

#include <iostream>
#include <fstream>
#include <vector>
#include <json.hpp>
#include <json_helpers.h>
#include <config.h>
#include <filesystem.h>
#include <jobbuilder.h>
#include <db.h>
#include <sys.h>
#include <workspace.h>
#include <spdlog/spdlog.h>
#include <process.h>
#include <jobtemplate.h>

class Single : public JobBuilder {

	private:
		nlohmann::ordered_json ui;
		std::string preprocess_dir = "preprocessing";
		std::string optics_dir     = "assign_optics";
		std::string inipick_dir    = "initial_picking";
		std::string refgen_dir     = "reference_generation";
		std::string refpick_dir    = "reference_picking";
		std::string stream2d_dir   = "stream_2D";
		std::string stream3d_dir   = "stream_3D";

	public:
		Single();
		bool ReadJobJson();
};

#endif
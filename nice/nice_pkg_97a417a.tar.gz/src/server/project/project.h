#ifndef PROJECT_H
#define PROJECT_H

#include <iostream>
#include <json.hpp>
#include <json_helpers.h>
#include <filesystem.h>
#include <db.h>
#include <spdlog/spdlog.h>

enum {
	 SUCCESS,
	 FAILURE,
	 PREEXISTING_PROJECT,
	 PREEXISTING_FOLDER,
	 MISSING_FOLDER,
	 FAILED_MKFOLDER,
	 PREEXISTING_LINK,
	 FAILED_MKLINK,
};

class Project {

	protected:
		int         project_id;     // unique id
		std::string project_folder; // full path to job folder
		std::string project_name;   // project name

		int CreateProject(std::string projectname, std::string projectfolder);
	public:
		Project();
		Project (nlohmann::ordered_json args);
		bool LoadProject(int project_id);
		nlohmann::ordered_json NewProject(nlohmann::ordered_json args);
		nlohmann::ordered_json ListAllProjects();
		nlohmann::ordered_json ListRecentProjects();
		nlohmann::ordered_json StatProject();
		nlohmann::ordered_json Rename(nlohmann::ordered_json args);
};

#endif
#ifndef IMAGER_H
#define IMAGER_H

#include <iostream>
#include <fstream>
#include <filesystem.h>
#include <db.h>
#include <sys.h>
#include <spdlog/spdlog.h>

enum ImageType{
	FAILED,
	THUMBNAIL_JPEG,
	BINARY,
};

struct JPEG_Section_Header {
    uint16_t com;
    uint16_t com_len;
};

struct JPEG_App1_Section {
    uint16_t app;
    uint16_t app_len;
    uint32_t payload_len;
    char     prog[4] = {'n', 'i', 'c', 'e'};
    uint8_t  napp; // at end for 4 byte alignment
};

class Imager {

	protected:
		std::string thumbnail_uid;
		
		
	public:
		char* binary_data;
		int datalength;
		enum ImageType type;
		Imager(std::string thumbnail_uid);
		Imager(int i, std::string thumbnail_uid);
};

#endif
#include "database_commander.h"

DatabaseCommander::DatabaseCommander (bool local) {
    // needs sorting to look like HTTPServer and log to correct location
    this->pg_ctl_path = getExecutableDir() + "/pg_ctl";
    if(local){
        if(!this->InitLocalDB()){
            std::cout << "failed to initialize local db" << std::endl;
            return;
        }
    }else{
        this->postgres_db = getRootDir() + "/var/db";
    }
    if(!folderExists(this->postgres_db)){
        std::cout << "DB folder missing " << this->postgres_db << std::endl;
        return;
    }
    if(!fileExists(this->pg_ctl_path)){
        std::cout << "pg_ctl executable missing " << this->pg_ctl_path << std::endl;
        return;
    }
    int status = this->Status();
    if(status != 0){
        this->Start();
        this->ApplySchema();
    }else{
        this->WasRunning = true;
    }
  
}

bool DatabaseCommander::InitLocalDB () {
    char* homedirenv = getenv("HOME");
    if(homedirenv == nullptr){
        std::cout << "HOME not set" << std::endl;
        return false;
    }

    std::string homedir(homedirenv);

    if(!ensureFolder(homedir + "/.nice3")){
        std::cout << "failed to ensure " + homedir + "/.nice3" + " directory exists" << std::endl;
        return false;
    }

    std::string dbdir = homedir + "/.nice3/db";
    if(!folderExists(dbdir)){

        if(!ensureFolder(dbdir)){
            std::cout << "failed to ensure " + dbdir + " directory exists" << std::endl;
            return false;
        }

        std::string cmd = getExecutableDir() + "/initdb -D " + dbdir;
        int rc = system(cmd.c_str());

        cmd = this->pg_ctl_path + " -D " + dbdir + " start";
        rc = system(cmd.c_str());

        cmd = getExecutableDir() + "/createdb nice";
        rc = system(cmd.c_str());

        cmd = this->pg_ctl_path + " -D " + dbdir + " stop";
        rc = system(cmd.c_str());
    }

    this->postgres_db = homedir + "/.nice3/db";

    return true;
}

void DatabaseCommander::Start () {
    std::string cmd = pg_ctl_path + " -D " + postgres_db + " start";
    int rc = system(cmd.c_str());
}

int DatabaseCommander::Status () {
    std::string cmd = pg_ctl_path + " -D " + postgres_db + " status";
    int rc = system(cmd.c_str());
    return WEXITSTATUS(rc);
}

void DatabaseCommander::Stop () {
    std::string cmd = pg_ctl_path + " -D " + postgres_db + " stop";
    int rc = system(cmd.c_str());
}

void DatabaseCommander::ApplySchema(){
    // processes table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS processes (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS name           VARCHAR(32);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS executable     VARCHAR(64);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS status         VARCHAR(10);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS module         VARCHAR(16);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS folder         VARCHAR(1024);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS preexeccommand VARCHAR(1024);"});
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS dependentid   INTEGER;"    });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS dependentjobid   INTEGER;"    });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS templateid    INTEGER;"    });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS queuetime     TIMESTAMP;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS starttime     TIMESTAMP;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS endtime       TIMESTAMP;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS heartbeattime TIMESTAMP;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS startrunning  BOOLEAN DEFAULT FALSE;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS userinput     BOOLEAN DEFAULT FALSE;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS restart       BOOLEAN DEFAULT FALSE;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS startuser     BOOLEAN DEFAULT FALSE;"  });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS uservals      JSON;"       });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS stat          JSON;"       });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS arguments     JSON;"       });
    sql_request(std::string_view{"ALTER TABLE processes ADD COLUMN IF NOT EXISTS updatearguments     JSON;"       });
    // thumbnails table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS thumbnails (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS path        VARCHAR(2048);"});
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS uid         VARCHAR(7);"   });
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS processid   INTEGER;"      });
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS thumbnailid INTEGER;"      });
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS staticid    INTEGER;"      });
    sql_request(std::string_view{"ALTER TABLE thumbnails ADD COLUMN IF NOT EXISTS blob        BYTEA;"        });
    // users table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS users (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS username      VARCHAR(20);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS firstname     VARCHAR(20);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS lastname      VARCHAR(20);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS password      VARCHAR(20);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS token         VARCHAR(32);"});
    sql_request(std::string_view{"ALTER TABLE users ADD COLUMN IF NOT EXISTS admin         BOOLEAN DEFAULT FALSE;"});
    // projects table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS projects (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE projects ADD COLUMN IF NOT EXISTS name            VARCHAR(128);"});
    sql_request(std::string_view{"ALTER TABLE projects ADD COLUMN IF NOT EXISTS folder          VARCHAR(1024);"});
    sql_request(std::string_view{"ALTER TABLE projects ADD COLUMN IF NOT EXISTS activeworkspace INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE projects ADD COLUMN IF NOT EXISTS cleartrash      BOOLEAN DEFAULT FALSE;"  });
    // workspaces table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS workspaces (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS name          VARCHAR(128);"});
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS folder        VARCHAR(1024);"});
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS project       INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS displayid     INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS accesstime    TIMESTAMP;"  });
    sql_request(std::string_view{"ALTER TABLE workspaces ADD COLUMN IF NOT EXISTS cleartrash    BOOLEAN DEFAULT FALSE;"  });
    // jobs table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS jobs (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS name            VARCHAR(128);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS folder          VARCHAR(1024);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS type            VARCHAR(64);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS module          VARCHAR(16);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS status          VARCHAR(16);"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS workspace       INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS displayid       INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS parent          INTEGER;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS diskspacemb     BIGINT DEFAULT -1;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS children        INTEGER[];"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS processes       INTEGER[];"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS arguments       JSON;"       });
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS deleted         BOOLEAN DEFAULT FALSE;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS retrievable     BOOLEAN DEFAULT FALSE;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS trashed         BOOLEAN DEFAULT FALSE;"});
    sql_request(std::string_view{"ALTER TABLE jobs ADD COLUMN IF NOT EXISTS retrieve        BOOLEAN DEFAULT FALSE;"});
    //config table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS config (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE config ADD COLUMN IF NOT EXISTS config       JSON;"       }); 
    //templates table
    sql_request(std::string_view{"CREATE TABLE IF NOT EXISTS templates (id BIGSERIAL PRIMARY KEY);"});
    sql_request(std::string_view{"ALTER TABLE templates ADD COLUMN IF NOT EXISTS name            VARCHAR(32);"});
    sql_request(std::string_view{"ALTER TABLE templates ADD COLUMN IF NOT EXISTS submitcommand   VARCHAR(128);"});
    sql_request(std::string_view{"ALTER TABLE templates ADD COLUMN IF NOT EXISTS defaulttemplate BOOLEAN DEFAULT FALSE;"});
    sql_request(std::string_view{"ALTER TABLE templates ADD COLUMN IF NOT EXISTS template        TEXT;"}); 
}
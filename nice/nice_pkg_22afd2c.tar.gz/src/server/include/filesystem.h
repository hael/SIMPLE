#ifndef FILESYSTEM
#define FILESYSTEM

#include <filesystem>
#include <regex>
#include <chrono>
#include <iomanip>
#include <system_error>
#include <pwd.h>
#include <grp.h>
#include <sys/stat.h>
#include <iostream>
#include <math.h>

static bool fileExists(std::string filepath){
	
	std::filesystem::path path(filepath);
	
	if(std::filesystem::exists(path)){
		if(std::filesystem::is_regular_file(path)){
			return true;
		}
	}
	return false;
}

static bool folderExists(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	if(std::filesystem::exists(path)){
		if(std::filesystem::is_directory(path)){
			return true;
		}
	}
	return false;
}

static bool linkExists(std::string linkpath){
	
	std::filesystem::path path(linkpath);
	
	if(std::filesystem::exists(path)){
		if(std::filesystem::is_symlink(path)){
			return true;
		}
	}
	return false;
}

static bool fifoExists(std::string filepath){
	
	std::filesystem::path path(filepath);
	
	if(std::filesystem::exists(path)){
		if(std::filesystem::is_fifo(path)){
			return true;
		}
	}
	return false;
}

static std::string basename(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	return path.filename();
}

static std::string stem(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	return path.stem();
}

static std::string extension(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	return path.extension();
}

static std::string parentPath(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	return path.parent_path();
}

// returns a number
static std::uintmax_t fileSize(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	return std::filesystem::file_size(folderpath);
}

static std::uintmax_t directorySize(std::string folderpath){
	uintmax_t dirsize = 0;
	
	std::filesystem::path path(folderpath);

    for (std::filesystem::directory_entry const& entry : std::filesystem::recursive_directory_iterator(path)){
    	try{
	        if (entry.exists() && entry.is_regular_file()){
	        	dirsize += entry.file_size();
	        }
	    }catch (std::filesystem::filesystem_error const& ex){
	    	dirsize += 0;
	    }
    }
	
	return dirsize;
}


// returns a string with a unit
static std::string fileSizeString(std::string folderpath){
	
	std::filesystem::path path(folderpath);
	
	std::uintmax_t intsize = std::filesystem::file_size(folderpath);
	std::string size;
	
	// divide by 1024 and add unit
	if (intsize < 1024) {
		size = std::to_string(intsize) + "B";
	} else if (intsize < (1024*1024) ) {
		size = std::to_string(intsize/1024) + "kB";
	} else if (intsize < (1024*1024*1024) ) {
		size = std::to_string(intsize/(1024*1024) ) + "MB";
	} else {
		size = std::to_string(intsize/(1024*1024*1024) ) + "GB";
	}
	
	return size;
}

static std::vector<std::string> getFolders(std::string folderpath){
	
	std::vector<std::string> folders;
	
	for(auto& p: std::filesystem::directory_iterator(folderpath)){

        if(folderExists(p.path())){
			folders.push_back(p.path());
		}
	}
	
	return folders;
}

static bool ensureFolder(std::string folderpath){

	if(folderExists(folderpath)) return true;
	
	std::filesystem::path path(folderpath);
	std::error_code ec;

	std::filesystem::create_directories(path, ec);
	
	if(!ec){
		return true;
	}else{
		std::cout << ec.message() << std::endl;
		return false;
	}
}

static bool moveFolder(std::string source, std::string destination){
	
	std::filesystem::path sourcepath(source);
	std::filesystem::path destinationpath(destination);
	std::error_code ec;
	
	std::filesystem::rename(sourcepath, destinationpath, ec);
	
	if(!ec){
		return true;
	}else{
		std::cout << ec.message() << std::endl;
		return false;
	}
}

static void copyFile(std::string sourcefile, std::string destinationfile){
	
	std::filesystem::path sourcepath(sourcefile);
	std::filesystem::path destinationpath(destinationfile);
	std::filesystem::copy(sourcepath, destinationpath);
	
}

static void linkDir(std::string sourcedir, std::string destinationdir){
	
	std::filesystem::path sourcepath(sourcedir);
	std::filesystem::path destinationpath(destinationdir);
	std::filesystem::create_directory_symlink(sourcepath, destinationpath);
	
}

static void linkFile(std::string source, std::string destination){
	
	std::filesystem::path sourcepath(source);
	std::filesystem::path destinationpath(destination);
	std::filesystem::create_symlink(sourcepath, destinationpath);
	
}

static bool removeFile(std::string sourcefile){
	
	std::filesystem::path sourcepath(sourcefile);
	return std::filesystem::remove(sourcepath);
	
}

static bool removeDirRecursive(std::string sourcefile){
	
	std::filesystem::path sourcepath(sourcefile);
	return std::filesystem::remove_all(sourcepath);
	
}

static std::vector<std::string>findFiles(std::string directory, std::regex pattern) {
	
	std::vector<std::string> filevec;
	
	for(auto i = std::filesystem::directory_iterator(directory); i !=  std::filesystem::directory_iterator(); ++i ){
		auto path = *i;
		bool isfile = std::filesystem::is_regular_file(path);
		bool match = false;
		std::string checkpath = path.path();
		
		if ( std::regex_match(checkpath, pattern) ) {
			match = true;
		}
		
		if ( isfile && match) {

			filevec.push_back(checkpath);
		}
	}
	
	return filevec;
}

static std::string humanSize(std::uintmax_t size){

	std::string returnstring;

	int o{};
    double mantissa = size;
    for (; mantissa >= 1024.; mantissa /= 1024., ++o);
    returnstring += std::to_string((int)std::ceil(mantissa)); // may need more precision
	returnstring += "BKMGTPE"[o];
	return returnstring;
}

static bool ls1fDir(std::string directory, std::vector<std::string>* dirs, std::vector<std::string>* files) {
	
	try{
		for(auto const& path : std::filesystem::directory_iterator(directory)){
			if(path.is_directory()){
				dirs->push_back(path.path().filename());
			}else if(path.is_regular_file()){
				files->push_back(path.path().filename());
			}else if(path.is_symlink()){
				files->push_back(path.path().filename());
			}
		}
	}catch(...){
		return false;
	}
	
	return true;
}

static bool writeTime(std::string path, std::time_t& tsepoch) {
	
	try{
		std::filesystem::path sourcepath(path);
		std::filesystem::file_time_type ftime = std::filesystem::last_write_time(sourcepath);
		std::filesystem::file_time_type now = std::filesystem::__file_clock::now();
		std::chrono::time_point<std::chrono::system_clock> epoch = std::chrono::system_clock::now();
		std::time_t ftimet = std::chrono::duration_cast<std::chrono::seconds>(ftime.time_since_epoch()).count();
		std::time_t nowt = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
		std::time_t epocht = std::chrono::duration_cast<std::chrono::seconds>(epoch.time_since_epoch()).count();
		tsepoch = epocht - nowt + ftimet;
	}catch(...){
		return false;
	}
	
	return true;
}

static bool humanFileSize(std::string path, std::string& filesize) {
	
	try{
		std::filesystem::path sourcepath(path);
		std::uintmax_t size = std::filesystem::file_size(sourcepath);
		filesize = humanSize(size);
	}catch(...){
		return false;
	}
	
	return true;
}

static bool lsDir(std::string directory, std::vector<std::vector<std::string>>* dirs, std::vector<std::vector<std::string>>* files) {
	
	try{
		for(auto const& path : std::filesystem::directory_iterator(directory)){
			
			std::vector<std::string> itvec; // [0] name [1] path [2] link [4] modtime [5] size
			
			std::string pathstr = path.path();
			std::string filenamestr = path.path().filename();
			std::string symlinkstr = "false";

			std::filesystem::file_time_type ftime = std::filesystem::last_write_time(path);
			std::time_t ftimet = std::chrono::duration_cast<std::chrono::seconds>(ftime.time_since_epoch()).count();

			std::filesystem::file_time_type now = std::filesystem::__file_clock::now();
			std::time_t nowt = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
			
			std::chrono::time_point<std::chrono::system_clock> epoch = std::chrono::system_clock::now();
			std::time_t epocht = std::chrono::duration_cast<std::chrono::seconds>(epoch.time_since_epoch()).count();

			std::time_t fepoch = epocht - nowt + ftimet;

			if(std::filesystem::is_symlink(path)) symlinkstr = "true";

			itvec.push_back(filenamestr);
			itvec.push_back(pathstr);
			itvec.push_back(symlinkstr);
			itvec.push_back(std::to_string(fepoch));

			if(std::filesystem::is_directory(path)){
				dirs->push_back(itvec);
			}else{
				std::uintmax_t size = std::filesystem::file_size(path);
				itvec.push_back(humanSize(size));
				files->push_back(itvec);
			}
		}
	}catch(...){
		return false;
	}
	
	return true;
	
}

static bool olderThan(std::string filepath, int secs ){
	
	std::filesystem::path path(filepath);
    auto now = std::filesystem::file_time_type::clock::now() ;
    
    return std::chrono::duration_cast<std::chrono::seconds>( now - std::filesystem::last_write_time(path) ).count() > secs ;
}


static bool permissionChecker(std::string path, std::string accesstype, std::string useruid, std::string usergid) {
	std::cout << "checking   " << path << "   " << accesstype << std::endl;
	
	struct stat info;
	//const char * charpath = ;
	stat(path.c_str(), &info);
	long uid = std::stol(useruid);
	long gid = std::stol(usergid);
	//struct passwd *pw = getpwuid(info.st_uid);
	//struct group  *gr = getgrgid(info.st_gid);
	//std::string folderowner = pw->pw_name;
	//std::string foldergroup = std::to_string(gr->gr_gid);
	
	// set variables containing the permissions
	std::filesystem::perms folderperms = std::filesystem::status(path).permissions();
	bool ownerallowed, groupallowed, otherallowed;
	
	if (accesstype == "read") {
		// set user, group and others allowed
		if ((folderperms & std::filesystem::perms::owner_read) == std::filesystem::perms::none) {
			ownerallowed = false;
		} else {
			ownerallowed = true;
		}
		if ((folderperms & std::filesystem::perms::group_read) == std::filesystem::perms::none) {
			groupallowed = false;
		} else {
			groupallowed = true;
		}
		if ((folderperms & std::filesystem::perms::others_read) == std::filesystem::perms::none) {
			otherallowed = false;
		} else {
			otherallowed = true;
		}
	} else if (accesstype == "write") {
		// set user, group and others allowed
		if ((folderperms & std::filesystem::perms::owner_write) == std::filesystem::perms::none) {
			ownerallowed = false;
		} else {
			ownerallowed = true;
		}
		if ((folderperms & std::filesystem::perms::group_write) == std::filesystem::perms::none) {
			groupallowed = false;
		} else {
			groupallowed = true;
		}
		if ((folderperms & std::filesystem::perms::others_write) == std::filesystem::perms::none) {
			otherallowed = false;
		} else {
			otherallowed = true;
		}
	} else {
		return false;
	}
	
	// compare loginuser->name and getpwuid->pw_name
	// compare loginuser->gid and getgrgid->gr_gid
	if (ownerallowed && uid == info.st_uid) {
		std::cout << "user allowed" << std::endl;
		return true;
	} else if (groupallowed && gid == info.st_gid) {
		std::cout << "gid allowed" << std::endl;
		return true;
	} else if (otherallowed) {
		std::cout << "other allowed" << std::endl;
		return true;
	}
	
	std::cout << "not allowed" << std::endl;
	return false;
}



#endif

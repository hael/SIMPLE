#ifndef NICETOOLS_H
#define NICETOOLS_H

#include <iostream>
#include <fstream>
#include <vector>
#include <json.hpp>
#include <json_helpers.h>
#include <config.h>
#include <filesystem.h>
#include <jobbuilder.h>
#include <db.h>
#include <sys.h>
#include <workspace.h>
#include <spdlog/spdlog.h>
#include <process.h>
#include <jobtemplate.h>

class NiceTools : public JobBuilder {

	private:
		
	public:
		NiceTools();
		std::vector<int> Queue(std::string type, std::string jobfolder, nlohmann::ordered_json args, int template_id = -1, int parent_jobid = -1, std::string parent_jobfolder = "", std::string comm_addr_str = "", bool local = false);
		nlohmann::ordered_json ProjectHeaderJson(std::string type, std::string path, bool folder = true);
		bool ProjectDataJson(nlohmann::ordered_json* returnjson, std::string type, std::string jobfolder, nlohmann::ordered_json args, bool folder = true);
		nlohmann::ordered_json joblist = {
			{
				{"name", "export_star"},
				{"descr_long",  "export job data in star format for import into other packages"},
				{"descr_short", "export job data in star format"},
				{"advanced", false},
				{"module", "NICE"}
			},
			{
				{"name", "manual_picker"},
				{"descr_long",  "manually pick particles"},
				{"descr_short", "manually pick particles"},
				{"advanced", false},
				{"interactive", true},
				{"module", "NICE"}
			}
		};
		nlohmann::ordered_json jobargs = {
			{"export_star" ,{
				{"resources", {
	      			{
	   					{"key", "nthr"},
	        			{"keytype", "num"},
	        			{"descr_short", "number threads"},
	        			{"descr_long", ""},
	        			{"descr_placeholder", ""},
	        			{"required", true},
	        			{"advanced", false},
	        			{"online", false}
	      			}
				}}
			}},
			{"manual_picker" ,{
				{"resources", {
	      			{
	   					{"key", "nthr"},
	        			{"keytype", "num"},
	        			{"descr_short", "number threads"},
	        			{"descr_long", ""},
	        			{"descr_placeholder", ""},
	        			{"required", true},
	        			{"advanced", false},
	        			{"online", false}
	      			}
				}}
			}},
		};

};

#endif
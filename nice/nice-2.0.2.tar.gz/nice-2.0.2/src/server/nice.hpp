#ifndef NICE
#define NICE

#include <pthread.h>
#include <string>

extern "C" {
    #include "mongoose.h"
}
#include "zlib.h"

#include "json.hpp"
#include "filesystem.hpp"
#include "core.hpp"
#include "handler.hpp"

struct user {
  //const char *name, *pass, *token, *level;
    std::string name;
    std::string pass;
    std::string token;
    std::string level;
};

struct thread_data {
    struct mg_queue queue;  // Worker -> Connection queue
    struct mg_str body;     // Copy of message body
    struct user* user;
    bool headersent = false;
};

#endif

#include "core.hpp"

void Core::collectWorker(){
	while(true){
		usleep(10000000);
		this->logInfo("starting collect worker cycle");
		this->collectCycle();
		this->logInfo("completed collect worker cycle");
	}

}

void Core::collectFail(int jobid){

	std::string sql = "UPDATE jobs SET status='failed' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectFinish(int jobid){

	std::string sql = "UPDATE jobs SET status='finished' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectStopped(int jobid, std::string stopstatus){

	std::string sql = "UPDATE jobs SET status='" + stopstatus + "' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectRunning(int jobid){

	std::string sql = "UPDATE jobs SET status='running' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectProgress(int jobid, int progress){

	std::string sql = "UPDATE jobs SET statuspercent=" + std::to_string(progress) + " WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectStats(int jobid, nlohmann::ordered_json stats){

	std::string sql = "UPDATE jobs SET jobstats='" + stats.dump() + "' WHERE id=" + std::to_string(jobid) + ";";

	if(!this->queryDB(sql)){
		this->logError("dispatchFail : sql query failed");
		return;
	}
}

void Core::collectCycle(){

	std::string sql = "SELECT * FROM jobs WHERE status='submitted' OR status='running' OR status='stopping';";
	
	std::vector<std::map<std::string, std::string>> jobs;

	if(!this->queryDB(sql, &jobs)){
		this->logError("collectCycle : server failed to reply: sql query failed");
		return;
	}

//	std::time_t laststat = std::time(nullptr);

	for(auto &job : jobs){

		if(job.find("id") == job.end()){
			this->logError("collectCycle : id missing for job");
			continue;
		}

		int jobid = std::stoi(job["id"]);

		if(job.find("workspaceid") == job.end()){
			this->logError("collectCycle : workspaceid missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("jobtype") == job.end()){
			this->logError("collectCycle : jobtype missing for job");
			continue;
		}

		if(job["jobtype"] == "link_cryosparc") continue;

		int workspaceid = std::stoi(job["workspaceid"]);

		std::map<std::string, std::string> workspace;

		if(!this->getWorkspace(workspaceid, "", "admin", &workspace)){
			this->logError("collectCycle : failed to retrieve workspace");
			this->collectFail(jobid);
			continue;
		}

		if(workspace.find("project") == workspace.end()){
			this->logError("collectCycle : project missing for workspace");
			this->collectFail(jobid);
			continue;
		}

		int projectid = std::stoi(workspace["project"]);

		std::map<std::string, std::string> project;

		if(!this->getProject(projectid, "", "admin", &project)){
			this->logError("collectCycle : failed to retrieve project");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("subfolder") == job.end()){
			this->logError("collectCycle : subfolder missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("module") == job.end()){
			this->logError("collectCycle : module missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("version") == job.end()){
			this->logError("collectCycle : version missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("jobtype") == job.end()){
			this->logError("collectCycle : jobtype missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("statuscommand") == job.end()){
			this->logError("collectCycle : submitcommand missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("cancelcommand") == job.end()){
			this->logError("collectCycle : cancelcommand missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(job.find("statuspercent") == job.end()){
			this->logError("collectCycle : statuspercent missing for job");
			this->collectFail(jobid);
			continue;
		}

		if(workspace.find("subfolder") == workspace.end()){
			this->logError("collectCycle : subfolder missing for workspace");
			this->collectFail(jobid);
			continue;
		}
		
		if(project.find("folder") == project.end()){
			this->logError("collectCycle : folder missing for project");
			this->collectFail(jobid);
			continue;
		}

		std::string jobfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + job["subfolder"];

		std::string module  = job["module"];
		std::string version = job["version"];
		std::string jobtype = job["jobtype"];
		std::string status  = job["status"];
		std::string cancelcommand = job["cancelcommand"];
		std::string statuscommand = job["statuscommand"];
		
		nlohmann::ordered_json statsjson;

		if(job.find("jobstats") != project.end() && job["jobstats"] != ""){
			std::string stats = job["jobstats"];
			statsjson = nlohmann::ordered_json::parse(job["jobstats"]);
		}else{
			statsjson = {};
		}

		std::time_t starttime = time(0);

		if(job.find("starttime") != job.end()){
			std::istringstream ss(job["starttime"]);
			std::tm t{};
			ss >> std::get_time(&t, "%Y-%m-%d %H:%M:%S");
			if (ss.fail()) {
				this->logError("Failed to parse starttime for job " + std::to_string(jobid));
			}   
			std::time_t starttime = mktime(&t);
		}else{
			this->logError("starttime missing for job " + std::to_string(jobid));
		}

		int statuspercent = std::stoi(job["statuspercent"]);

		if(status == "submitted"){
			if(!folderExists(jobfolder)) continue;
			if(fileExists(jobfolder + "/nice.log") || fileExists(jobfolder + "/nice.error")){
				this->collectRunning(jobid);
				continue;
			}
		} else if(status == "running" || status == "stopping"){
			if(!folderExists(jobfolder)) continue; // should be error!

			if(status == "stopping"){
				if(module == "SIMPLE"){
					this->SIMPLE_jobStop(version, jobtype, jobfolder, cancelcommand, statuscommand, starttime);
				}else if(module == "RELION"){
					this->RELION_jobStop(version, jobtype, jobfolder, cancelcommand, statuscommand, starttime);
				}
			}

			if(status == "running"){
				
				int progress = 0;

				std::string statsdump = statsjson.dump();
				
				if(module == "SIMPLE"){
					if(this->SIMPLE_progress(jobfolder, &progress)){
						if(progress != statuspercent){
							this->collectProgress(jobid, progress);
						}
					}
					if(this->SIMPLE_stats(jobfolder, &statsjson)){
						if(statsjson.dump() != statsdump){
							this->collectStats(jobid, statsjson);
						}
						
					}
				}else if(module == "RELION"){
					if(this->RELION_progress(jobfolder, &progress)){
						if(progress != statuspercent){
							this->collectProgress(jobid, progress);
						}
					}
				}
			}

			if(fileExists(jobfolder + "/nice.exit")){
				std::string buffer;

				std::ifstream exitfile(jobfolder + "/nice.exit");
				getline (exitfile, buffer);
				exitfile.close();
				
				int exitcode = std::stoi(buffer);

				std::string statsdump = statsjson.dump();

				if(exitcode == 0){
					if(status == "stopping"){
						if(module == "SIMPLE"){
							std::string stopstatus;
							if(this->SIMPLE_stopStatus(version, jobtype, &stopstatus)){
								this->collectStopped(jobid, stopstatus);
								if(this->SIMPLE_stats(jobfolder, &statsjson)){
									if(statsjson.dump() != statsdump){
										this->collectStats(jobid, statsjson);
									}
								}
							}else{
								this->collectStopped(jobid);
							}
						}else{
							this->collectStopped(jobid);
						}
					}else{
						if(module == "SIMPLE"){
							if(this->SIMPLE_stats(jobfolder, &statsjson)){
								if(statsjson.dump() != statsdump){
									this->collectStats(jobid, statsjson);
								}
							}
						}else if(module == "RELION"){
							this->RELION_finishJob(jobfolder, jobtype);
							if(this->RELION_stats(jobfolder, &statsjson)){
								if(statsjson.dump() != statsdump){
									this->collectStats(jobid, statsjson);
								}
							}
						}
						this->collectFinish(jobid);
					}
					continue;
				}else if(module == "RELION" && fileExists(jobfolder + "/RELION_JOB_EXIT_SUCCESS")){
					this->RELION_finishJob(jobfolder, jobtype);
					this->collectFinish(jobid);
				}else{
					this->collectFail(jobid);
					continue;
				}
			}else{
				if(fileExists(jobfolder + "/nice.pid")){
					std::string buffer;
					std::ifstream pidfile(jobfolder + "/nice.pid");
					getline (pidfile, buffer);
					pidfile.close();
						
					if(buffer == "") return;

					int pid = std::stoi(buffer);

					// Query status handler

					this->statusAddCommand(statuscommand); // confirm command is in array after restart

					if(this->statusTest(statuscommand, pid, starttime)){
						this->logInfo("job running");
					}else{
						this->logError("job dead");
						if(!fileExists(jobfolder + "/nice.exit")){
							std::ofstream exitfilehandle(jobfolder + "/nice.exit");
							exitfilehandle << 1 << std::endl;
							exitfilehandle.close();
						}
					}
					
				}else{
					this->collectFail(jobid);
				}
			}

		}
		
	}

}
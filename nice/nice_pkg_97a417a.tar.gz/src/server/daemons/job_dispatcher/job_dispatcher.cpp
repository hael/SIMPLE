#include "job_dispatcher.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE

JobDispatcher::JobDispatcher (bool local) {
    // logfile path
    this->logpath = getRootDir() + "/var/log/JobDispatcher.txt";
    // create logger if not already existing
    if(spdlog::get("JobDispatcher") == nullptr){
      auto logger = spdlog::rotating_logger_mt("JobDispatcher", this->logpath, 1048576 * 5, 5);
    }
    this->local = local;
    // start
    this->Start();
    // console log running
    spdlog::get("master")->info("JobDispatcher running. Logs will be written to " + this->logpath);
}

bool JobDispatcher::Status (bool quiet) {
    // current status
    bool thread_status = this->healthy;
    // reset status
    this->healthy = false;
    // log if not healthy and not quiet
    if(!thread_status && !quiet){
        spdlog::get("master")->error("JobDispatcher failed. More details may be found in " + this->logpath);
        spdlog::get("JobDispatcher")->error("JobDispatcher failed. More details may be found in " + this->logpath);
    }
    return thread_status;
}

void JobDispatcher::Stop () {
    // console log stop
    spdlog::get("master")->info("JobDispatcher stopping");
    // send signal
    this->terminate = true;
    // wait for status
    while(this->Status(true)){
        sleep(1);
    }
    // log stopped
    spdlog::get("master")->info("JobDispatcher stopped");
    spdlog::get("JobDispatcher")->info("JobDispatcher stopped");
}

void JobDispatcher::Start () {
    // console log start
    spdlog::get("master")->info("JobDispatcher starting");
    spdlog::get("JobDispatcher")->info("JobDispatcher starting");
    // start daemon thread
    this->terminate = false;
    this->workerthread = std::thread(&JobDispatcher::Worker, this);
    this->workerthread.detach();
}

void JobDispatcher::Worker () {
    while (true){
        this->healthy = true;
        this->Cycle();
        sleep(5);
        if(this->terminate) break;
    }
}

void JobDispatcher::Cycle(){
    //can we combine all these sql calls into 1?
    std::cout << "JobDispatcher::Cycle" << std::endl;
    // get all finished processes
    pqxx::result dispatchable_processes = sql_nontx_result("SELECT id,module,dependentid FROM processes WHERE status='queued' AND startrunning=FALSE AND startuser=FALSE AND dependentid = ANY(SELECT id FROM processes WHERE status='finished');");
    for (pqxx::result::const_iterator dispatchable_process = dispatchable_processes.begin(); dispatchable_process != dispatchable_processes.end(); ++dispatchable_process) {
        if(dispatchable_process[0].is_null() || dispatchable_process[1].is_null()) continue;
        int process_id             = dispatchable_process[0].as<int>();
        std::string process_module = dispatchable_process[1].as<std::string>();
        if(process_module == "SIMPLE"){
            Simple* simple = new Simple();
            simple->Dispatch(process_id, false, this->local);
            delete simple;
        }
        std::cout << process_id << process_module << "dispatchable" << std::endl;
    }

    dispatchable_processes = sql_nontx_result("SELECT id,module,dependentid FROM processes WHERE status='queued' AND startrunning=TRUE AND startuser=FALSE AND dependentid = ANY(SELECT id FROM processes WHERE status='running' OR status='finished');");
    for (pqxx::result::const_iterator dispatchable_process = dispatchable_processes.begin(); dispatchable_process != dispatchable_processes.end(); ++dispatchable_process) {
        if(dispatchable_process[0].is_null() || dispatchable_process[1].is_null()) continue;
        int process_id             = dispatchable_process[0].as<int>();
        std::string process_module = dispatchable_process[1].as<std::string>();
        if(process_module == "SIMPLE"){
            Simple* simple = new Simple();
            simple->Dispatch(process_id, false, this->local);
            delete simple;
        }
        std::cout << process_id << process_module << "dispatchable" << std::endl;
    }

    dispatchable_processes = sql_nontx_result("SELECT id,module,dependentid FROM processes WHERE status='queued' AND startuser=TRUE AND dependentid = ANY(SELECT id FROM processes WHERE status='running' OR status='finished');");
    for (pqxx::result::const_iterator dispatchable_process = dispatchable_processes.begin(); dispatchable_process != dispatchable_processes.end(); ++dispatchable_process) {
        if(dispatchable_process[0].is_null() || dispatchable_process[1].is_null()) continue;
        int process_id             = dispatchable_process[0].as<int>();
        std::string process_module = dispatchable_process[1].as<std::string>();
        if(process_module == "SIMPLE"){
            Simple* simple = new Simple();
            simple->Dispatch(process_id, false, this->local);
            delete simple;
        }
        std::cout << process_id << process_module << "dispatchable" << std::endl;
    }

    dispatchable_processes = sql_nontx_result("SELECT id,module,dependentid FROM processes WHERE status='queued' AND (dependentjobid = -1 OR dependentjobid = ANY(SELECT id FROM jobs WHERE status='finished'));");
    for (pqxx::result::const_iterator dispatchable_process = dispatchable_processes.begin(); dispatchable_process != dispatchable_processes.end(); ++dispatchable_process) {
        if(dispatchable_process[0].is_null() || dispatchable_process[1].is_null()) continue;
        int process_id             = dispatchable_process[0].as<int>();
        std::string process_module = dispatchable_process[1].as<std::string>();
        if(process_module == "SIMPLE"){
            Simple* simple = new Simple();
            simple->Dispatch(process_id, false, this->local);
            delete simple;
        }
        std::cout << process_id << process_module << "dispatchable" << std::endl;
    }

    dispatchable_processes = sql_nontx_result("SELECT id,module,dependentid FROM processes WHERE restart=TRUE AND (status='finished' OR status='failed' OR status='restarting' OR status='stopped');");
    for (pqxx::result::const_iterator dispatchable_process = dispatchable_processes.begin(); dispatchable_process != dispatchable_processes.end(); ++dispatchable_process) {
        if(dispatchable_process[0].is_null() || dispatchable_process[1].is_null()) continue;
        int process_id             = dispatchable_process[0].as<int>();
        std::string process_module = dispatchable_process[1].as<std::string>();
        if(process_module == "SIMPLE"){
            Simple* simple = new Simple();
            simple->Dispatch(process_id, true, this->local);
            delete simple;
        }
        std::cout << process_id << process_module << "dispatchable" << std::endl;
    }

}





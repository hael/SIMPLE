#ifndef JOB_DISPATCHER
#define JOB_DISPATCHER

#include <iostream>
#include <thread>
#include <json.hpp>
#include <db.h>
#include <sys.h>
#include <spdlog/spdlog.h>
#include <simple.h>
#include <spdlog/sinks/rotating_file_sink.h>

extern "C" {
    #include <mongoose.h>
}

class JobDispatcher {

	private:
		bool local;
		std::thread workerthread;
		std::string logpath;
		std::atomic<bool> healthy;
		std::atomic<bool> terminate;
		void Worker();
		void Cycle();

	public:
		JobDispatcher(bool local = false);		
		bool Status(bool quiet = false);
		void Start();
		void Stop();

};

#endif
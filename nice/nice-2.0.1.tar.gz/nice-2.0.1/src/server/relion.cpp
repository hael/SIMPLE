#include "core.hpp"
#include "star.hpp"
#include "relion_tabinfo.hpp" // generated from gui_jobwindow.cpp in relion source using relionsrc2json.py found in helpers
#include "src/pipeline_jobs.h"

bool Core::RELION_test(){
	
	std::string relionpath;
	
	if(!this->getConfigValue ("relionpath", relionpath)){
		this->logError("failed to retrieve relionpath from config. RELION disabled");
		return false;
	}

	if(!folderExists(relionpath)){
		this->logError("relionpath does not exist. RELION disabled");
		return false;
	}

	std::string relionclusterpath;
	
	if(!this->getConfigValue ("relionclusterpath", relionclusterpath)){
		this->logError("failed to retrieve relionclusterpath from config. RELION disabled");
		return false;
	}

	if(relionclusterpath[0] == '/'){
		if(!folderExists(relionclusterpath)){
			this->logError("relionclusterpath does not exist. RELION disabled");
			return false;
		}
	}else{
		if(!folderExists(this->bindir + "/" + relionclusterpath)){
			this->logError("relionclusterpath does not exist. RELION disabled");
			return false;
		}
	}
	
	std::string relionpathbin = relionpath + "/bin/";

	if(!folderExists(relionpathbin)){
		this->logError("bin folder in relionpath does not exist. RELION disabled");
		return false;
	}

	this->logInfo("RELION enabled");
	return true;

}

std::tuple<std::string, std::string> Core::RELION_DataInOut(std::string jobtype){
	
	if(jobtype == "PROC_IMPORT"){
		return std::make_tuple("none", "movies");
	}else if (jobtype == "PROC_MOTIONCORR"){	
		return std::make_tuple("movies", "micrographs");
	}else if (jobtype == "PROC_CTFFIND"    || \
			  jobtype == "PROC_MANUALPICK" || \
			  jobtype == "PROC_AUTOPICK" ){
	  	return std::make_tuple("micrographs", "micrographs");
	}else if (jobtype == "PROC_EXTRACT"){
	  	return std::make_tuple("micrographs", "particles");
	}else if (jobtype == "PROC_2DCLASS"){
	  	return std::make_tuple("particles", "classes");
	}else if (jobtype == "PROC_INIMODEL" || \
			  jobtype == "PROC_3DAUTO"){
	  	return std::make_tuple("particles", "volumes");
	}
	 // NEEDS REST ADDING
	return std::make_tuple("unknown", "unknown");
}

std::string CleanString(std::string str){

	str.erase(str.find_last_not_of(' ')+1);
	str.erase(0, str.find_first_not_of(' '));
	if(str[0] == '"' && str.back() == '"'){
		str = str.substr(1,str.length()-2);
	}

	str.erase(str.find_last_not_of(' ')+1);
	str.erase(0, str.find_first_not_of(' '));

	if(str.back() == ':'){
		str = str.substr(0,str.length()-1);
	}

	return str;

}

bool Core::RELION_getJobs(nlohmann::ordered_json* joblist){	

	std::string relionpath;
	
	if(!this->getConfigValue ("relionpath", relionpath)){
		this->logError("failed to retrieve relionpath from config. RELION disabled");
		return false;
	}

	if(!folderExists(relionpath)){
		this->logError("relionpath does not exist. RELION disabled");
		return false;
	}

	std::string relionpathbin = relionpath + "/bin/";

	if(!folderExists(relionpathbin)){
		this->logError("bin folder in relionpath does not exist. RELION disabled");
		return false;
	}

	nlohmann::ordered_json relionjoblist;

	for (auto it : reliontabinfo){
		nlohmann::ordered_json jobjson = it;
		// store job info
		nlohmann::ordered_json joblistelement;

		if(!jobjson.contains("program") || !jobjson["program"].is_object()){
			continue;
		}

		if(jobjson["program"].contains("name") && jobjson["program"]["name"].is_string()){
			joblistelement["name"] = CleanString(jobjson["program"]["name"].get<std::string>());
		}else{
			continue;
		}

		if(jobjson["program"].contains("displayname") && jobjson["program"]["displayname"].is_string()){
			joblistelement["displayname"] = CleanString(jobjson["program"]["displayname"].get<std::string>());
		}

		if(jobjson["program"].contains("descr_long") && jobjson["program"]["descr_long"].is_string()){
			joblistelement["descr_long"] = CleanString(jobjson["program"]["descr_long"].get<std::string>());
		}else{
			continue;
		}		

		if(jobjson["program"].contains("descr_short") && jobjson["program"]["descr_short"].is_string()){
			joblistelement["descr_short"] = CleanString(jobjson["program"]["descr_short"].get<std::string>());
		}else{
			continue;
		}		
	
		if(jobjson["program"].contains("advanced") && jobjson["program"]["advanced"].is_boolean()){
			joblistelement["advanced"] = jobjson["program"]["advanced"];
		}else{
			continue;
		}

		joblistelement["module"] = "RELION";

		relionjoblist.push_back(joblistelement);
		
	}

	joblist->emplace("jobs", "");
	joblist->at("jobs") = relionjoblist;

	return true;
}

bool Core::RELION_getJobOptions(std::string jobname, nlohmann::ordered_json* joboptions){

	std::string relionpath;
	
	if(!this->getConfigValue ("relionpath", relionpath)){
		this->logError("failed to retrieve relionpath from config. RELION disabled");
		return false;
	}

	if(!folderExists(relionpath)){
		this->logError("relionpath does not exist. RELION disabled");
		return false;
	}

	std::string relionpathbin = relionpath + "/bin/";

	if(!folderExists(relionpathbin)){
		this->logError("bin folder in relionpath does not exist. RELION disabled");
		return false;
	}

	if(!reliontabinfo.contains(jobname) || !reliontabinfo[jobname].is_object()){
		this->logError("program missing from UI");
		return false;
	}

	if(!reliontabinfo[jobname].contains("program") || !reliontabinfo[jobname]["program"].is_object()){
		this->logError("program field missing from UI");
		return false;
	}

	if(!reliontabinfo[jobname]["program"].contains("executable") || !reliontabinfo[jobname]["program"]["executable"].is_string()){
		this->logError("executable field missing from UI");
		return false;
	}

	nlohmann::ordered_json options;

	for (auto it = reliontabinfo[jobname].begin(); it != reliontabinfo[jobname].end(); ++it) {
		nlohmann::ordered_json jobjson = *it;

		if(it.key() != "program"){
			for (auto it2 = jobjson.begin(); it2 != jobjson.end(); ++it2) {
				
				nlohmann::ordered_json sectionjson = *it2;
				std::string guisubmenu = it.key();

				if(sectionjson.contains("gui_submenu") && sectionjson["gui_submenu"].is_string() ){
					guisubmenu = CleanString(sectionjson["gui_submenu"].get<std::string>());
				}

				if(!options.contains(guisubmenu)){
					options[guisubmenu] = {};
				}
				
				bool hidden = false;

				for (auto& option : sectionjson.items()){
					if(option.value().is_string()){
						sectionjson[option.key()] = CleanString(option.value().get<std::string>());
					}
					
					if(option.key() == "key" && option.value() == "fn_img"){
						hidden = true;
					}

				}

				if(hidden){
					sectionjson["keytype"] = "hidden";
					sectionjson["default"] = "NICEPARTICLES";
				}

				options[guisubmenu] += sectionjson;

			}

		}
	}

	if(reliontabinfo[jobname]["program"].contains("mpi") && reliontabinfo[jobname]["program"]["mpi"].is_boolean() && reliontabinfo[jobname]["program"]["mpi"].get<bool>()){
		
		nlohmann::ordered_json mpioption;

		mpioption["key"] = "nr_mpi";
		mpioption["keytype"] = "num";
		mpioption["descr_short"] = "Number of MPI procs";
		mpioption["descr_long"] = "Number of MPI nodes to use in parallel. When set to 1, MPI will not be used";
		mpioption["descr_placeholder"] = "";
		mpioption["required"] = true;
		mpioption["advanced"] = false;
		mpioption["online"] = false;

		if(options.contains("Compute")){
			options["Compute"] += mpioption;
		}else{
			options["compute"] += mpioption;
		}

	}

	if(reliontabinfo[jobname]["program"].contains("threads") && reliontabinfo[jobname]["program"]["threads"].is_boolean() && reliontabinfo[jobname]["program"]["threads"].get<bool>()){
		
		nlohmann::ordered_json threadsoption;

		threadsoption["key"] = "nr_threads";
		threadsoption["keytype"] = "num";
		threadsoption["descr_short"] = "Number of threads";
		threadsoption["descr_long"] = "Number of shared-memory (POSIX) threads to use in parallel. When set to 1, no multi-threading will be used";
		threadsoption["descr_placeholder"] = "";
		threadsoption["required"] = true;
		threadsoption["advanced"] = false;
		threadsoption["online"] = false;

		if(options.contains("Compute")){
			options["Compute"] += threadsoption;
		}else{
			options["compute"] += threadsoption;
		}

	}

	nlohmann::ordered_json clusters;

	clusters["key"] = "nicecluster";
	clusters["keytype"] = "multi";
	clusters["descr_short"] = "cluster";
	clusters["descr_long"] = "cluster to submit processes to";
	clusters["descr_placeholder"] = "";
	clusters["required"] = true;
	clusters["advanced"] = false;
	clusters["online"] = false;
	clusters["options"] = {};

	nlohmann::ordered_json clusterlist;

	this->RELION_getClusters(&clusterlist);

	if(clusterlist.contains("clusters") && clusterlist["clusters"].is_array()){
		for(auto cluster : clusterlist["clusters"]){
			if(cluster.contains("name") && cluster["name"].is_string()
			&& cluster.contains("template") && cluster["template"].is_string()){
				clusters["options"] += cluster["name"].get<std::string>();
			}
		}
	}
	
	if(options.contains("Compute")){
		options["Compute"] += clusters;
	}

	std::string executable = reliontabinfo[jobname]["program"]["executable"].get<std::string>();

	joboptions->emplace("executable", executable);

	if(reliontabinfo[jobname]["program"].contains("id") && reliontabinfo[jobname]["program"]["id"].is_number_integer()){
		joboptions->emplace("programid", reliontabinfo[jobname]["program"]["id"].get<int>());
	}

	joboptions->emplace("options", "");
	joboptions->at("options") = options;
		
	return true;
}

bool Core::RELION_workspaceInit(std::string path){

	this->logInfo("RELION workspace initiated");
	return true;
}

void Core::RELION_cleanup(std::string version){
	
	
}

bool Core::RELION_jobInit(std::string version, std::string type, int jobtypeid, std::string jobfolder, std::string clustertemplate, nlohmann::ordered_json jobargs, std::string parentsubfolder){

	std::string filledtemplate;

	if(!this->RELION_fillTemplate(clustertemplate, type, jobtypeid, jobargs, jobfolder, parentsubfolder, &filledtemplate)){
		this->logError("RELION_jobInit: failed to substitute template");
		return false;
	}

	std::string scriptfile = jobfolder + "/nice.script";

	std::ofstream scriptfilehandle(jobfolder + "/nice.script");
	scriptfilehandle << filledtemplate << std::endl;
	scriptfilehandle.close();

	chmod(scriptfile.c_str(), S_IRWXU);

	return true;
}

bool Core::RELION_fillTemplate(std::string clustertemplate, std::string prg, int jobtypeid, nlohmann::ordered_json jobargs, std::string jobfolder, std::string parentsubfolder, std::string* returnstring){

	std::string relionpath;
	
	if(!this->getConfigValue ("relionpath", relionpath)){
		this->logError("failed to retrieve relionpath from config");
		return false;
	}

	if(!folderExists(relionpath)){
		this->logError("relionpath does not exist");
		return false;
	}

	std::string relionpathbin = relionpath + "/bin/";

	if(!folderExists(relionpathbin)){
		this->logError("bin folder in relionpath does not exist");
		return false;
	}

	if(!jobargs.is_object()){
		this->logError("RELION_fillTemplate: arguments is not an object");
		return false;
	}

	std::string commandstring;

	commandstring += '\n';

	if(jobargs.contains("niceselection")){

		if(!jobargs["niceselection"].is_string()){
			this->logError("relion_fillTemplate: niceselection is not a string");
			return false;
		}

		std::string niceselection = jobargs["niceselection"].get<std::string>();

		if(!fileExists(niceselection)){
			this->logError("RELION_fillTemplate: niceselection does not exist");
			return false;
		}

		std::string inputstar;

		if(fileExists(parentPath(jobfolder) + "/" + parentsubfolder + "/particles3D.star")){
			inputstar = parentPath(jobfolder) + "/" + parentsubfolder + "/particles3D.star";
		}else if(fileExists(parentPath(jobfolder) + "/" + parentsubfolder + "/particles2D.star")){
			inputstar = parentPath(jobfolder) + "/" + parentsubfolder + "/particles2D.star";
		}else{
			this->logError("RELION_fillTemplate: inputstar does not exist");
			return false;
		}
		commandstring += "export PATH=" + relionpathbin + ":$PATH";
		commandstring += '\n';
		commandstring += "{";
		commandstring += '\n';
		commandstring += "mv " + niceselection + " nice_selection.tmp";
		commandstring += " && ";
		commandstring += "`which relion_star_handler` --i " + inputstar + " --i_tablename data_particles --select rlnClassNumber --maxval 0 --o optics.tmp";
		commandstring += " && ";
		commandstring += "cat optics.tmp nice_selection.tmp > nice_selection.star";
		commandstring += " && ";
		commandstring += "`which relion_star_handler` --i " + inputstar + " --compare nice_selection.star --label1 rlnClassNumber --i_tablename particles --o particles2D.star";
		commandstring += " && ";
		commandstring += "mv particles2D_both.star particles2D.star";
		commandstring += " && ";
		commandstring += "rm optics.tmp nice_selection.tmp nice_selection.star particles2D_only1.star particles2D_only2.star";

		if(fileExists(parentPath(jobfolder) + "/" + parentsubfolder + "/clusters2D.star")){

			nlohmann::ordered_json clustersstar = readSTAR(parentPath(jobfolder) + "/" + parentsubfolder + "/clusters2D.star");

			if(clustersstar.contains("data_model_classes") && clustersstar["data_model_classes"].is_object() && clustersstar["data_model_classes"].contains("loop") 
			&& clustersstar["data_model_classes"]["loop"].is_array() && clustersstar["data_model_classes"]["loop"].size() > 0){
				
				nlohmann::ordered_json selection = readSTAR(niceselection);
				
				if(selection.contains("data_particles") && selection["data_particles"].is_object() && selection["data_particles"].contains("loop") 
				&& selection["data_particles"]["loop"].is_array() && selection["data_particles"]["loop"].size() > 0
				&& selection["data_particles"]["loop"][0].contains("_rlnClassNumber")){

					clustersstar["data_model_classes"]["loopbak"] = clustersstar["data_model_classes"]["loop"];
					clustersstar["data_model_classes"]["loop"].clear();

					for(auto selected : selection["data_particles"]["loop"]){

						int classid = std::stoi(selected["_rlnClassNumber"].get<std::string>()) - 1;
						if(classid >= clustersstar["data_model_classes"]["loopbak"].size()){
							this->logError("RELION_fillTemplate: classid out of range");
							return false;
						}

						clustersstar["data_model_classes"]["loop"] += clustersstar["data_model_classes"]["loopbak"][classid];

					}
					clustersstar["data_model_classes"].erase("loopbak");

					srand (time(NULL)); // add some entropy
	
					std::string clustersfile = "/tmp/nice.class." + std::to_string(rand() % 1000);

					if(!writeSTAR(clustersfile, clustersstar)){
						return false;
					}
					commandstring += " && ";
					commandstring += "cp " + clustersfile + " clusters2D.star";
				}
			}
		}
		commandstring += '\n';
		commandstring += "} > nice.log 2> nice.error";
		commandstring += '\n';

	}else{

		if(jobtypeid == -1){
			this->logError("RELION_fillTemplate: jobtypeid id not set");
			return false;
		}

		RelionJob* relionjob = new RelionJob();

		relionjob->initialise(jobtypeid);

		std::string outputname;
		std::string final_command;
		std::string error_message;
		std::vector<std::string> commands;
	    int job_counter;

	    outputname = basename(jobfolder) + "/";

	    for (auto it = jobargs.begin(); it != jobargs.end(); ++it){
			
			std::string key = it.key();
			std::string value = it.value();
			
			if(key != "nicecluster" && key != "niceexec" && key != "niceselection"){
				if(value == "yes"){
					relionjob->joboptions[key].value = "Yes";
				}else if(value == "no"){
					relionjob->joboptions[key].value = "No";
				}else{
					relionjob->joboptions[key].value = value;
				}
				
			}

			if(value == "NICEPARTICLES"){ 
				if(fileExists(parentPath(jobfolder) + "/" + parentsubfolder + "/particles3D.star")){
					relionjob->joboptions[key].value = parentPath(jobfolder) + "/" + parentsubfolder + "/particles3D.star";
				}else if(fileExists(parentPath(jobfolder) + "/" + parentsubfolder + "/particles2D.star")){
					relionjob->joboptions[key].value = parentPath(jobfolder) + "/" + parentsubfolder + "/particles2D.star";
				}
			}

		}

		if(!relionjob->getCommands(outputname, commands, final_command, false, job_counter, error_message)){
			this->logError("RELION_fillTemplate: " + error_message);
			delete relionjob;
			return false;
		}

		final_command = CleanString(final_command);

		std::string outfile = outputname + "run.out";
		std::size_t foundout = final_command.find(outfile);

	    if (foundout != std::string::npos){
			final_command.replace(foundout, outfile.size(), outputname + "nice.log");
		}

		std::string errfile = outputname + "run.err";
		std::size_t founderr = final_command.find(errfile);

	    if (founderr != std::string::npos){
			final_command.replace(founderr, errfile.size(), outputname + "nice.error");
		}

		if(final_command.back() == '&'){
			final_command = final_command.substr(0,final_command.length()-1);
		}

		commandstring += "export PATH=" + relionpathbin + ":$PATH";
		commandstring += '\n';
		commandstring += "cd ..";
		commandstring += '\n';
		commandstring += final_command;
		commandstring += '\n';

		delete relionjob;
	}

	commandstring += "echo $? > nice.exit";

	std::ifstream clusterfile(clustertemplate);

	if(!clusterfile){
		this->logError("RELION_fillTemplate: failed to open template");
		return false;
	}

 	std::ostringstream clusterfiless;
    
    clusterfiless << clusterfile.rdbuf();

    std::string templatestring = clusterfiless.str();
	
	clusterfile.close();

	std::string replacestring = "XXXNICEXXX";

	templatestring.replace(templatestring.find(replacestring), replacestring.size(), commandstring);

	returnstring->assign(templatestring);

	return true;
	
}

void Core::RELION_getClusters(nlohmann::ordered_json* clusterlist){

	std::string relionclusterpath;
	
	if(!this->getConfigValue ("relionclusterpath", relionclusterpath)){
		this->logError("RELION_getClusters: failed to retrieve relionclusterpath from config");
		return;
	}
	std::vector<std::string> clusters;

	if(relionclusterpath[0] == '/'){
		if(!folderExists(relionclusterpath)){
			this->logError("RELION_getClusters: relionclusterpath does not exist");
			return;
		}
		clusters = findFiles(relionclusterpath, std::regex(".*cluster"));

	}else{
		if(!folderExists(this->bindir + "/" + relionclusterpath)){
			this->logError("RELION_getClusters: relionclusterpath does not exist. RELION disabled");
			return ;
		}
		clusters = findFiles(this->bindir + "/" + relionclusterpath, std::regex(".*cluster"));
	}

	if(clusters.size() == 0){
		this->logError("RELION_getClusters: no cluster definitions in relionclusterpath. RELION disabled");
		return;
	}

	nlohmann::ordered_json clustersjson;
	clustersjson = {};

	std::string clusternamecomment   = "#NICE clustername";
	std::string submitcommandcomment = "#NICE submitcommand";
	std::string cancelcommandcomment = "#NICE cancelcommand";
	std::string statuscommandcomment = "#NICE statuscommand";
	std::string defaultcomment 	     = "#NICE defaultcluster";
	std::string replacestring 	     = "XXXNICEXXX";

	for(auto cluster : clusters){
		std::string buffer;
		bool defaultcluster = false;
		bool replacepresent = false;
		nlohmann::ordered_json clusterjson;
		
		clusterjson["template"] = cluster;

		std::ifstream clusterfile(cluster);

		while (getline (clusterfile, buffer)) {

			if(buffer.find(clusternamecomment) != std::string::npos){
				clusterjson["name"] = buffer.substr(buffer.find(clusternamecomment) + clusternamecomment.size() + 1);
			}else if(buffer.find(submitcommandcomment) != std::string::npos){
				clusterjson["submitcommand"] = buffer.substr(buffer.find(submitcommandcomment) + submitcommandcomment.size() + 1);
			}else if(buffer.find(cancelcommandcomment) != std::string::npos){
				clusterjson["cancelcommand"] = buffer.substr(buffer.find(cancelcommandcomment) + cancelcommandcomment.size() + 1);
			}else if(buffer.find(statuscommandcomment) != std::string::npos){
				clusterjson["statuscommand"] = buffer.substr(buffer.find(statuscommandcomment) + statuscommandcomment.size() + 1);
			}else if(buffer.find(defaultcomment) != std::string::npos){
				defaultcluster = true;
			}else if(buffer.find(replacestring) != std::string::npos){
				replacepresent = true;
			}
		}

		clusterfile.close();

		if(!replacepresent){
			this->logError("RELION_getClusters: " + replacestring + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("name") && !clusterjson["name"].is_string()){
			this->logError("RELION_getClusters: " + clusternamecomment + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("submitcommand") && !clusterjson["submitcommand"].is_string()){
			this->logError("RELION_getClusters: " + submitcommandcomment + " missing from cluster " + cluster );
			continue;
		}
		
		if(!clusterjson.contains("cancelcommand") && !clusterjson["cancelcommand"].is_string()){
			this->logError("RELION_getClusters: " + cancelcommandcomment + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("statuscommand") && !clusterjson["statuscommand"].is_string()){
			this->logError("RELION_getClusters: " + statuscommandcomment + " missing from cluster " + cluster );
			continue;
		}

		if(defaultcluster){
			clustersjson.insert(clustersjson.begin(), clusterjson);
		}else{
			clustersjson += clusterjson;
		}
	
	}

	clusterlist->emplace("clusters", "");
	clusterlist->at("clusters") = clustersjson;

}

void Core::RELION_jobStop(std::string version, std::string type, std::string jobfolder, std::string cancelcommand, std::string statuscommand, std::time_t starttime){
	
	if(fileExists(jobfolder + "/nice.pid")){

		std::string buffer;
		std::ifstream pidfile(jobfolder + "/nice.pid");
		getline (pidfile, buffer);
		pidfile.close();
			
		if(buffer == "") return;

		int pid = std::stoi(buffer);

		this->statusAddCommand(statuscommand); // confirm command is in array after restart

		if(this->statusTest(statuscommand, pid, starttime)){
			this->logInfo("RELION job running");
		}else{
			this->logError("RELION job already dead");
			if(!fileExists(jobfolder + "/nice.exit")){
				std::ofstream exitfilehandle(jobfolder + "/nice.exit");
				exitfilehandle << 1 << std::endl;
				exitfilehandle.close();
			}
			return;
		}

		std::string killcommand = cancelcommand + " " + std::to_string(pid);

		FILE* killcmd = popen(killcommand.c_str(), "r");

		int killexitcode = WEXITSTATUS(pclose(killcmd));

		if(killexitcode == 0){
			this->logInfo("RELION job killed");
			std::ofstream exitfilehandle(jobfolder + "/nice.exit");
			exitfilehandle << 1 << std::endl;
			exitfilehandle.close();
		}else{
				this->logError("failed to kill RELION job. marking as dead");
				std::ofstream exitfilehandle(jobfolder + "/nice.exit");
				exitfilehandle << 1 << std::endl;
				exitfilehandle.close();
		}	
	}

}

void Core::RELION_finishJob(std::string jobfolder, std::string jobtype){

	std::vector<std::vector<std::string>> dirs;
	std::vector<std::vector<std::string>> files;

	int maxit = -1;
	std::string maxitstr;

	if(lsDir(jobfolder, &dirs, &files)){
		for(auto fileinfo : files){
			std::string::size_type runpos = fileinfo[0].find("run_it");
			if(runpos != std::string::npos){
				std::string itstr = fileinfo[0].substr(runpos + 6, 3);
				int it = std::stoi(itstr);
				if(it > maxit){
					maxit = it;
					maxitstr = itstr;
				}
			}
		}
	}

	if(maxit == -1) return;

	if(jobtype == "Class2D"){
		if(fileExists(jobfolder + "/run_it" + maxitstr + "_model.star") && ! fileExists(jobfolder + "/clusters2D.star")){
			copyFile(jobfolder + "/run_it" + maxitstr + "_model.star", jobfolder + "/clusters2D.star");
		}
		if(fileExists(jobfolder + "/run_it" + maxitstr + "_data.star") && ! fileExists(jobfolder + "/particles2D.star")){
			copyFile(jobfolder + "/run_it" + maxitstr + "_data.star", jobfolder + "/particles2D.star");
		}
	}else{
		if(fileExists(jobfolder + "/run_it" + maxitstr + "_model.star") && ! fileExists(jobfolder + "/clusters3D.star")){
			copyFile(jobfolder + "/run_it" + maxitstr + "_model.star", jobfolder + "/clusters3D.star");
		}
		if(fileExists(jobfolder + "/run_it" + maxitstr + "_data.star") && ! fileExists(jobfolder + "/particles3D.star")){
			copyFile(jobfolder + "/run_it" + maxitstr + "_data.star", jobfolder + "/particles3D.star");
		}
	}


}

void Core::RELION_images(std::string version, std::string type, nlohmann::ordered_json* returnjson){

	nlohmann::ordered_json images;
	images = {};

	if(returnjson->contains("nmics")){
		
		nlohmann::ordered_json imagejson;
		/*
		imagejson["key"] = "_rlnMicrographName";
		imagejson["visible"] = true;
		images += imagejson;

		imagejson["key"] = "_rlnCtfPowerSpectrum";
		imagejson["visible"] = true;
		images += imagejson;

		imagejson["key"] = "_rlnMicrographCoordinates";
		imagejson["visible"] = true;
		images += imagejson;

		returnjson->at("keys").emplace("_splSpecPrePost", "string");
		imagejson["key"] = "_splSpecPrePost";
		imagejson["visible"] = false;
		images += imagejson;

		imagejson["key"] = "_rlnReferenceImage";
		imagejson["visible"] = true;
		images += imagejson;*/

	}else if(returnjson->contains("ncls")){
		
		nlohmann::ordered_json imagejson;
		
		imagejson["key"] = "_rlnReferenceImage";
		imagejson["visible"] = true;
		images += imagejson;

	}

	returnjson->at("images") = images;

}
/*
void Core::RELION_paths(std::string version, std::string type, std::string key, nlohmann::ordered_json stringpath, nlohmann::ordered_json* datajson){
	
	std::string intgsuffix  = "_intg.mrc";
	std::string thumbsuffix = "_thumb.jpg";
	
	if(type == "preprocess_stream" || type == "preprocess_stream_dev"){
		
		if(key == "_rlnMicrographName"){

			std::string filename = stringpath["arr"][1];

			filename.replace(filename.find(intgsuffix), intgsuffix.size(), thumbsuffix);

			stringpath["arr"][1] = filename;
			stringpath["arr"][2] = 0;
			stringpath["arr"][3] = 1;
			stringpath["arr"][4] = 2;

			if(!datajson->contains("_rlnMicrographName")){
				datajson->emplace("_rlnMicrographName", nlohmann::json::array());
			} 

			datajson->at("_rlnMicrographName") += stringpath["arr"];


			if(!datajson->contains("_splSpecPrePost")){
				datajson->emplace("_splSpecPrePost", nlohmann::json::array());
			} 

			stringpath["arr"][3] = 0;

			datajson->at("_splSpecPrePost") += stringpath["arr"];

		}else{
			if(!datajson->contains(key)){
				datajson->emplace(key, nlohmann::json::array());
			}
			datajson->at(key) += stringpath["arr"];
		}

	}else{
		if(!datajson->contains(key)){
			datajson->emplace(key, nlohmann::json::array());
		}
		datajson->at(key) += stringpath["arr"];
	}

}
/*
int Core::RELION_micsptcls(std::string version, nlohmann::ordered_json* micsstar){
	
	int returnval = 0;

	if(micsstar->contains("data_micrographs") && micsstar->at("data_micrographs").is_object()
    && micsstar->at("data_micrographs").contains("loop") && micsstar->at("data_micrographs")["loop"].is_array()
    && micsstar->at("data_micrographs")["loop"].size() > 0 && micsstar->at("data_micrographs")["loop"][0].contains("_splNumberParticles")){

		for(auto mic : micsstar->at("data_micrographs")["loop"]){
			int numptcls = std::stoi(mic["_splNumberParticles"].get<std::string>());
			returnval += numptcls;
		}

	}

	return returnval;
}
*/
int Core::RELION_cls2Dptcls(std::string version, std::string filename, nlohmann::ordered_json* cls2Dstar){
	
	std::string ptclsname = parentPath(filename) + "/particles2D.star";
	
	int returnval = 0;

	if(fileExists(ptclsname)){

		nlohmann::ordered_json ptcls2Dstar = readSTAR(ptclsname);

		if(ptcls2Dstar.contains("data_particles") && ptcls2Dstar.at("data_particles").is_object()
    	&& ptcls2Dstar.at("data_particles").contains("loop") && ptcls2Dstar.at("data_particles")["loop"].is_array()){
			returnval = ptcls2Dstar.at("data_particles")["loop"].size();
    	}
	}

	if(cls2Dstar->contains("data_clusters") && cls2Dstar->at("data_clusters").is_object()
    && cls2Dstar->at("data_clusters").contains("loop") && cls2Dstar->at("data_clusters")["loop"].is_array()
	&& cls2Dstar->at("data_clusters")["loop"].size() > 0 && cls2Dstar->at("data_clusters")["loop"][0].contains("_rlnClassDistribution")){
		
		for(int i = 0; i < cls2Dstar->at("data_clusters")["loop"].size(); i++){
			float dist = std::stof(cls2Dstar->at("data_clusters")["loop"][i]["_rlnClassDistribution"].get<std::string>());
			int numptcls = std::round(dist * returnval);
			cls2Dstar->at("data_clusters")["loop"][i]["_rlnClassDistribution"] = std::to_string(numptcls);
		}

	}

	return returnval;
}

int Core::RELION_cls2Dclsall(std::string version, nlohmann::ordered_json* cls2Dstar){
	
	int returnval = 0;

	if(cls2Dstar->contains("data_clusters") && cls2Dstar->at("data_clusters").is_object()
    && cls2Dstar->at("data_clusters").contains("loop") && cls2Dstar->at("data_clusters")["loop"].is_array()){
		returnval = cls2Dstar->at("data_clusters")["loop"].size();
	}

	return returnval;
}
/*
int Core::SIMPLE_micsall(std::string version, nlohmann::ordered_json* micsstar){
	
	int returnval = 0;

	if(micsstar->contains("data_micrographs") && micsstar->at("data_micrographs").is_object()
    && micsstar->at("data_micrographs").contains("loop") && micsstar->at("data_micrographs")["loop"].is_array()
    && micsstar->at("data_micrographs")["loop"].size() > 0 && micsstar->at("data_micrographs")["loop"][0].contains("_splNMics")){

		returnval = std::stoi(micsstar->at("data_micrographs")["loop"][0]["_splNMics"].get<std::string>());

	}

	return returnval;
}
*/
bool Core::RELION_suggestChild(std::string version, std::string jobtype, std::vector<std::map<std::string, std::string>> parent, std::string* suggestedjobtype, std::string* suggestedjobname){

	if(jobtype == "selection"){
		if(parent[0].find("suggested") != parent[0].end()){
			suggestedjobtype->assign("'" + parent[0]["suggested"] + "'");
		}else{
			return false;
		}
		if(parent[0].find("suggestedname") != parent[0].end()){
			suggestedjobname->assign("'" + parent[0]["suggestedname"] + "'");
		}else{
			return false;
		}
		return true;
	}else if(jobtype == "Class2D"){
		suggestedjobtype->assign("'Inimodel'");
		suggestedjobname->assign("'Inimodel'");
		return true;
	}else if(jobtype == "Inimodel"){
		suggestedjobtype->assign("'Class3D'");
		suggestedjobname->assign("'3D'");
		return true;
	}

	// need to work on this

	return false;

}

bool Core::RELION_selectionInit(nlohmann::json* requestjson){
	
	srand (time(NULL)); // add some entropy
	
	std::string selectionfile = "/tmp/nice.selection." + std::to_string(rand() % 1000);

	nlohmann::ordered_json selectionstar = {};

	nlohmann::json arguments = {};

	arguments["nicecluster"]   = "default";
	arguments["niceselection"] = selectionfile;

	if(requestjson->at("datatype").get<std::string>() == "cls2D"){

		selectionstar["data_particles"] = {};

		selectionstar["data_particles"]["loop"] = {};
		
		for (int i = 0; i < requestjson->at("selection").size(); i++){
			if(requestjson->at("selection")[i].get<int>() > 1){
				nlohmann::ordered_json classline = {};
				classline["_rlnClassNumber"] = std::to_string(requestjson->at("selectionmap")[i].get<int>() + 1);
				selectionstar["data_particles"]["loop"] += classline;
			}
		}

		if(!writeSTAR(selectionfile, selectionstar)){
			return false;
		}


	}else if(requestjson->at("datatype").get<std::string>() == "mics"){
	/*	arguments["oritype"] = "mic";
		
		std::ofstream selectionfilehandle(selectionfile);

		int nall = requestjson->at("nall").get<int>();

		std::vector<int> selection(nall, 0);

		for (int i = 0; i < requestjson->at("selection").size(); i++){
			if(requestjson->at("selection")[i].get<int>() > 1){
				selection[requestjson->at("selectionmap")[i].get<int>()] = 1;
			}else{
				selection[requestjson->at("selectionmap")[i].get<int>()] = 0;
			}
		}

		for(auto sel : selection){
			selectionfilehandle << sel << std::endl;
		}

		selectionfilehandle.close();*/
	}
	requestjson->emplace("type", "selection");
	requestjson->emplace("jobname", "");
	requestjson->emplace("executable","relion_star_handler");
	requestjson->emplace("arguments", arguments);

	return true;

}

bool Core::RELION_progress(std::string jobfolder, int* progress){
	

	return false;

}

bool Core::RELION_stats(std::string jobfolder, nlohmann::ordered_json* stats){

	bool returnval = false;

	return returnval;
}
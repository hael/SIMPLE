/*
 * This utility was visciosly stolen from stackoverflow.
 * It was graciously posted by aaa on 17 Feb 2010.
 * http://stackoverflow.com/questions/2285185/easiest-way-to-test-for-existence-of-cuda-capable-gpu-from-cmake
 */
#include <stdlib.h> 
#include <stdio.h> 
#include <cuda.h> 
#include <cuda_runtime.h> 
 
int main(int argc, char** argv) { 
  int ct=0;
  int dev=0; 
  cudaError_t code; 
  struct cudaDeviceProp prop; 
 
 cudaGetDeviceCount(&ct); 
 code = cudaGetLastError(); 
 if(code)  printf("%s\n", cudaGetErrorString(code)); 
 
 
if(ct == 0) { 
   printf("Cuda device not found.\n"); 
   exit(0); 
} 
 printf("Found %i Cuda device(s).\n",ct); 
 
for (dev = 0; dev < ct; ++dev) { 
printf("Cuda device %i\n", dev); 
 
cudaGetDeviceProperties(&prop,dev); 
printf("\tname : %s\n", prop.name); 
 printf("\ttotalGlobablMem: %lu\n", (unsigned long)prop.totalGlobalMem); 
printf("\tsharedMemPerBlock: %i\n", prop.sharedMemPerBlock); 
printf("\tregsPerBlock: %i\n", prop.regsPerBlock); 
printf("\twarpSize: %i\n", prop.warpSize); 
printf("\tmemPitch: %i\n", prop.memPitch); 
printf("\tmaxThreadsPerBlock: %i\n", prop.maxThreadsPerBlock); 
printf("\tmaxThreadsDim: %i, %i, %i\n", prop.maxThreadsDim[0], prop.maxThreadsDim[1], prop.maxThreadsDim[2]); 
printf("\tmaxGridSize: %i, %i, %i\n", prop.maxGridSize[0], prop.maxGridSize[1], prop.maxGridSize[2]); 
printf("\tclockRate: %i\n", prop.clockRate); 
printf("\ttotalConstMem: %i\n", prop.totalConstMem); 
printf("\tmajor: %i\n", prop.major); 
printf("\tminor: %i\n", prop.minor); 
printf("\ttextureAlignment: %i\n", prop.textureAlignment); 
printf("\tdeviceOverlap: %i\n", prop.deviceOverlap); 
printf("\tmultiProcessorCount: %i\n", prop.multiProcessorCount); 
} 
} 


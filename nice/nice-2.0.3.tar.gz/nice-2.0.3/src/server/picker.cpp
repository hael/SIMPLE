#include "handler.hpp"
#include "star.hpp"

void Handler::CreateNicePicker(struct thread_data* d, nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;
	std::string returnstring;
	std::vector<std::uint8_t> msgpack ;
	char *queueptr;
	size_t msglen;
	
	returnstring = "M";
	mg_queue_printf(&d->queue, returnstring.c_str());
	d->headersent = true;

	if(!requestjson->contains("module")){
		this->core->logError("CreateNicePicker : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("CreateNicePicker : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("type")){
		this->core->logError("CreateNicePicker : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string module     (requestjson->at("module").get<std::string>());
	std::string version    (requestjson->at("version").get<std::string>());
	std::string jobtype    (requestjson->at("type").get<std::string>());

	returnjson = this->CreateInteractiveJob(requestjson);

	if(returnjson["success"] == false){
		this->core->logError("CreateNicePicker : server failed to reply: failed to create job");
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string filename = returnjson["jobfolder"].get<std::string>() + "/micrographs.star";

	if(fileExists(returnjson["parentfolder"].get<std::string>() + "/micrographs.star")){
		copyFile(returnjson["parentfolder"].get<std::string>() + "/micrographs.star", filename);
	}

	requestjson->emplace("jobid", returnjson["jobid"]);

	this->ShowNicePicker(d, requestjson);
}

void Handler::ShowNicePicker(struct thread_data* d, nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;
	std::string returnstring;
	std::vector<std::uint8_t> msgpack ;
	char *queueptr;
	size_t msglen;
	
	if(d->headersent == false){
		returnstring = "M";
		mg_queue_printf(&d->queue, returnstring.c_str());
	}

	if(!requestjson->contains("module")){
		this->core->logError("ShowNicePicker : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("ShowNicePicker : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("type")){
		this->core->logError("ShowNicePicker : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("ShowNicePicker : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("ShowNicePicker : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("ShowNicePicker : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("ShowNicePicker : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("ShowNicePicker : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("ShowNicePicker : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("ShowNicePicker : server failed to reply: jobid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not an integer";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("ShowNicePicker : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("ShowNicePicker : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string module     (requestjson->at("module").get<std::string>());
	std::string version    (requestjson->at("version").get<std::string>());
	std::string jobtype    (requestjson->at("type").get<std::string>());

	int jobid       = requestjson->at("jobid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();

	std::map<std::string, std::string> workspace;

	if(!this->core->getWorkspace(workspaceid, "", "admin", &workspace)){
		this->core->logError("ShowNicePicker : failed to retrieve workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::map<std::string, std::string> project;

	if(!this->core->getProject(projectid, "", "admin", &project)){
		this->core->logError("ShowNicePicker : failed to retrieve project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retrieve project";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(workspace.find("subfolder") == workspace.end()){
		this->core->logError("ShowNicePicker : subfolder missing for workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: subfolder missing for workspace";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}
	
	if(project.find("folder") == project.end()){
		this->core->logError("ShowNicePicker : folder missing for project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing for project";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string subfolder = std::to_string(jobid) + "_" + jobtype;
	std::string jobfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + subfolder;
	std::string filename = jobfolder + "/micrographs.star";

	if(!fileExists(filename)){
		this->core->logError("ShowNicePicker : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	nlohmann::ordered_json micsstar = readSTAR(filename);

	nlohmann::ordered_json globaljson;

	globaljson["jobdir"]   = jobfolder;
	globaljson["starfile"] = filename;

	if(micsstar.contains("data_optics") && micsstar["data_optics"].is_object() 
    && micsstar["data_optics"].contains("loop") && micsstar["data_optics"]["loop"].is_array() ){
		globaljson["optics"] = micsstar["data_optics"]["loop"];
	}

	if(micsstar.contains("data_micrographs") && micsstar["data_micrographs"].is_object() 
    && micsstar["data_micrographs"].contains("loop") && micsstar["data_micrographs"]["loop"].is_array() 
    && micsstar["data_micrographs"]["loop"].size() > 0){
    	globaljson["keys"] = {};
    	for (auto& el : micsstar["data_micrographs"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}

	if(!globaljson["keys"].contains("_rlnMicrographCoordinates")){
		globaljson["keys"]["_rlnMicrographCoordinates"] = "string";
	}

	if(!globaljson["keys"].contains("_splNumberParticles")){
		globaljson["keys"]["_splNumberParticles"] = "integer";
	}

	globaljson["nmics"] = micsstar["data_micrographs"]["loop"].size();

	if(module == "SIMPLE"){
		int nptcls = this->core->SIMPLE_micsptcls(version, &micsstar);
		if(nptcls > 0){
			globaljson["nptcls"] = nptcls;
		}
		int nmicsall = this->core->SIMPLE_micsall(version, &micsstar);
		if(nmicsall > 0){
			globaljson["nall"] = nmicsall;
		}
	}

	globaljson["paths"] = {};

	msgpack = nlohmann::json::to_msgpack(globaljson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();

	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	int chunksize = 50;

	int miccount  = 0;

	nlohmann::ordered_json pagejson;

	pagejson["startit"] = {};
	pagejson["paths"] = {};
	pagejson["data"] = {};

	for(auto mic : micsstar["data_micrographs"]["loop"]){

		if(miccount > 0 && miccount%chunksize == 0){
			pagejson["paths"] = globaljson["paths"];
			pagejson["endit"] = miccount;
			msgpack = nlohmann::json::to_msgpack(pagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();
			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);
			pagejson["data"] = {};
			pagejson["paths"] = {};
		}

		for (auto& el : mic.items()){
			
			std::string key = el.key();
			std::string value = el.value();

			if(globaljson["keys"][key] == "integer"){
				pagejson["data"][key] += std::stoi(value);
			}else if(globaljson["keys"][key] == "float"){
				pagejson["data"][key] += std::stof(value);
			}else{ //string
				if(value[0] != '/'){
					value = parentPath(parentPath(filename)) + "/" + value;
				}
				std::string parentpath = parentPath(value);
			 	auto findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				if(findpath == globaljson["paths"].end()){
					globaljson["paths"] += parentpath;
					findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				}

				nlohmann::ordered_json stringpath;
				stringpath["arr"] = {};
				stringpath["arr"] += findpath - globaljson["paths"].begin();
				stringpath["arr"] += basename(value);
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;

				if(module == "SIMPLE"){
					this->core->SIMPLE_paths(version, jobtype, key, stringpath, &pagejson["data"]);
				}else{
					pagejson["data"][key] += stringpath["arr"];
				}
			}

		}

		if(!mic.contains("_rlnMicrographCoordinates") && mic.contains("_rlnMicrographName")){

			auto findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), jobfolder);
			if(findpath == globaljson["paths"].end()){
				globaljson["paths"] += jobfolder;
				findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), jobfolder);
			}

			nlohmann::ordered_json stringpath;
			stringpath["arr"] = {};
			stringpath["arr"] += findpath - globaljson["paths"].begin();
			stringpath["arr"] += stem(basename(mic["_rlnMicrographName"].get<std::string>())) + ".box";
			stringpath["arr"] += 0;
			stringpath["arr"] += 0;
			stringpath["arr"] += 0;

			pagejson["data"]["_rlnMicrographCoordinates"] += stringpath["arr"];
		}

		if(!mic.contains("_splNumberParticles")){
			pagejson["data"]["_splNumberParticles"].push_back(0);
		}

		miccount++;
	}

	pagejson["paths"] = globaljson["paths"];
	pagejson["endit"] = miccount;

	msgpack = nlohmann::json::to_msgpack(pagejson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	returnjson["success"] = true;
	returnjson["info"]    = "micrographs contents loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}


nlohmann::ordered_json Handler::SaveBoxes(nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;

	if(!requestjson->contains("user")){
		this->core->logError("SaveBoxes : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("SaveBoxes : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("filename")){
		this->core->logError("SaveBoxes : server failed to reply: filename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename missing from request";
		return returnjson;
	}

	if(!requestjson->contains("boxsize")){
		this->core->logError("SaveBoxes : server failed to reply: boxsize missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: boxsize missing from request";
		return returnjson;
	}

	if(!requestjson->contains("coordinates")){
		this->core->logError("SaveBoxes : server failed to reply: coordinates missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: coordinates missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("filename").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: filename is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename is not a string";
		return returnjson;
	}

	if(!requestjson->at("boxsize").is_number_integer()){
		this->core->logError("SaveBoxes : server failed to reply: boxsize is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: boxsize is not an integer";
		return returnjson;
	}

	if(!requestjson->at("coordinates").is_array()){
		this->core->logError("SaveBoxes : server failed to reply: coordinates is not an array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: coordinates is not an array";
		return returnjson;
	}

	std::string filename = requestjson->at("filename").get<std::string>();
	int boxsize = requestjson->at("boxsize").get<int>();
	int halfboxsize = std::round(boxsize/2);

	std::ofstream ofs(filename, std::ofstream::trunc);

	if(requestjson->at("coordinates")[0].size() > 0 && !requestjson->at("coordinates")[0].is_null()){
		for(auto xy : requestjson->at("coordinates")){
			ofs << std::setw(8) << xy[0].get<int>() - halfboxsize << std::setw(8) << xy[1].get<int>() - halfboxsize << std::setw(8) << boxsize << std::setw(8) << boxsize << std::setw(8) << -3 << std::endl;
		}
	}

   	ofs.close();

   	returnjson["success"] = true;
	returnjson["info"]    = "coordinates saved";

	return returnjson;

}

nlohmann::ordered_json Handler::SavePick(nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;

	if(!requestjson->contains("user")){
		this->core->logError("SaveBoxes : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("SaveBoxes : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("SaveBoxes : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		return returnjson;
	}

	if(!requestjson->contains("keepexisting")){
		this->core->logError("SaveBoxes : server failed to reply: keepexisting missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: keepexisting missing from request";
		return returnjson;
	}

	if(!requestjson->contains("map")){
		this->core->logError("SaveBoxes : server failed to reply: map missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: map missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("SaveBoxes : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		return returnjson;
	}

	if(!requestjson->at("keepexisting").is_boolean()){
		this->core->logError("SaveBoxes : server failed to reply: keepexisting is not a boolean");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: keepexisting is not a boolean";
		return returnjson;
	}

	if(!requestjson->at("map").is_array()){
		this->core->logError("SaveBoxes : server failed to reply: map is not an array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: map is not an array";
		return returnjson;
	}

	std::string starfile = requestjson->at("starfile").get<std::string>();
	bool keepexisting = requestjson->at("keepexisting").get<bool>();

	nlohmann::ordered_json micsstar = readSTAR(starfile);
	std::string jobfolder = parentPath(starfile);
	std::string workspacefolder = parentPath(parentPath(starfile));

	if(micsstar.contains("data_micrographs") && micsstar["data_micrographs"].contains("loop") && micsstar["data_micrographs"]["loop"].size() > 0 && micsstar["data_micrographs"]["loop"][0].contains("_rlnMicrographName")){

		if(requestjson->at("map").size() != micsstar["data_micrographs"]["loop"].size()){
			this->core->logError("SaveBoxes : server failed to reply: map size does not match micrographs");
			returnjson["success"] = false;
			returnjson["error"] = "server failed to reply: map size does not match micrographs";
			return returnjson;
		}

		std::string boxroot = basename(parentPath(starfile));

		for(int i = 0; i < micsstar["data_micrographs"]["loop"].size(); i++){
			
			if(micsstar["data_micrographs"]["loop"][i].contains("_rlnMicrographCoordinates")){

				std::string filename = basename(micsstar["data_micrographs"]["loop"][i]["_rlnMicrographCoordinates"].get<std::string>());

				if(requestjson->at("map")[i] == 1){	

					if(fileExists(jobfolder + "/" + filename)){
						nlohmann::ordered_json coords = readHeaderlessSTAR(jobfolder + "/" + filename);
						micsstar["data_micrographs"]["loop"][i]["_splNumberParticles"] = std::to_string(coords["data"].size());
					}else{
						if(keepexisting){
							std::string sourcefile = workspacefolder + "/" + micsstar["data_micrographs"]["loop"][i]["_rlnMicrographCoordinates"].get<std::string>();
							std::string destfile   = jobfolder + "/" + filename;
							if(sourcefile != destfile && fileExists(sourcefile) && ! fileExists(destfile)){
								copyFile(sourcefile, destfile);
							}
						}else{
							micsstar["data_micrographs"]["loop"][i]["_splNumberParticles"] = std::to_string(0);
						}
					}

					micsstar["data_micrographs"]["loop"][i]["_rlnMicrographCoordinates"] = boxroot + "/" + filename;	

				}else{ 

					if(fileExists(jobfolder + "/" + filename)){
						removeFile(jobfolder + "/" + filename);
					}

					if(micsstar["data_micrographs"]["loop"][i].contains("_splNumberParticles")){
						micsstar["data_micrographs"]["loop"][i]["_splNumberParticles"] = std::to_string(0);
					}

					micsstar["data_micrographs"]["loop"][i]["_rlnMicrographCoordinates"] = boxroot + "/" + filename;
				}
			}else{

				std::string filename = stem(micsstar["data_micrographs"]["loop"][i]["_rlnMicrographName"].get<std::string>()) + ".box";
		
				if(fileExists(jobfolder + "/" + filename)){
					nlohmann::ordered_json coords = readHeaderlessSTAR(jobfolder + "/" + filename);
					micsstar["data_micrographs"]["loop"][i]["_splNumberParticles"] = std::to_string(coords["data"].size());
				}else{
					micsstar["data_micrographs"]["loop"][i]["_splNumberParticles"] = std::to_string(0);
				}
				
				micsstar["data_micrographs"]["loop"][i]["_rlnMicrographCoordinates"] = boxroot + "/" + filename;
			}

		}
	}else{
		this->core->logError("SaveBoxes : server failed to reply: _rlnMicrographName missing from starfile");
		returnjson["success"] = false;
		returnjson["info"]    = "failed to save boxes";
		return returnjson;
	}

	writeSTAR(starfile, micsstar);

   	returnjson["success"] = true;
	returnjson["info"]    = "boxes saved";

	return returnjson;

}

/*

void Handler::CreateNicePicker(struct thread_data* d, nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;
	std::string returnstring;
	std::vector<std::uint8_t> msgpack ;
	char *queueptr;
	size_t msglen;
	
	returnstring = "M";
	mg_queue_printf(&d->queue, returnstring.c_str());

	if(!requestjson->contains("module")){
		this->core->logError("CreateNicePicker : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("CreateNicePicker : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->contains("type")){
		this->core->logError("CreateNicePicker : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("CreateNicePicker : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string module     (requestjson->at("module").get<std::string>());
	std::string version    (requestjson->at("version").get<std::string>());
	std::string jobtype    (requestjson->at("type").get<std::string>());

	returnjson = this->CreateInteractiveJob(requestjson);

	if(returnjson["success"] == false){
		this->core->logError("GetMics : server failed to reply: failed to create job");
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	std::string filename = returnjson["jobfolder"].get<std::string>() + "/micrographs.star";

	if(fileExists(returnjson["parentfolder"].get<std::string>() + "/micrographs.star")){
		copyFile(returnjson["parentfolder"].get<std::string>() + "/micrographs.star", filename);
	}

	if(!fileExists(filename)){
		this->core->logError("GetMics : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		msgpack = nlohmann::json::to_msgpack(returnjson);
		msgpack.insert(msgpack.begin(), 'P');
		msglen = msgpack.size();
		while (d->queue.tail != d->queue.head) usleep(100);
		mg_queue_book(&d->queue, &queueptr, msglen);
		memcpy(queueptr, &msgpack[0], msglen);
		mg_queue_add(&d->queue, msglen);
		return;
	}

	nlohmann::ordered_json micsstar = readSTAR(filename);

	nlohmann::ordered_json globaljson;

	if(micsstar.contains("data_optics") && micsstar["data_optics"].is_object() 
    && micsstar["data_optics"].contains("loop") && micsstar["data_optics"]["loop"].is_array() ){
		globaljson["optics"] = micsstar["data_optics"]["loop"];
	}

	if(micsstar.contains("data_micrographs") && micsstar["data_micrographs"].is_object() 
    && micsstar["data_micrographs"].contains("loop") && micsstar["data_micrographs"]["loop"].is_array() 
    && micsstar["data_micrographs"]["loop"].size() > 0){
    	globaljson["keys"] = {};
    	for (auto& el : micsstar["data_micrographs"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}

	globaljson["nmics"] = micsstar["data_micrographs"]["loop"].size();

	if(module == "SIMPLE"){
		int nptcls = this->core->SIMPLE_micsptcls(version, &micsstar);
		if(nptcls > 0){
			globaljson["nptcls"] = nptcls;
		}
		int nmicsall = this->core->SIMPLE_micsall(version, &micsstar);
		if(nmicsall > 0){
			globaljson["nall"] = nmicsall;
		}
	}

	globaljson["paths"] = {};

	globaljson["images"] = {};

	if(module == "SIMPLE"){
		this->core->SIMPLE_images(version, jobtype, &globaljson);
	}

	msgpack = nlohmann::json::to_msgpack(globaljson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();

	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	int chunksize = 100;

	int miccount  = 0;
	int maxcount  = 50;

	nlohmann::ordered_json pagejson;

	pagejson["startit"] = {};
	pagejson["paths"] = {};
	pagejson["data"] = {};

	for(auto mic : micsstar["data_micrographs"]["loop"]){

		if(miccount > 0 && miccount%chunksize == 0){
			pagejson["paths"] = globaljson["paths"];
			msgpack = nlohmann::json::to_msgpack(pagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();

			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);
			pagejson["endit"] = miccount;
			pagejson["data"] = {};
			pagejson["paths"] = {};
		}

		if(miccount == maxcount){
			pagejson["paths"] = globaljson["paths"];
			msgpack = nlohmann::json::to_msgpack(pagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();

			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);
			pagejson["endit"] = miccount;
			pagejson["data"] = {};
			pagejson["paths"] = {};
			break;
		}

		for (auto& el : mic.items()){
			
			std::string key = el.key();
			std::string value = el.value();

			if(globaljson["keys"][key] == "integer"){
				pagejson["data"][key] += std::stoi(value);
			}else if(globaljson["keys"][key] == "float"){
				pagejson["data"][key] += std::stof(value);
			}else{ //string
				if(value[0] != '/'){
					value = parentPath(parentPath(filename)) + "/" + value;
				}
				std::string parentpath = parentPath(value);
			 	auto findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				if(findpath == globaljson["paths"].end()){
					globaljson["paths"] += parentpath;
					findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				}

				nlohmann::ordered_json stringpath;
				stringpath["arr"] = {};
				stringpath["arr"] += findpath - globaljson["paths"].begin();
				stringpath["arr"] += basename(value);
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;

				if(module == "SIMPLE"){
					this->core->SIMPLE_paths(version, jobtype, key, stringpath, &pagejson["data"]);
				}else{
					pagejson["data"][key] += stringpath["arr"];
				}
			}

		}

		miccount++;
	}

	pagejson["paths"] = globaljson["paths"];
	pagejson["endit"] = miccount;

	msgpack = nlohmann::json::to_msgpack(pagejson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	returnjson["success"] = true;
	returnjson["info"]    = "micrographs contents loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}

*/
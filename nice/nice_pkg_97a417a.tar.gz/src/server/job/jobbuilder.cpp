#include "jobbuilder.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

JobBuilder::JobBuilder () {

}


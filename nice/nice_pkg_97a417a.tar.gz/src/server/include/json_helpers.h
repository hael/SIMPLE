#ifndef JSON_HELPERS_H
#define JSON_HELPERS_H

#include <json.hpp>

template<class UnaryFunction>
inline void json_recursive_iterate(const nlohmann::ordered_json& j, UnaryFunction f){
    for(auto it = j.begin(); it != j.end(); ++it){
        if (it->is_structured()){
            json_recursive_iterate(*it, f);
        }
        f(it);   
    }
}

inline bool json_test_int(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_number_integer();
}

inline bool json_test_float(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_number_float();
}

inline bool json_test_string(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_string();
}

inline bool json_test_bool(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_boolean();
}

inline bool json_test_object(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_object();
}

inline bool json_test_array(nlohmann::ordered_json testobject, std::string teststring){
    if(!testobject.contains(teststring)) return false;
    return testobject[teststring].is_array();
}

#endif
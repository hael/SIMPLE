#ifndef SYS_H
#define SYS_H

#include <iostream>
#include <thread>
#include <filesystem>

inline std::string getExecutablePath(){
    char self[2048] = { 0 };
    int nchar = readlink("/proc/self/exe", self, sizeof self);
    if (nchar < 0 || nchar >= sizeof self){
        std::cout << "Failed to obtain executable directory" << std::endl;
    }
    return std::string(self);
}

inline std::string getExecutableDir(){
    std::string executable = getExecutablePath();
    return std::string(weakly_canonical(std::filesystem::path(executable)).parent_path());
}

inline std::string getRootDir(){
    std::string executable = getExecutablePath();
    return std::string(weakly_canonical(std::filesystem::path(executable)).parent_path().parent_path());
}

inline unsigned short Decode16(const unsigned char *pos) {
    return (pos[0] << 8) | pos[1];
}

inline uint16_t be_word(const uint16_t le_word)
{
    uint16_t lo = (le_word & 0x00ff);
    uint16_t hi = ((le_word & 0xff00) >> 8);
    return (uint16_t)((lo << 8) | hi);
}

inline std::string gen_random(const int len) {
    srand((unsigned)time(NULL) * getpid());  
    static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
    std::string tmp_s;
    tmp_s.reserve(len);

    for (int i = 0; i < len; ++i) {
        tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    
    return tmp_s;
}

#endif
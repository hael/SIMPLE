#include "workspace.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Workspace::Workspace () {
    this->workspace_id = -1;
}

Workspace::Workspace (int project_id) {
    this->workspace_id = -1;
    this->LoadProject(project_id);
}

Workspace::Workspace (nlohmann::ordered_json args) {
    this->workspace_id = -1;
    if(json_test_int(args, "currentworkspaceid")){
        this->LoadWorkspace(args["currentworkspaceid"].get<int>());
    }else if(json_test_int(args, "currentprojectid")){
        this->LoadProject(args["currentprojectid"].get<int>());
    }
}

bool Workspace::LoadWorkspace(int workspace_id){
    pqxx::result workspace = sql_nontx_result("SELECT folder,project,name,displayid FROM workspaces WHERE id=" + std::to_string(workspace_id) + ";");
    if(workspace.size() > 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve single workspace from db");
        this->workspace_id = -1;
        return false;
    }else if(workspace.size() < 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve workspace from db");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace folder is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace project is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][2].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace name is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][3].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace displayid is null");
        this->workspace_id = -1;
        return false;
    }
    this->LoadProject(workspace[0][1].as<int>());
    this->workspace_id     = workspace_id;
    this->workspace_folder = this->project_folder + "/" + workspace[0][0].as<std::string>();
    this->workspace_name   = workspace[0][2].as<std::string>();
    this->display_id       = workspace[0][3].as<int>();
    return true;
}

bool Workspace::LoadLastAccessedWorkspace(){
    if(this->project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uninitialised project");
        return false;
    }
    pqxx::result workspace = sql_nontx_result("SELECT id,folder,name,displayid FROM workspaces WHERE project=" + std::to_string(this->project_id) + " AND accesstime IS NOT NULL ORDER BY accesstime DESC LIMIT 1;");
    if(workspace.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve single workspace from db");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace id is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace folder is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][2].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace name is null");
        this->workspace_id = -1;
        return false;
    }
    if(workspace[0][3].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived workspace displayid is null");
        this->workspace_id = -1;
        return false;
    }
    this->workspace_id     = workspace[0][0].as<int>();
    this->workspace_folder = this->project_folder + "/" + workspace[0][1].as<std::string>();
    this->workspace_name   = workspace[0][2].as<std::string>();
    this->display_id       = workspace[0][3].as<int>();
    return true;
}

int Workspace::CreateWorkspace(){

    if(this->project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uninitialised project");
        return FAILURE;
    }

    if(!folderExists(this->project_folder)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - " + this->project_folder + " does not exist");
        return MISSING_FOLDER;
    }

    pqxx::result existing_workspaces = sql_nontx_result(std::string_view{"SELECT COUNT(id) FROM workspaces WHERE project=" + std::to_string(this->project_id) + ";"});

    if(existing_workspaces.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to count workspaces");
        return FAILURE;
    }

    if(existing_workspaces[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - existing workspace count is null");
        return FAILURE;
    }

    int workspace_display_id = existing_workspaces[0][0].as<int>() + 1;

    std::string workspace_name      = "new workspace " + std::to_string(workspace_display_id);
    std::string workspace_folder    = ".workspace_" + std::to_string(workspace_display_id);
    std::string workspace_path      = this->project_folder + "/" + workspace_folder;
    std::string workspace_link_path = this->project_folder + "/" + workspace_name;
    std::replace(workspace_link_path.begin(), workspace_link_path.end(), ' ', '_');

    if(folderExists(workspace_path)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - " + workspace_path + " already exists");
        return PREEXISTING_FOLDER;
    }

    if(!ensureFolder(workspace_path)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to create "  + workspace_path);
        return FAILED_MKFOLDER;
    }

    if(linkExists(workspace_link_path)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - " + workspace_link_path + " already exists");
        return PREEXISTING_LINK;
    }

    linkDir(workspace_path, workspace_link_path);

    pqxx::result new_workspace = sql_result(std::string_view{"INSERT INTO workspaces (project,name,folder,displayid,accesstime) VALUES "
        "(" + std::to_string(this->project_id) + ",'" + workspace_name + "','" + workspace_folder + "'," + std::to_string(workspace_display_id) + ",NOW()) RETURNING id;"});

    if(new_workspace.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to insert workspace into database");
        return FAILURE;
    }

    if(new_workspace[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted workspace id is null");
        return FAILURE;
    }

    int workspace_id = new_workspace[0][0].as<int>();

    if(workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted workspace id is invalid");
        return FAILURE;
    }

    this->workspace_id     = workspace_id;
    this->workspace_folder = workspace_path;
    this->display_id       = workspace_display_id;
    this->workspace_name   = workspace_name;

    Simple* simple = new Simple();
    simple->InitialiseWorkspace(this->workspace_folder);
    delete simple;

    return SUCCESS;
}

nlohmann::ordered_json Workspace::NewWorkspace(){
    nlohmann::ordered_json returnjson;
    int create = this->CreateWorkspace();
    if(create > 0){
        returnjson["success"] = false;
        if(create == FAILURE){
            // generic error
        }else if(create == PREEXISTING_PROJECT){
            // project exists
            returnjson["projectexists"] = true;
        }else if(create == PREEXISTING_FOLDER){
            // folder exists
            returnjson["folderexists"] = true;
        }else if(create == MISSING_FOLDER){
            // folder missing
            returnjson["foldermissing"] = true;
        }else if(create == FAILED_MKFOLDER){
            // folder missing
        }
    }else{
         returnjson["success"] = true;
    }
    return returnjson;
}

nlohmann::ordered_json Workspace::ListAllWorkspaces(){
    nlohmann::ordered_json returnjson;
    if(this->project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid project id ");
        returnjson["success"] = false;
    }else{
        returnjson["workspaces"] = {};
        pqxx::result existing_workspaces = sql_nontx_result("SELECT id,name,folder,displayid FROM workspaces WHERE project=" + std::to_string(this->project_id) + " ORDER BY id ASC;");
        for (pqxx::result::const_iterator workspace = existing_workspaces.begin(); workspace != existing_workspaces.end(); ++workspace) {
            nlohmann::ordered_json workspacejson;
            if(workspace[0].is_null() || workspace[1].is_null() || workspace[2].is_null()) continue;
            workspacejson["id"]     = workspace[0].as<int>();
            workspacejson["name"]   = workspace[1].as<std::string>();
            workspacejson["folder"] = this->project_folder + "/" + workspace[2].as<std::string>();
            workspacejson["displayid"] = workspace[3].as<int>();
            returnjson["workspaces"].push_back(workspacejson);
        }
        returnjson["success"] = true;
    }
    return returnjson;
}

nlohmann::ordered_json Workspace::ListRecentWorkspaces(){
    nlohmann::ordered_json returnjson = {};
    returnjson["recentworkspaces"] = {};

    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Workspace::StatWorkspace(){
    nlohmann::ordered_json returnjson;
    if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid workspace id ");
        returnjson["success"] = false;
    }else{
        returnjson["workspacestats"] = {};
        returnjson["workspacestats"]["id"]        = this->workspace_id;
        returnjson["workspacestats"]["displayid"] = this->display_id;
        returnjson["workspacestats"]["folder"]    = this->workspace_folder;
        returnjson["workspacestats"]["name"]      = this->workspace_name;
        returnjson["success"] = true; 
    }
    return returnjson;
}

nlohmann::ordered_json Workspace::AccessWorkspace(){
    nlohmann::ordered_json returnjson;
    if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid workspace id ");
        returnjson["success"] = false;
    }else{
        sql_request("UPDATE workspaces SET accesstime=NOW() WHERE id=" + std::to_string(this->workspace_id) + ";");
        returnjson["success"] = true; 
    }
    return returnjson;
}

nlohmann::ordered_json Workspace::Rename(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;
    if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid workspace id");
        returnjson["success"] = false; 
        return returnjson;
    }
    if(!json_test_string(args, "workspacename")){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing workspace name");
        returnjson["success"] = false; 
        return returnjson;
    }

    std::string workspacename = args["workspacename"].get<std::string>();
    sql_request(std::string_view{"UPDATE workspaces SET name='" + workspacename + "' WHERE id=" + std::to_string(this->workspace_id)  + ";"});

    std::string workspace_link_path     = this->project_folder + "/" + this->workspace_name;
    std::string new_workspace_link_path = this->project_folder + "/" + workspacename;
    std::replace(workspace_link_path.begin(),     workspace_link_path.end(),     ' ', '_');
    std::replace(new_workspace_link_path.begin(), new_workspace_link_path.end(), ' ', '_');

    if(!linkExists(new_workspace_link_path)){
        if(linkExists(workspace_link_path)){
            moveFolder(workspace_link_path, new_workspace_link_path);
        }else{
            linkDir(this->workspace_folder, new_workspace_link_path); 
        }
    }
   
    this->workspace_name = workspacename;
    returnjson["workspacename"] = this->workspace_name;
    returnjson["success"]       = true; 
    return returnjson;
}
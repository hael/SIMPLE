#ifndef BOX_H
#define BOX_H

#include <string>

static std::vector<std::string> line2Array(std::string line, char delimiter){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == delimiter){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != delimiter){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static std::vector<std::string> line2Array(std::string line){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == ' '){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != ' '){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static nlohmann::ordered_json readBoxFile(std::string filename, int max_fields=0){

	nlohmann::ordered_json data;
	data["boxes"] = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;

	while(std::getline(buf, line)){
		
		std::vector<std::string> linearray;
		linearray = line2Array(line);
		nlohmann::ordered_json linejson = {};
		
		if(linearray.size() > 0){
			if(max_fields < 1){
				for(int i = 0; i < linearray.size(); i++){
					linejson += linearray[i];
				}
			}else{
				for(int i = 0; i < max_fields; i++){
					linejson += linearray[i];
				}
			}

		}
		data["boxes"] += linejson;
	}

	return data;

}

static nlohmann::ordered_json readBoxFileInt(std::string filename, int* fields, int fields_len){

	nlohmann::ordered_json data;
	data["boxes"] = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;

	while(std::getline(buf, line)){
		
		std::vector<std::string> linearray;
		linearray = line2Array(line);
		nlohmann::ordered_json linejson = {};
		
		if(linearray.size() > 0){
			for(int i = 0; i < fields_len; i++){
				int field_idx = fields[i];
				if(field_idx < linearray.size()){
					linejson += std::floor(std::stof(linearray[field_idx]));
				}
			}
		}
		data["boxes"] += linejson;
	}

	return data;

}

#endif
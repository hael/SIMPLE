#include "core.hpp"

#include <iostream>

Core::Core (std::string bindir, bool local) {
	spdlog::stdout_color_mt("console"); // Default console logger
	
	this->logInfo("initialising core library", false);
	
	this->bindir   	  = bindir;
	this->publicdir	  = bindir + "/public";
	this->logdir   	  = bindir + "/log";

	if(local){

		char* homedirenv = getenv("HOME");

		if(homedirenv == nullptr) this->logFatal("HOME not set");

		std::string homedir(homedirenv);

		tinyxml2::XMLElement* defaultpathele = this->xmldoc.NewElement("defaultpath");
		defaultpathele->SetText(homedir.c_str());
		this->xmldoc.InsertEndChild(defaultpathele);

		tinyxml2::XMLElement* httpportele = this->xmldoc.NewElement("httpport");
		httpportele->SetText("8090");
		this->xmldoc.InsertEndChild(httpportele);

		if(!ensureFolder(homedir + "/.nice")) this->logFatal("failed to ensure " + homedir + "/.nice" + " directory exists");
		if(!ensureFolder(homedir + "/.nice/clusters")) this->logFatal("failed to ensure " + homedir + "/.nice/clusters" + " directory exists");

		this->logdir   	  = homedir + "/.nice/log";
		this->dbdir	   	  = homedir + "/.nice/db";
	}else{
		this->logdir   	  = bindir + "/log";	
		this->dbdir	   	  = bindir + "/db";
		this->conffile 	  = bindir + "/nice.xml";
	}

	this->dbpath = this->dbdir + "/nice.sqlite";
	
	if(!ensureFolder(this->logdir))    this->logFatal("failed to ensure log directory exists " + this->logdir, false);
	if(!ensureFolder(this->dbdir))     this->logFatal("failed to ensure db directory exists " + this->dbdir,   false);
	if(!ensureFolder(this->publicdir)) this->logFatal("failed to ensure public directory exists " + this->publicdir, false);
	
	spdlog::daily_logger_mt("external_logger", this->logdir + "/daily.txt", 0, 00);
	
	if(local){

		char* homedirenv = getenv("HOME");
		if(homedirenv == nullptr) this->logFatal("HOME not set");
		std::string homedir(homedirenv);

		char* simplepathenv = getenv("SIMPLE_PATH");
		if(simplepathenv == nullptr) this->logFatal("SIMPLE_PATH not set");
		std::string simplepath(simplepathenv);

		tinyxml2::XMLElement* simplepathele = this->xmldoc.NewElement("simplepath");
		simplepathele->SetText(simplepath.c_str());
		this->xmldoc.InsertEndChild(simplepathele);

		std::string simpleclusterpath = homedir + "/.nice/clusters/simple";
		if(!ensureFolder(simpleclusterpath)) this->logFatal("failed to ensure " + simpleclusterpath + " directory exists");

		tinyxml2::XMLElement* simpleclusterpathele = this->xmldoc.NewElement("simpleclusterpath");
		simpleclusterpathele->SetText(simpleclusterpath.c_str());
		this->xmldoc.InsertEndChild(simpleclusterpathele);

		if(!fileExists(simpleclusterpath + "/local.cluster")){
			this->createLocalClusterDef("simple", simpleclusterpath + "/local.cluster");
		}

	}else{
		this->reloadConfig();
	}
	
	this->logInfo("logs will be written to " + this->logdir);

	this->SIMPLE_enabled    = this->SIMPLE_test();
	this->RELION_enabled    = this->RELION_test();
	this->CRYOSPARC_enabled = this->CRYOSPARC_test();

	bool dbuserinit = false;

	this->openDB(&dbuserinit);

	if(!this->getConfigValue("defaultpath", this->defaultpath)) this->defaultpath = bindir;

	std::thread datathread = std::thread(&Core::dataWorker, this);
	datathread.detach();
	this->logInfo("data worker thread started");

	std::thread dispatchthread = std::thread(&Core::dispatchWorker, this);
	dispatchthread.detach();
	this->logInfo("dispatch worker thread started");

	std::thread collectthread = std::thread(&Core::collectWorker, this);
	collectthread.detach();

	this->logInfo("collect worker thread started");

	std::thread statusthread = std::thread(&Core::statusWorker, this);
	statusthread.detach();

	this->logInfo("status worker thread started");

	this->ApplySchema();

	if(dbuserinit){
		std::string sql = "insert into users (name,uid,gid,level,pass) VALUES ('admin', 'admin', 'admin', 'admin', 'admin');";
		if(this->queryDB(sql, false, false)){
			this->logInfo("initial user created with username:password admin:admin");
		}else{
			this->logFatal("failed to generate initial user");
		}
	}

	this->logInfo("core library initialisation complete");

}

void Core::logInfo(std::string logtext, bool external) {
	if(external) spdlog::get("external_logger")->info(logtext);
	spdlog::get("console")->info(logtext);
}

void Core::logError(std::string logtext, bool external) {
	if(external) spdlog::get("external_logger")->error(logtext);
	spdlog::get("console")->error(logtext);
}

void Core::logFatal(std::string logtext, bool external) {
	if(external) spdlog::get("external_logger")->critical(logtext);
	spdlog::get("console")->critical(logtext);
	exit(1);
}

void Core::reloadConfig(){
	if(!fileExists(this->conffile)) this->logFatal("nice xml config file does not exist " + this->conffile);
	
	auto xmlerror = xmldoc.LoadFile( this->conffile.c_str() );
	
	if(xmlerror > 0) this->logFatal("failed to read " + this->conffile);
	
	this->logInfo("nice config read from " + conffile);
}

bool Core::getConfigValue (std::string key, std::string& value){	
	auto element = this->xmldoc.FirstChildElement( key.c_str() );
	
	if(element == NULL){
		this->logError("failed to retrieve " + key + " from config");
		return false;
	}
	
	value = std::string(element->GetText());
	this->logInfo("retrieved " + key + " (" + value + ") from config");
	return true;
}

bool Core::createLocalClusterDef(std::string module, std::string filename){

	std::ofstream deffile(filename);
	
	if(module == "simple"){
		deffile << "#NICE clustername cpu" << std::endl;
		deffile << "#NICE submitcommand nohup" << std::endl;
		deffile << "#NICE cancelcommand pkill -P" << std::endl;
		deffile << "#NICE statuscommandolf kill -0" << std::endl;
		deffile << "#NICE statuscommand pgrep -u $USER" << std::endl;
		deffile << "echo $$ > nice.pid" << std::endl;
		deffile << "export SIMPLE_QSYS=local" << std::endl;
		deffile << "XXXNICEXXX" << std::endl;
	}
	deffile.close();
	return true;
}

std::string Core::generateToken( size_t length ) {
    auto randchar = []() -> char
	{
        const char charset[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
        const size_t max_index = (sizeof(charset) - 1);
        return charset[ rand() % max_index ];
    };
    std::string str(length,0);
    std::generate_n( str.begin(), length, randchar );

    return str;
}

bool Core::getUserCreds(std::string username, nlohmann::ordered_json* user){

	std::string sql = "SELECT * FROM users WHERE name='" + username + "';";

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!queryDB(sql, &returnvals)){
		return false;
	}

	if(returnvals.size() != 1){
		return false;
	}

	std::string token = generateToken(100);

	user->emplace("name",  returnvals[0]["name"]);
	user->emplace("level", returnvals[0]["level"]);
	user->emplace("pass",  returnvals[0]["pass"]);
	user->emplace("token", token);

	return true;
}

bool Core::openDB (bool* dbuserinit) {
	if(this->db != NULL) return true;
	if(!fileExists(this->dbpath)){
		*dbuserinit = true;
	}
	auto error = sqlite3_open_v2(this->dbpath.c_str(), &this->db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, NULL);
	if(error != SQLITE_OK) this->logFatal("failed to open database " + this->dbpath);
	this->logInfo("opened database " + this->dbpath);
	return true;
}

bool Core::openDB () {
	if(this->db != NULL) return true;
	auto error = sqlite3_open_v2(this->dbpath.c_str(), &this->db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, NULL);
	if(error != SQLITE_OK) this->logFatal("failed to open database " + this->dbpath);
	this->logInfo("opened database " + this->dbpath);
	return true;
}

bool Core::queryDB (std::string sql, bool ignoreduplicate, bool verbose) {

	if(verbose) this->logInfo("running sql query 1: " + sql);
	
	sqlite3_stmt *res;
	
	this->openDB();
	
	auto error = sqlite3_prepare_v2(this->db, sql.c_str(), -1, &res, 0);    
    
    if (error > 0) {
		std::string errorstring = std::string(sqlite3_errmsg(db));
		
		if(ignoreduplicate && errorstring.find("duplicate column name") != std::string::npos){ 
			return true;
		}
		
		this->logError("database query preparation failed " + errorstring);
		return false;
	}
	
    error = sqlite3_step(res);
    
    if (error < 100) {
        this->logError("database query failed " + std::string(sqlite3_errmsg(db)));
		return false;
	}
	
    sqlite3_finalize(res);
    
    return true;
}

bool Core::queryDB (std::string sql, std::vector<std::map<std::string, std::string>>* returnvals) {
	
	this->logInfo("running sql query 2: " + sql);

	sqlite3_stmt *res;
	
	auto error = sqlite3_prepare_v2(this->db, sql.c_str(), -1, &res, 0);    
    
    if (error > 0) {
        this->logError("database query prepare failed " + std::string(sqlite3_errmsg(db)));
		return false;
	}
	
	int cols = sqlite3_column_count(res);
	
    while ((error = sqlite3_step(res)) != SQLITE_DONE){
		switch (error){
			case SQLITE_BUSY:
				this->logError("database busy " + std::string(sqlite3_errmsg(db)));
				return false;
			case SQLITE_ERROR:
				this->logError("database query failed " + std::string(sqlite3_errmsg(db)));
				return false;
			case SQLITE_ROW:
				std::map<std::string, std::string> row;
				for(int i = 0; i < cols; i++){
					if(sqlite3_column_bytes(res, i) > 0){
						row[sqlite3_column_name(res, i)] = std::string(reinterpret_cast<const char*>(sqlite3_column_text(res, i)));
					}
				}
				if(row.size() > 0){
					returnvals->push_back(row);
				}
		}
	}
    
    sqlite3_finalize(res);

    return true;
}

bool Core::queryDB (std::string sql, int* rowid) {

	this->logInfo("running sql query 3: " + sql);
	
	sqlite3_stmt *res;
	
	this->openDB();
	
	auto error = sqlite3_prepare_v2(this->db, sql.c_str(), -1, &res, 0);    
    
    if (error > 0) {
		std::string errorstring = std::string(sqlite3_errmsg(db));
		
		this->logError("database query preparation failed " + errorstring);
		return false;
	}
	
    error = sqlite3_step(res);
    
    if (error < 100) {
        this->logError("database query failed " + std::string(sqlite3_errmsg(db)));
		return false;
	}
	
    sqlite3_finalize(res);

    sql = "select last_insert_rowid()";

    error = sqlite3_prepare_v2(this->db, sql.c_str(), -1, &res, 0);    
    
    if (error > 0) {
		std::string errorstring = std::string(sqlite3_errmsg(db));
		
		this->logError("database query preparation failed " + errorstring);
		return false;
	}

	int cols = sqlite3_column_count(res);
    
    while ((error = sqlite3_step(res)) != SQLITE_DONE){
		switch (error){
			case SQLITE_BUSY:
				this->logError("database busy " + std::string(sqlite3_errmsg(db)));
				return false;
			case SQLITE_ERROR:
				this->logError("database query failed " + std::string(sqlite3_errmsg(db)));
				return false;
			case SQLITE_ROW:
				std::map<std::string, std::string> row;
				for(int i = 0; i < cols; i++){
					if(sqlite3_column_bytes(res, i) > 0){
						row[sqlite3_column_name(res, i)] = std::string(reinterpret_cast<const char*>(sqlite3_column_text(res, i)));
						*rowid = std::stoi(row["last_insert_rowid()"]);
					}
				}
		}
	}
	
    sqlite3_finalize(res);
 
    return true;
}

bool Core::getProject(int projectid, std::string user, std::string userlevel, std::map<std::string, std::string>* returnvals){
	
	std::string sql;

	if(userlevel == "admin"){
		sql = "SELECT * FROM projects WHERE id=" + std::to_string(projectid) + ";";
	}else{
		sql = "SELECT * FROM projects WHERE user='" + user + "' AND id=" + std::to_string(projectid) + ";";
	}

	std::vector<std::map<std::string, std::string>> projects;

	if(!this->queryDB(sql, &projects)){
		this->logError("getProject : sql query failed");
		return false;
	}

	if(projects.size() == 0){
		this->logError("getProject : failed to retrieve project");
		return false;
	}else if (projects.size() > 1){
		this->logError("getProject : multiple projects returned");
		return false;
	}

	for(auto & keyval : projects[0]){
		returnvals->insert(keyval);
	}

	return true;
}

bool Core::getWorkspace(int workspaceid, std::string user, std::string userlevel, std::map<std::string, std::string>* returnvals){
	
	std::string sql;

	if(userlevel == "admin"){
		sql = "SELECT * FROM workspaces WHERE id=" + std::to_string(workspaceid) + ";";
	}else{
		sql = "SELECT * FROM workspaces WHERE user='" + user + "' AND id=" + std::to_string(workspaceid) + ";";
	}

	std::vector<std::map<std::string, std::string>> workspaces;

	if(!this->queryDB(sql, &workspaces)){
		this->logError("getWorkspace : sql query failed");
		return false;
	}

	if(workspaces.size() == 0){
		this->logError("getWorkspace : failed to retrieve project");
		return false;
	}else if (workspaces.size() > 1){
		this->logError("getWorkspace : multiple projects returned");
		return false;
	}

	for(auto & keyval : workspaces[0]){
		returnvals->insert(keyval);
	}

	return true;
}

bool Core::getStats(int jobid, nlohmann::ordered_json* stats){
	
	std::string sql;

	sql = "SELECT jobstats FROM jobs WHERE id=" + std::to_string(jobid) + ";";
	
	std::vector<std::map<std::string, std::string>> jobs;

	if(!this->queryDB(sql, &jobs)){
		this->logError("getStats : sql query failed");
		return false;
	}

	if(jobs.size() == 0){
		this->logError("getStats : failed to retrieve stats");
		return false;
	}else if (jobs.size() > 1){
		this->logError("getStats : multiple stats returned");
		return false;
	}

	if(jobs[0].find("jobstats") != jobs[0].end() && jobs[0]["jobstats"] != ""){
		std::string statstr = jobs[0]["jobstats"];
		*stats = nlohmann::ordered_json::parse(statstr);
	}else{
		*stats = {};
	}
	
	return true;
}
/*
void Config::reload (){
	
	auto xmlerror = xmldoc.LoadFile( conffile.c_str() );
	
	if(xmlerror > 0) {
		configlogger->logError("Failed to read " + conffile);
	}else{

		configlogger->logInfo("Read " + conffile);
	}
}

bool Config::iterateNode (tinyxml2::XMLNode* node, void (*cb)(tinyxml2::XMLNode*)){
	
	auto child = node->FirstChild();


	for( child; child; child=child->NextSibling()){
		if(child != NULL){
			cb(child);
		}else{
			configlogger->logError("Element in config returned null");
			return false;
		}
	}

	configlogger->logInfo("Iterated element in config");
	return true;

}

tinyxml2::XMLNode* Config::getNode (std::string elementname){	
	
	tinyxml2::XMLNode* node = xmldoc.FirstChildElement( elementname.c_str() );
	
	if(node == NULL){
		configlogger->logError("Failed to retrieve " + elementname + " from config");
	} else {
		configlogger->logInfo("Retrieved " + elementname + " from config");
	}
	
	return node;
}

tinyxml2::XMLNode* Config::getNode (tinyxml2::XMLNode* nodein, std::string elementname){	
	
	tinyxml2::XMLNode* node = nodein->FirstChildElement( elementname.c_str() );
	
	if(node == NULL){
		configlogger->logError("Failed to retrieve " + elementname + " from config");
	} else {
		configlogger->logInfo("Retrieved " + elementname + " from config");
	}
	
	return node;
}

bool Config::getText (tinyxml2::XMLElement* elementin, std::string elementname, std::string& value){	
	
	auto element = elementin->FirstChildElement( elementname.c_str() );
	
	if(element == NULL){
		configlogger->logError("Failed to retrieve " + elementname + " from config");
		return false;
	} else {
		value = std::string(element->GetText());
		configlogger->logInfo("Retrieved " + elementname + " from config");
		return true;
	}
	
}


*/
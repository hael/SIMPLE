#include "jobtemplate.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

JobTemplate::JobTemplate(){
	// use default
	this->template_id = -1;
	this->template_string = "";
	this->submission_command = "";

	pqxx::result template_info = sql_result(std::string_view{"SELECT id,template,submitcommand FROM templates WHERE defaulttemplate=TRUE;"});
	
	if(template_info.size() != 1){
		template_info = sql_result(std::string_view{"SELECT id,template,submitcommand FROM templates WHERE id=1;"});
	}

    if(template_info.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve single template from database");
        return;
    }

    if(template_info[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - template id is null");
        return;
    }
 	if(template_info[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - template template is null");
        return;
    }
	if(template_info[0][2].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - template submitcommand is null");
        return;
    }

    this->template_id        = template_info[0][0].as<int>();
    this->template_string    = template_info[0][1].as<std::string>();
	this->submission_command = template_info[0][2].as<std::string>();
}

JobTemplate::JobTemplate(bool local){
	// use default
	this->template_id = -1;
	this->template_string = "";
	this->submission_command = "";


    this->template_id        = 1;
    this->template_string    = 
    "#!/usr/bin/env bash \n\
    XXXNICEXXX\
    ";

	this->submission_command = "nohup";

    if (std::getenv("SIMPLE_QSYS") != NULL){
    	std::string qsys = std::getenv("SIMPLE_QSYS");
    	if(qsys == "slurm") this->submission_command = "nohup_slurm";
    } 
}

JobTemplate::JobTemplate(int template_id){
	this->template_id = -1;
	this->template_string = "";
	this->submission_command = "";

	pqxx::result template_info = sql_result(std::string_view{"SELECT template,submitcommand FROM templates WHERE id=" + std::to_string(template_id) + ";"});
	if(template_info.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve single template from database");
        return;
    }

    if(template_info[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - template template is null");
        return;
    }
 	if(template_info[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - template submitcommand is null");
        return;
    }

    this->template_id        = template_id;
    this->template_string    = template_info[0][0].as<std::string>();
	this->submission_command = template_info[0][1].as<std::string>();
}

void JobTemplate::Substitute(std::string command_string, int nthr){
	std::string command_motif = "XXXNICEXXX";
	std::string threads_motif = "XXXNCPUXXX";
	this->substituted_template = this->template_string;
	if (this->substituted_template.find(command_motif) != std::string::npos) this->substituted_template.replace(this->substituted_template.find(command_motif), command_motif.size(), command_string);
	if (this->substituted_template.find(threads_motif) != std::string::npos) this->substituted_template.replace(this->substituted_template.find(threads_motif), threads_motif.size(), std::to_string(nthr));
}

bool JobTemplate::Write(std::string script_dir, std::string script_name){
	std::string script_path = script_dir + "/" + script_name;
	std::ofstream script_fh;
	script_fh.exceptions ( std::ofstream::failbit | std::ofstream::badbit );
	try{
		script_fh.open(script_path, std::ofstream::trunc);
		script_fh << this->substituted_template << std::endl;
	}catch (std::ofstream::failure e) {
   		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fstream failure to open scriptfile");
   		return false;
  	}
	
	if(script_fh.is_open()) script_fh.close();

	chmod(script_path.c_str(), S_IRWXU|S_IRWXG);
	this->script_dir  = script_dir;
	this->script_path = script_path;
	return true;

}

bool JobTemplate::Submit(){
	std::string systemcmd = this->submission_command + " " + this->script_path + " &";
	pid_t c_pid = fork(); 
		
	if (c_pid == -1) { 
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fork failed");
        exit(1);
    } else if (c_pid > 0) { 
       	spdlog::get("Core")->info(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - submitted " + this->script_path);
    } else { 
    	chdir(this->script_dir.c_str());
		int a = std::system(systemcmd.c_str());
	    exit(0);
    } 
    return true;
}
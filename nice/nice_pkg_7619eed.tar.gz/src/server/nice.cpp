#include "database_commander.h"
#include "job_collector.h"
#include "job_dispatcher.h"
#include "job_data_handler.h"
#include "http_server.h"
#include "simple.h"
#include "config.h"
#include "spdlog/spdlog.h"
#include "spdlog/sinks/stdout_color_sinks.h"

std::atomic<bool> terminate;

void signal_callback_handler(int signum) {
    std::cout << "Caught signal " << signum << std::endl;
    terminate = true;
}

void open_browser(int port, std::string localtoken){
    std::string url = "http://localhost:" + std::to_string(port) + "/?access_token=" + localtoken;
    bool failed = true;
    if(!system("which gnome-open > /dev/null 2>&1")){
        std::string cmd = "gnome-open " + url;
        if(!system(cmd.c_str())) failed = false;
    }else if(!system("which xdg-open > /dev/null 2>&1")){
        std::string cmd = "xdg-open " + url;
        if(!system(cmd.c_str())) failed = false;
    }else if(!system("which gio > /dev/null 2>&1")){
        std::string cmd = "gio " + url;
        if(!system(cmd.c_str())) failed = false;
    }else if(!system("which open > /dev/null 2>&1")){
        std::string cmd = "open " + url;
        if(!system(cmd.c_str())) failed = false;
    }
    if(failed){
        std::cout <<"please open a browser at " + url << std::endl;
    }
}

void printHelp(){
   std::cout << "options:" << std::endl;
   std::cout << "\tloadconfig" << std::endl;
   std::cout << "\tprintconfig" << std::endl;
   std::cout << "\tloadtemplate" << std::endl;
   std::cout << "\tprinttemplates" << std::endl;
   std::cout << "\tcreateuser" << std::endl;
   std::cout << "\tlistusers" << std::endl;
   std::cout << "\tresetpassword" << std::endl;
   std::cout << "\tdeleteuser" << std::endl;
   std::cout << "\tlocal" << std::endl;
}

int main(int argc, char* argv[]) {

    bool terminal    = isatty(STDOUT_FILENO);
    bool local       = false;
    bool browserinit = false;

    if(argc > 1){
        if(!terminal){
            std::cout << "cannot accept arguments in non-interactive terminal" << std::endl;
            return 1;
        }
        if(std::string(argv[1]) == "help"){
            printHelp();
            return 0;
        }else if(std::string(argv[1]) == "loadconfig"){
            if(argc != 3){
               std::cout << "incorrect number of arguments for loadconfig" << std::endl;
               return 1;
            }
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            if(!LoadConfig(std::string(argv[2]))){
                std::cout << "failed to load new configuration" << std::endl;
                if(!databasecommander->WasRunning) databasecommander->Stop();
                return 1;
            }
            if(!databasecommander->WasRunning) databasecommander->Stop();
            std::cout << "successfully loaded new configuration" << std::endl;
            return 0;
        }else if(std::string(argv[1]) == "printconfig"){
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            nlohmann::ordered_json config = RetreiveConfig();
            if(!databasecommander->WasRunning) databasecommander->Stop();
            std::cout << config.dump(2) << std::endl;
            return 0;  
        }else if(std::string(argv[1]) == "loadtemplate"){
            if(argc != 6){
               std::cout << "incorrect number of arguments for loadtemplate" << std::endl;
               return 1;
            }
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            if(!LoadTemplate(std::string(argv[2]), std::string(argv[3]), std::string(argv[4]), std::string(argv[5]))){
                std::cout << "failed to load new template" << std::endl;
                std::cout << "< name submitcommand default template >" << std::endl;
                if(!databasecommander->WasRunning) databasecommander->Stop();
                return 1;
            }
            if(!databasecommander->WasRunning) databasecommander->Stop();
            std::cout << "successfully loaded new template" << std::endl;
            return 0;
        }else if(std::string(argv[1]) == "printtemplates"){
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            PrintTemplates();
            if(!databasecommander->WasRunning) databasecommander->Stop();
            return 0; 
        }else if(std::string(argv[1]) == "createuser"){
            if(argc != 7){
               std::cout << "incorrect number of arguments for createuser" << std::endl;
               std::cout << "< username firstname lastname admin password >" << std::endl;
               return 1;
            }
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            sql_request("INSERT INTO users (username,firstname,lastname,admin,password,token) VALUES ('" + std::string(argv[2]) + "','" + std::string(argv[3]) + "','" + std::string(argv[4]) + "'," + std::string(argv[5]) + ",'" + std::string(argv[6]) + "',(SELECT md5(random()::text)));");
            if(!databasecommander->WasRunning){
                databasecommander->Stop();
            }
            std::cout << "successfully created new user" << std::endl;
            return 0;
        }else if(std::string(argv[1]) == "listusers"){
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            ListUsers();
            if(!databasecommander->WasRunning){
                databasecommander->Stop();
            }
            return 0;
        }else if(std::string(argv[1]) == "resetpassword"){
            if(argc != 4){
               std::cout << "incorrect number of arguments for resetpassword" << std::endl;
               std::cout << "< username password >" << std::endl;
               return 1;
            }
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            sql_request("UPDATE users SET password='"+ std::string(argv[3]) + "',token=(SELECT md5(random()::text)) WHERE username='" + std::string(argv[2]) + "';");
            if(!databasecommander->WasRunning){
                databasecommander->Stop();
            }
            std::cout << "successfully updated password" << std::endl;
            return 0;
        }else if(std::string(argv[1]) == "deleteuser"){
            if(argc != 3){
               std::cout << "incorrect number of arguments for deleteuser" << std::endl;
               std::cout << "< username >" << std::endl;
               return 1;
            }
            DatabaseCommander* databasecommander = new DatabaseCommander(local);
            sql_request("UPDATE users SET password=NULL,token=NULL WHERE username='" + std::string(argv[2]) + "';");
            if(!databasecommander->WasRunning){
                databasecommander->Stop();
            }
            std::cout << "successfully deleted user" << std::endl;
            return 0;
        }else if(std::string(argv[1]) == "local"){
            local = true;
        }else{
            std::cout << "unknown argument " << argv[1] << std::endl;
            return 1;
        }
    }
    // local tests
    if(local){
        if (getenv("SIMPLE_PATH") == NULL){
            std::cout << "the SIMPLE environment hasn't been sourced" << std::endl;
            return 1;
        }
    }
    // catch signals
    signal(SIGINT, signal_callback_handler);
    terminate = false;
    // console logger
    auto master = spdlog::stdout_color_mt("master");
    // core logger
    std::string logpath = getRootDir() + "/var/log/core.log";
    auto logger = spdlog::rotating_logger_mt("Core", logpath, 1048576 * 5, 5);
    // start daemons
    DatabaseCommander* databasecommander = new DatabaseCommander(local);
    JobCollector*      jobcollector      = new JobCollector(local);
    JobDispatcher*     jobdispatcher     = new JobDispatcher(local);
    JobDataHandler*    jobdatahandler    = new JobDataHandler();
    HTTPServer*        httpserver        = new HTTPServer(jobcollector->comm_addr_str, local);

    while(true){
        sleep(1);
        if(httpserver->Status()){
            if(!browserinit && local){
                browserinit = true;
                open_browser(httpserver->port, httpserver->localtoken);
            }
        }else{
            //restart
            spdlog::get("master")->info("HTTPServer restarting");
            delete httpserver;
            httpserver = new HTTPServer(jobcollector->comm_addr_str, local);
        }
        if(!jobcollector->Status()){
            //restart
            spdlog::get("master")->info("JobCollector restarting");
            delete jobcollector;
            jobcollector = new JobCollector(local);
        }
        if(terminate) break;
    }
    
    httpserver->Stop();
    jobcollector->Stop();
    jobdispatcher->Stop();
    jobdatahandler->Stop();
    databasecommander->Stop();
    return 0;
}
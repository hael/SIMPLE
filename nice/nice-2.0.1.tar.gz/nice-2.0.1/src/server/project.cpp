#include "handler.hpp"

bool Handler::SelectProject(int projectid, std::string username){

	std::string sql = "UPDATE users SET selectedprojectid=" + std::to_string(projectid) + " WHERE name='" + username + "';";

	if(!this->core->queryDB(sql)){
		this->core->logError("SelectProject : sql query failed");
		return false;
	}

	return true;
}

nlohmann::ordered_json Handler::ActiveProject(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("ActiveProject : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ActiveProject : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ActiveProject : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ActiveProject : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	
	std::string sql = "SELECT selectedprojectid FROM users WHERE name='" + user + "';";

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ActiveProject : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	if(returnvals.size() != 1){
		this->core->logError("ActiveProject : server failed to reply: failed to find active projectid");
		returnjson["success"] = true;
		returnjson["info"] = "failed to find active project. please select project";
		return returnjson;
	}

	int projectid = std::stoi(returnvals[0]["selectedprojectid"]);

	returnvals.clear();

	sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE AND id=" + std::to_string(projectid) + ";";

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ActiveProject : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	if(returnvals.size() != 1){
		this->core->logError("ActiveProject : server failed to reply: failed to find active project");
		returnjson["success"] = false;
		returnjson["error"] = "failed to find active project";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"]    = "last project loaded";
	returnjson["projectname"] = returnvals[0]["name"];
	returnjson["projectid"]   = returnvals[0]["id"];
	
	return returnjson;
}

nlohmann::ordered_json Handler::CreateProject(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("CreateProject : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("CreateProject : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("name")){
		this->core->logError("CreateProject : server failed to reply: name missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: name missing from request";
		return returnjson;
	}

	if(!requestjson->contains("folder")){
		this->core->logError("CreateProject : server failed to reply: folder missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing from request";
		return returnjson;
	}

	if(!requestjson->contains("description")){
		this->core->logError("CreateProject : server failed to reply: description missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: description missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("CreateProject : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("CreateProject : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("name").is_string()){
		this->core->logError("CreateProject : server failed to reply: name is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: name is not a string";
		return returnjson;
	}

	if(!requestjson->at("folder").is_string()){
		this->core->logError("CreateProject : server failed to reply: folder is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder is not a string";
		return returnjson;
	}

	if(!requestjson->at("description").is_string()){
		this->core->logError("CreateProject : server failed to reply: description is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: description is not a string";
		return returnjson;
	}

	std::string user        (requestjson->at("user").get<std::string>());
	std::string userlevel   (requestjson->at("userlevel").get<std::string>());
	std::string name        (requestjson->at("name").get<std::string>());
	std::string folder      (requestjson->at("folder").get<std::string>());
	std::string description (requestjson->at("description").get<std::string>());

	std::string subfolder = name;

	std::replace(subfolder.begin(), subfolder.end(), ' ', '_');

	if(folderExists(folder + "/" + subfolder)){
		int count = 1;
		while(folderExists(folder + "/" + subfolder + "_" + std::to_string(count))){
			count += 1;
		}
		subfolder = subfolder + "_" + std::to_string(count);
	}

	if(!ensureFolder(folder + '/' + subfolder)){
		this->core->logError("CreateProject : server failed to reply: failed to create project directory");
		returnjson["success"] = false;
		returnjson["error"] = "CreateProject : failed to create project directory";
		return returnjson;
	}

	std::string sql = "INSERT INTO projects (name, folder, description, owner) VALUES ('" + name + "','" + folder + '/' + subfolder + "','" + description + "','" + user + "');";
	
	int projectid = -1;

	if(!this->core->queryDB(sql, &projectid)){
		this->core->logError("CreateProject : server failed to reply: failed to insert project into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateProject : failed to insert project into database";
		return returnjson;
	}

	if(projectid < 0){
		this->core->logError("CreateProject : failed to insert workspace into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateProject : failed to insert workspace into database";
		return false;
	}

	if(!this->SelectProject(projectid, user)){
		this->core->logError("CreateProject : server failed to reply: failed to select project");
		returnjson["success"] = false;
		returnjson["error"] = "CreateProject : failed to select workspace";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"] = "project created with id " + std::to_string(projectid);
	returnjson["projectname"] = name;
	returnjson["projectid"] = projectid;
	
	return returnjson;

}
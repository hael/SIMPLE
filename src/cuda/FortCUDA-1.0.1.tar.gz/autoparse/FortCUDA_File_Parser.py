#!/usr/bin/env python
#................................................................................
# Copyright (C) 2010 Michael List, listmg@users.sourceforge.net
# Copyright (C) 2010 David Car, skinny_boy@users.sourceforge.net
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA 02111-1307 USA
#................................................................................

try:
    from blockit.basegrammar import ishex, isbin, isoct
    import blockit.m4.grammars as m4gram
    import blockit.C.grammars as Cgram
    import blockit.external.pyparsing as pp
except:
    print("""
You must have the BlockIt project installed on your system
in order to execute this tool. The file parser requires grammars
that are included in BlockIt's develop branch!!!

See http://blockit.sourceforge.net and look for git readonly access.
""")

import exceptions
import os
import sys
import fnmatch
import optparse as op
import shlex
import subprocess
import pprint

##
# Map of C intrinsics to Fortran ISO_C_BINDINGS.
# Build a map between various C types and their Fortran equivalents.
# Most of this is taken from N1830, the last Fortran 2008 draft,
# sections 15.3.2 and 15.3.3.
CTypeMap = {
    'int':          ('integer','c_int'),
    'unsigned int': ('integer','c_int'),
    'short':             ('integer','c_short'),
    'short int':         ('integer','c_short'),
    'unsigned short int':('integer','c_short'),
    'long int':         ('integer','c_long'),
    'unsigned long int':('integer','c_long'),
    'long unsigned int':('integer','c_long'),
    'long':             ('integer','c_long'),
    'long long':             ('integer','c_long_long'),
    'unsigned long long':    ('integer','c_long_long'),
    'long long int':         ('integer','c_long_long'),
    'unsigned long long int':('integer','c_long_long'),
    'signed char':  ('integer','c_signed_char'),
    'unsigned char':('integer','c_signed_char'),
    'size_t':       ('integer','c_size_t'),
    'int8_t':       ('integer','c_int8_t'),
    'int16_t':      ('integer','c_int16_t'),
    'int32_t':      ('integer','c_int32_t'),
    'int64_t':      ('integer','c_int64_t'),
    'int_least8_t': ('integer','c_int_least8_t'),
    'int_least16_t':('integer','c_int_least16_t'),
    'int_least32_t':('integer','c_int_least32_t'),
    'int_least64_t':('integer','c_int_least64_t'),
    'int_fast8_t':  ('integer','c_int_fast8_t'),
    'int_fast16_t': ('integer','c_int_fast16_t'),
    'int_fast32_t': ('integer','c_int_fast32_t'),
    'int_fast64_t': ('integer','c_int_fast64_t'),
    'intmax_t':     ('integer','c_intmax_t'),
    'intptr_t':     ('integer','c_intptr_t'),
    'float':      ('real','c_float'),
    'double':     ('real','c_double'),
    'long double':('real','c_long_double'),
    'float _Complex':      ('complex','c_float_complex'),
    'double _Complex':     ('complex','c_double_complex'),
    'long double _Complex':('complex','c_long_double_complex'),
    '_Bool':('logical','c_bool'),
    'char':('character','c_char'),
    'char *':('type','c_ptr'),
    'void *':('type','c_ptr'),
    'void **':('type','c_ptr'),
}

##
# Fortran keywords that we don't actually want to use as dummy argument names.
KEYWORDS = ["kind", "end", "stop", "type", "value"]

#=======================================================================
# Build Options
#=======================================================================
parser = op.OptionParser()
parser.set_defaults(module=False)
parser.add_option("-i", "--include-dir", metavar="DIR", action="store", \
    dest="includedir", default="/usr/local/cuda/include")
parser.add_option("-f", "--file", metavar="FILE", action="append", \
    dest="filelist", default=list())
parser.add_option("-l", "--log-file", metavar="FILE", action="store", \
    dest="logfile", default=None)
parser.add_option("-m", "--write-module", action="store_true", \
    help="Writes all output into a Fortran module. The name of the file \
and module are derived from the file being parsed with all '.' replaced by '_'", \
    dest="module")
parser.add_option("-w", "--write-wrapper", metavar="NAME", action="store", \
    help="Writes a module that wraps all the modules written with -m",
    dest="wrapper", default=None)
parser.add_option("-t", "--unit-test", action="store_true", \
    help="Runs the unit-tests. All other options are ignored.", \
    dest="test", default=False)
parser.add_option("--enum-as-parameter", action="store_true", \
    help="Parsed C enumerators as Fortran integer(c_int) parameters", \
    dest="enum_as_parameter", default=False)
parser.add_option("-r", "--resolve-file", metavar="FILE", action="store", \
    help="Reads a resolve file with special syntax to assist in wrapper creation.", \
    dest="resolvefile", default=None)

#-----------------------------------------------------------------------
# Preprocessing Flags
#-----------------------------------------------------------------------
preproc = op.OptionGroup(parser, "Preprocessing options")
preproc.add_option("-E", action="store_true", \
    help="Activates the preprocessing pipeline", \
    dest="pp_process", default=False)
preproc.add_option("-D", metavar="VARIABLE", action="append", \
    help="User defined preprocessing macros", \
    dest="pp_defines", default=list())
preproc.add_option("-I", metavar="FILE", action="append", \
    help="User defined include directories", \
    dest="pp_includes", default=list())
preproc.add_option("--preprocessor", metavar="EXECNAME", action="store", \
    help="User defined preprocessing macros", type="string", \
    dest="pp_preprocessor", default="gcc")
preproc.add_option("--preprocessor-flag", metavar="FLAG", action="store", \
    help="Flag required to activate preprocessing", type="string", \
    dest="pp_preprocflag", default="-E")
preproc.add_option("--save-pp", action="store_true", \
    dest="pp_savefile", default=False)
parser.add_option_group(preproc)
del preproc

#-----------------------------------------------------------------------
# Extraction Flags
#-----------------------------------------------------------------------
parser.set_defaults(ex_defines=False, ex_enums=True, ex_structs=True, \
                    ex_typedefs=True, ex_prototypes=True)
extract = op.OptionGroup(parser, "Extraction flags")
extract.add_option("--enable-defines", action="store_true", dest="ex_defines")
extract.add_option("--disable-defines", action="store_false", dest="ex_defines")
extract.add_option("--enable-enums", action="store_true", dest="ex_enums")
extract.add_option("--disable-enums", action="store_false", dest="ex_enums")
extract.add_option("--enable-structs", action="store_true", dest="ex_structs")
extract.add_option("--disable-structs", action="store_false", dest="ex_structs")
extract.add_option("--enable-typedefs", action="store_true", dest="ex_typedefs")
extract.add_option("--disable-typedefs", action="store_false", dest="ex_typedefs")
extract.add_option("--enable-prototypes", action="store_true", dest="ex_prototypes")
extract.add_option("--disable-prototypes", action="store_false", dest="ex_prototypes")
parser.add_option_group(extract)
del extract


#=======================================================================
# Function definitions
#=======================================================================
def locate(pattern,root=os.curdir):
    """Locates files within a root directory which match a pattern"""

    files = os.listdir(os.path.abspath(incdir))
    for path, dirs, files in os.walk(os.path.abspath(incdir)):
        for filename in fnmatch.filter(files,pattern):
            yield os.path.join(path, filename)


def printHeader(dev, title, char='-', firstChar=None):
    """Prints a simple header banner"""

    if firstChar: dev.write(firstChar)
    dev.write(80*char + os.linesep)

    dev.write(title + os.linesep)

    if firstChar: dev.write(firstChar)
    dev.write(80*char + os.linesep)


def rearrangeUnderscore(istr):
    """Moves underscores to the end of a string."""

    output = istr
    if output:
        while output[0] == "_":
            output = output[1:] + "_"
    return output

def safeJoin(lst):
    """Safely joins entries in a list."""

    if isinstance(lst[0],str):
        output = lst[0]
    else:
        return ''
    ctr = 1
    while True:
        try:
            output = " ".join([output,lst[ctr]])
            ctr += 1
        except:
            break
    return output

def buildResolutionDict(itemList, output=dict(), needs=dict()):

    newItems = list()

    # We overwrite and set the CTypeMap as defaults for every file
    # Other entries are added to, typically.
    #
    # This is really redundant and occurs for every file, even though
    # it may be inappropriate and may overwrite something we wanted
    # from a previous file. It should be outside the loop during
    # initialization.
    for k,v in CTypeMap.items():
        f_type, c_type = v
        output[k] = f_type + ' (' + c_type + ')'
        output[" ".join( [ "const", k ] )] = output[k]
        output[" ".join( [ k, "const" ] )] = output[k]

    # What is this check? I remember putting something into the
    # function, but why, and why does it reference a variable
    # that isn't here?
    if resolution is None:
        raise Exception("resolution is somehow none...")

    for grp in itemList:
        type_key, obj = grp[1:3]

        if isinstance( obj, ParsedDefine ):
            ns = obj.nameSpec()
            eq = obj.equivalence()
            if output.has_key(eq):
                output[eq] += [ns]
            else:
                output[eq] = [ns]

        elif isinstance( obj, ParsedEnum ):
            ns = obj.nameSpec()
            fi = obj.firstItem()
            output[ns] = 'integer (KIND(' + fi + '))'
            try:
                if fi not in needs[ns]:
                    needs[ns] += [fi]
            except:
                needs[ns] = [fi]
            if obj.istypedefed():
                ns2 = obj.nameSpec2()
                output[ns2] = output[ns]
                needs[ns2] = needs[ns]

        elif isinstance( obj, ParsedStruct ):
            ns = obj.nameSpec()
            nam = obj.name()
            output[ns] = 'type (' + nam + ')'
            output[ns + " *"] = 'type (c_ptr)'
            output[ns + " **"] = 'type (c_ptr)'
            try:
                needs[ns] += [nam]
            except:
                needs[ns] = [nam]
            try:
                needs[ns + " *"] += [nam]
                needs[ns + " **"] += [nam]
            except:
                needs[ns + " *"] = [nam]
                needs[ns + " **"] = [nam]
            if obj.istypedefed():
                ns2 = obj.nameSpec2()
                output[ns2] = output[ns]
                needs[ns2] = needs[ns]
                output[ns2 + " *"] = output[ns + " *"]
                output[ns2 + " **"] = output[ns + " **"]
                needs[ns2 + " *"] = needs[ns + " *"]
                needs[ns2 + " **"] = needs[ns + " **"]

        elif isinstance( obj, ParsedStructPrototype ):
            ns = obj.nameSpec()
            output[ns + " *"] = 'type (c_ptr)'
            output[ns + " **"] = 'type (c_ptr)'

        elif isinstance( obj, ParsedTypedef ):
            eq = obj.equivalence()
            print "ParsedTypedef::", eq
            if output.has_key(eq[0]):
                print "Equivalencing ", eq[1], "=>", eq[0], "'", output[eq[0]], "'"
                output[eq[1]] = output[eq[0]]
                try:
                    needs[eq[1]] = needs[eq[0]]
                except:
                    pass
            else:
                print "Did not have key", eq[0], "for resolution of", eq[1]
                #output[eq[1]] = eq[0]
                #try:
                #    needs[eq[1]] = [eq[0]]
                #except:
                #    pass

                # This is where we must find a way to resolve all the things
                # which have been hidden from us. The example is CUDA symbols
                # that are not resolved within the header files and must be
                # byte-coded somewhere in nvcc.

                #if eq[0][:6] == "struct":
                #    snam = eq[0][6:].strip(' *')
                #else:
                #    snam = eq[0].strip(' *')
                #print "   --> substituting:", snam
                #newItems.append("struct "+snam+" { void *ptr; };")
                #output[eq[0]] = "type ("+snam+")"
                #needs[eq[0]] = [snam]

                if eq[1][:6] == "struct":
                    snam = eq[1][6:].strip(' *')
                else:
                    snam = eq[1].strip(' *')
                print "   --> substituting:", snam
                newItems.append("struct "+snam+" { void *ptr; };")
                output[eq[1]] = "type ("+snam+")"
                needs[eq[1]] = [snam]

    return (output, needs, newItems)


#=======================================================================
# Classes
#=======================================================================
VALIDNAME = pp.Word(pp.alphanums+"_")
FUNCTION = (pp.Literal("function")|pp.Literal("subroutine")).suppress() 
FUNCTIONNAME = FUNCTION + VALIDNAME
ENDFUNCTION = pp.Literal("end").suppress() + pp.Optional(FUNCTION) + VALIDNAME.suppress()
DOUBLECOLON = pp.Literal("::").suppress()
ATTRIBUTEDECL = pp.Group(pp.delimitedList(pp.Word(pp.alphanums)) + DOUBLECOLON + pp.Word(pp.nums))
PROTOMODIFIER = FUNCTIONNAME + pp.ZeroOrMore(ATTRIBUTEDECL) + ENDFUNCTION


class ProtoModifier(object):
    """This class exists to allow user modification to a prototype that
    will be written. The format to the file is in flux, but basically
    it allows attribute specification of each argument for now.

    Ultimately this class should allow specifications of INTENT(IN|OUT|INOUT),
    attributes such as VALUE, VOLATILE, etc, and generation of a wrapper
    with potentially different arguments.
    """

    def __init__(self, match):
        """Instances should be instantiated with a match from the
        PROTOMODIFIER grammar.

        """

        self.match = match
        self._name = match[0]
        self._itemdict = dict()
        for i in xrange(1,len(match),1):
            attrib = match[i]
            k = attrib[-1]
            self._itemdict[k] = [v for v in attrib[0:-1]]

    def name(self):
        """The name is the name of the function which will be modified."""
        return self._name

    def __getitem__(self, num):
        if self._itemdict.has_key(num):
            return self._itemdict[num]
        else:
            print "Does not contain", num, " dict=", self._itemdict
            return None


class ParsedObject(object):
    def __init__(self, match):
        """Stores match into self"""
        self.match = match[0]

    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=dict()):
        """Parses match into Fortran 2003/2008 interoperable type into
        a file descriptor (default: stdout).
        """
        pass


class ParsedEncompass(ParsedObject):
    """Base class for Structs, Enums, and Prototypes.
    """

    def __init__(self, match, enc):
        super(ParsedEncompass,self).__init__(match)
        self.encompass = enc

    def __getitem__(self,it):
        try:
            return self.match[2][it].asList()
        except:
            try:
                return self.match[2][it]
            except:
                return None

    def firstItem(self):
        try:
            return (self.match[2][0].asList())[0]
        except:
            try:
                return self.match[2][0]
            except:
                return None

    def name(self): return rearrangeUnderscore(self.match[1]) or ''
    def nameC(self): return self.match[1] or ''
    def nameSpec(self):
        try:
            return " ".join([self.encompass,rearrangeUnderscore(self.match[1])])
        except:
            return ''

    def nameSpec2(self): return rearrangeUnderscore(self.match[4])
    def istypedefed(self):
        if self.match[4]: return True
        return False

class ParsedEnum(ParsedEncompass):
    def __init__(self, match): super(ParsedEnum,self).__init__(match, "enum")
    def nameSpec(self):
        """The enum can have a name as index 1 or 4, depending on if it is in a
        typedef or not....
        """

        try:
            if self.match[1] is not None:
                return " ".join([self.encompass,rearrangeUnderscore(self.match[1])])
            else:
                return " ".join([self.encompass,rearrangeUnderscore(self.match[4])])
        except:
            return ''

    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=(),
                  enum_as_parameter=False):
        """Parses match into Fortran 2003/2008 enumerator and writes the
        result to a file descriptor (default: stdout).
        """

        name = self.match[1]
        if name is None: name = self.match[4]
        items = self.match[2]

        outstr = ""
        if enum_as_parameter:
            #fd.write( " ".join( [ 4*" ", "! C Enumerator =>", 
            #                      str(name), os.linesep ] ) )
            outstr += " ".join( [ 4*" ", "! C Enumerator =>", \
                                  str(name), os.linesep ] )
            for num,item in enumerate(items):
                is_string = isinstance(item, str)
                tmpstr = 6*" " + "integer(c_int), parameter :: "
                tmpstr += rearrangeUnderscore(is_string and item or item[0])
                if not is_string and len(item) == 2:
                    num = item[1]
                    if isoct(num): tmpstr += "=" + str(int(num,8))
                    elif ishex(num): tmpstr += "=" + str(int(num,16))
                    else: tmpstr += "=" + num
                else:
                    tmpstr += "=" + str(num)
                outstr += tmpstr + os.linesep
        else:
            outstr += 4*" " + "enum, bind(C) !:: " + str(name) + os.linesep
            for i in items:
                isstring = isinstance(i, str)
                tmpstr = 6*" " + "enumerator :: " + \
                    rearrangeUnderscore(isstring and i or i[0])
                if not isstring and len(i) == 2:
                    num = i[1]
                    # if isbin(num): outstr += "=" + str(int(num,2)) #outstr += "=/b'" + num + "'/"
                    if isoct(num): tmpstr += "=" + str(int(num,8)) #outstr += "=/o'" + num + "'/"
                    elif ishex(num): tmpstr += "=" + str(int(num,16)) #outstr += "=/z'" + num + "'/"
                    else: tmpstr += "=" + num
                outstr += tmpstr + os.linesep
            outstr += 4*" " + "end enum ! " + str(name) + os.linesep

        outstr += os.linesep
        fd.write( outstr )

class ParsedStruct(ParsedEncompass):
    def __init__(self, match): super(ParsedStruct,self).__init__(match, "struct")

    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=dict()):

        rd = resolution

        outstr = ""
        name = self.name()
        items = self.match[2]
        if name == '': return
        outstr += 4*" " + "type, bind(C) :: " + name + os.linesep
        for i in items:
            typspec = " ".join([rearrangeUnderscore(x) for x in i[0:-2]])
            if i[-2]: typspec = " ".join([typspec,i[-2]])
            if rd.has_key(typspec):
                for v in i[-1]:
                    tmpstr = 6*" " + rd[typspec] + " :: " + \
                              rearrangeUnderscore(str(v[0]))
                    if '*' in tmpstr:
                        print ">>> * found in type specification in type ", name,": ignoring"
                        return
                    outstr += tmpstr
                    if v[1] is not None:
                        outstr += "(" + str(v[1]) + ")"
                    if (len(v) == 3) and (v[2] is not None):
                        outstr += "=" + v[2]
                    outstr += os.linesep
            else:
                if i[-2] is not None:
                    for v in i[-1]:
                        outstr += 6*" " + "type (c_ptr) :: " + \
                                  rearrangeUnderscore(str(v[0]))
                        if v[1] is not None:
                            outstr += "(" + str(v[1]) + ")"
                        if (len(v) == 3) and (v[2] is not None):
                            outstr += "=" + v[2]
                        outstr += os.linesep
                else:
                    print ">>> Could not find info for typspec=",typspec
                    outstr += 6*" " + "! " + typspec + \
                              " :: unresolved :: " + str(i[-1]) + os.linesep
        outstr += 4*" " + "end type " + name + os.linesep
        outstr += os.linesep

        fd.write( outstr )


class ParsedStructPrototype(ParsedEncompass):
    def __init__(self, match): 
        super(ParsedStructPrototype,self).__init__(match, "struct")

    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=dict()):
        pass

    def nameSpec2(self): return None
    def istypedefed(self): return False


class ParsedDefine(ParsedObject):
    def __init__(self, match): super(ParsedDefine,self).__init__(match)
    def nameSpec(self):
        return self.match[0]
    def equivalence(self):
        return self.match[1]
    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=dict()):
        """Parses match into Fortran 2003/2008 interoperable type into
        a file descriptor (default: stdout).
        """
        name = self.nameSpec()
        eq = self.equivalence()

        eqint = None
        eqreal = None
        outstr = 4*" "
        dowrite = False

        try:
            eqint = int(eq)
            dowrite = True
        except:
            pass
        try:
            eqreal = float(eq)
            dowrite = True
        except:
            pass

        if eqint is not None:
            outstr += "integer(kind=c_int), parameter :: "
        elif eqreal is not None:
            outstr += "real(kind=c_float), parameter :: "
        outstr += rearrangeUnderscore(name) + "=" + eq + os.linesep

        if dowrite:
            fd.write( outstr )



class ParsedTypedef(ParsedObject):
    def __init__(self, match): super(ParsedTypedef,self).__init__(match)
    def equivalence(self):
        spec = ( " ".join( map( lambda x: rearrangeUnderscore(x) or '', 
                                self.match[1][:] ) ) ).strip()
        # spec = rearrangeUnderscore(self.match[1][0])
        # try:
        #     ctr = 1
        #     while True:
        #         spec = " ".join([spec,rearrangeUnderscore(self.match[1][ctr])])
        #         ctr += 1
        # except:
        #     pass
        return ( spec, rearrangeUnderscore( self.match[2] ) )


class ParsedProto(ParsedObject):
    """Stores a parsed function prototype.
    """

    def __init__(self, match): super(ParsedProto,self).__init__(match)
    def toFortran(self, fd=sys.stdout, resolution=dict(), toimport=dict(), modifiers=list()):
        """Parses match into Fortran 2003/2008 interface with bind(c)
        to a file descriptor (default: stdout).
        """

        rd = resolution

        ret = self.match[0:-2]
        name = self.match[-2]
        if name is None:
            print self.match
            return
        if name in resolution.keys():
            if len(resolution[name]) == 1:
                name = resolution[name][0]
        safename = rearrangeUnderscore( name )

        domod = False
        if modifiers.has_key(name):
            print "Modifying prototype", name
            mymods = modifiers[name]
            domod = True
                

        #..........................
        # Create all the arguments
        #..........................
        items = self.match[-1]
        arglist = list()
        type_need = dict()
        type_dict = dict()
        for n, item in enumerate(items):
            intent = ""
            if item == "void":
                arglist = list()
                break
            if item == "...":
                break
            type_spec, ptr_spec, identifier = item[0:-2], item[-2], item[-1]
            if "const" in type_spec:
                type_spec.remove("const")
                intent = ", intent(in)"
            type_spec = " ".join( type_spec ).strip()
            arg_name = rearrangeUnderscore( identifier )
            if arg_name.lower() in KEYWORDS: arg_name = arg_name.lower()+"_arg"

            decl = ""
            try:
                decl = rd[ type_spec ]
            except:
                try:
                    type_spec = " ".join( [ type_spec, ptr_spec ] )
                    decl = rd[ type_spec ] 
                except:
                    print ">>> Could not find info for type_spec='" + \
                        str(type_spec)+"'"
                    decl = "class (*)"
            try:
                nds = toimport[type_spec]
                type_need[arg_name] = nds
                # print toimport[type_spec]
                # print "Adding need ... ", nds, " for arg ", arg_name
            except:
                # print "Not adding any needs for argument ", arg_name, type_spec
                pass

            #if 'c_ptr' in decl:
            #    if ptr_spec != '*': decl += ", value"
            #elif ptr_spec != '*': 
            #    decl += ", value"
            if ptr_spec is None: decl += ", value"

            if domod:
                print "Doing modifications for n=",n,mymods.name()
                app = mymods[str(n)]
                if app is not None:
                    print "  For argument number",n,"modifying:",app
                    for appin in app: decl += ", "+appin
                else:
                    app = mymods[arg_name]
                    if app is not None:
                        print "  For argument name",arg_name,"modifying:",app
                        for appin in app: decl += ", "+appin
            decl += intent

            arglist.append(arg_name)
            type_dict[arg_name] = decl

        #..........................
        # Create the return
        #..........................
        rettype = True
        procedure = "function "
        if isinstance(ret,list):
            rets = safeJoin(ret[0])
        elif isinstance(ret,str):
            rets = ret
        if rets == "void":
            procedure = "subroutine "
            rettype = False

        outstr = ""
        # Write the procedure header
        outstr += 4*" " + "interface ! " + str(self.match) + os.linesep

        outstr1 = ""
        outstr1 += 6*" " + procedure + safename
        outstr1 += "(" + ",".join(arglist) + ")"

        outstr2 = ""
        if rettype: outstr2 += " result( res )"
        outstr2 += " bind(C, name=\"" + name + "\")" + os.linesep

        if (len(outstr1) + len(outstr2)) > 127:
            outstr += outstr1 + " &" + os.linesep + "&" + 8*" " + outstr2
        else:
            outstr += outstr1 + outstr2

        # Write all the uses and import statements
        outstr += 8*" " + "use, intrinsic :: ISO_C_BINDING" + os.linesep
        if rettype and toimport.has_key(rets):
            for imp in set(toimport[rets]):
                tmpstr = 8*" " + "import " + imp + os.linesep
                if '*' in tmpstr:
                    print ">>> * found in import statement:", name," : ignoring"
                    return
                outstr += tmpstr
        for arg in arglist:
            if type_need.has_key(arg):
                for imp in set(type_need[arg]):
                    if imp != '':
                        tmpstr = 8*" " + "import " + imp + os.linesep
                        if '*' in tmpstr:
                            print ">>> * found in import statement:", name," : ignoring"
                            return
                        outstr += tmpstr
        outstr += 8*" " + "implicit none" + os.linesep

        # Write all arguments
        for arg in arglist:
            outstr += 8*" " + type_dict[arg] + " :: " + arg + os.linesep

        # Write the return value
        if rettype:
            try:
                decl = rd[rets]
            except:
                decl = "class (*)"
            outstr += 8*" " + decl + " :: res" + os.linesep

        # Write the procedure closure
        outstr += 6*" " + "end " + procedure + safename + os.linesep
        outstr += 4*" " + "end interface" + os.linesep
        outstr += os.linesep

        fd.write( outstr )


########################################################################
#
# UNIT TEST SECTION
#
########################################################################
def executeUnitTests():

    import unittest

#=======================================================================
    class TestParsedObjects(unittest.TestCase):
#=======================================================================
        def setUp(self): pass
        def tearDown(self): pass

        def testParsedEnum(self):
            """Tests basic parsed enum to ensure proper actions"""

            enum_define = Cgram.CENUMBNF

            try:
                match = enum_define.parseString("enum myEnum {item1 = 0,item2,item3};")
            except:
                self.fail("String was not parsed")
            a = ParsedEnum(match)
            self.failUnlessEqual(a.name(),"myEnum", "Enum name incorrect")
            self.failUnlessEqual(a.nameC(),"myEnum", "Enum nameC incorrect")
            self.failUnlessEqual(a.nameSpec(),"enum myEnum", "Enum nameSpec incorrect")
            self.failUnlessEqual(a.firstItem(),"item1", "Enum firstItem incorrect")
            self.failUnlessEqual(a[0],["item1","0"], "Enum a[0] incorrect")
            self.failUnlessEqual(a[1],"item2", "Enum a[1] incorrect")
            self.failUnlessEqual(a[2],"item3", "Enum a[2] incorrect")
            self.assertTrue(a.nameSpec2() is None, "Enum nameSpec2 incorrect")
            self.assertFalse(a.istypedefed(), "Enum istypedefed incorrect")

            try:
                match = enum_define.parseString("typedef enum myEnum {} anenum_t;")
            except:
                self.fail("String was not parsed")
            a = ParsedEnum(match)
            self.failUnlessEqual(a.name(),"myEnum", "Enum name incorrect")
            self.failUnlessEqual(a.nameC(),"myEnum", "Enum nameC incorrect")
            self.failUnlessEqual(a.nameSpec(),"enum myEnum", "Enum nameSpec incorrect")
            self.assertTrue(a.firstItem() is None, "Enum firstItem incorrect")
            self.failUnlessEqual(a.nameSpec2(), "anenum_t", "Enum nameSpec2 incorrect")
            self.assertTrue(a.istypedefed(), "Enum istypedefed incorrect")


    suite = unittest.TestLoader().loadTestsFromTestCase(TestParsedObjects)
    unittest.TextTestRunner(verbosity=2).run(suite)

    exit()


########################################################################
#
# EXECUTION SECTION
#
########################################################################
(options, args) = parser.parse_args()

# Check for unit-tests
if options.test: executeUnitTests()

#=======================================================================
# Initialize
#=======================================================================
# Store options to friendlier locations

incdir = options.includedir
logfile = options.logfile
preprocess = options.pp_process
if options.wrapper: options.module = True

modifiers = dict()
if options.resolvefile:
    try:
        fd = open(options.resolvefile,'r')
        rdat = fd.readlines()
        fd.close()
        dat = "".join(rdat)
        for m,s,e in PROTOMODIFIER.scanString(dat):
            a = ProtoModifier(m)
            nam = a.name()
            modifiers[nam] = a
    except:
        print options.resolvefile," not read due to failure in opening/parsing"

#-----------------------------------------------------------------------
# Determine which files to parse
#-----------------------------------------------------------------------
if len(options.filelist) > 0:
    filelist = options.filelist
else:
    filelist = locate("*.h",incdir)

#-----------------------------------------------------------------------
# Open a log file or stdout (default)
#-----------------------------------------------------------------------
if logfile:
    lf = open(logfile,'w')
else:
    lf = sys.stdout

#-----------------------------------------------------------------------
# Set up actions to take if preprocessing
#-----------------------------------------------------------------------
constant_define = pp.Group(m4gram.CONSTANTDEFINE)
enum_define = Cgram.CENUMBNF
struct_define = Cgram.CSTRUCTBNF
struct_proto = pp.Group(Cgram.STRUCTPROTOTYPE)
typedef_define = Cgram.TYPEDEFBNF
proto_define = Cgram.GPROTOBNF

if preprocess:
    enum_define.ignore( m4gram.POUNDLINE ) # Makes parsing slow
    struct_define.ignore( m4gram.POUNDLINE ) # Makes parsing slow
    #typedef_define.ignore( m4gram.POUNDLINE ) # Makes parsing slow

    proto_define = Cgram.PROTOBNF # This BNF only works with preprocessed source
    #proto_define.ignore( m4gram.POUNDLINE ) # Makes parsing slow

    # Preprocessor flags
    cpp_command = " ".join([options.pp_preprocessor,options.pp_preprocflag])

    # Command line defines
    for d in options.pp_defines:
        cpp_command += "".join([" -D",d])

    # Include directories
    if incdir: cpp_command += "".join([" -I",incdir])
    for i in options.pp_includes:
        cpp_command += "".join([" -I",i])

# Members of the scanlist are tuples containing several entries:
# 0) A flag indicating whether the item should be parsed
# 1) A name string
# 2) A grammar
# 3) A class which stores/manipulates the data
# 4) A flag indicating whether the preprocessed data should be used
scanlist = [(options.ex_defines, "Defines", constant_define, ParsedDefine, False), \
            (options.ex_enums, "Enums", enum_define, ParsedEnum, True), \
            (options.ex_structs, "Struct Prototypes", struct_proto, 
             ParsedStructPrototype, True), \
            (options.ex_structs, "Structs", struct_define, ParsedStruct, True), \
            (options.ex_typedefs, "Typedefs", typedef_define, ParsedTypedef, True), \
            (options.ex_prototypes, "Prototypes", proto_define, ParsedProto, True)]
#=======================================================================
# Process the files
#=======================================================================
# Establish a dictionary for storing all the results so that they can be
# used for resolution of types.
resolution = dict()
toimport = dict()

# Set up the wrapper module
if options.wrapper:
    wfd = open(options.wrapper+'.f03','w')
    printHeader(wfd,"module "+options.wrapper, char="@", firstChar="!")

# Parse each file
for f in filelist:

    fnam = rearrangeUnderscore((os.path.basename(f)).replace(".","_"))
    if options.wrapper: wfd.write("use "+fnam+os.linesep)

    if logfile:
        sys.stdout.write("Processing... " + f + os.linesep)
    printHeader(lf, f, char="=")

    #-------------------------------------------------------------------
    # Read file
    #-------------------------------------------------------------------
    # Data lines will be stored in fdat
    fd = open(f,'r')
    fdat = fd.readlines()
    fd.close()
    fdat = "".join(fdat)
    fppdat = fdat # This is in case the user does not want the
                  # preprocessor to run

    #-------------------------------------------------------------------
    # Run the C preprocessor
    #-------------------------------------------------------------------
    # Data lines will be stored in fppdat
    if preprocess:
        cpp_commandf = " ".join([cpp_command,f])
        print "  Preprocessing :: ", cpp_commandf
        fd = subprocess.Popen(shlex.split(cpp_commandf), stdout=subprocess.PIPE)
        (fppdat, stderrdata) = fd.communicate()
        if fd.wait() != 0:
            #raise Exception("Preprocessing subprocess failed for file "+f+os.linesep)
            print "ERROR: FILE "+f+" NOT PREPROCESSED"
            continue
        if options.pp_savefile:
            fd = open('local_' + os.path.basename(f),'w')
            fd.write(fppdat)
            fd.close()

    #-------------------------------------------------------------------
    # Open output module
    #-------------------------------------------------------------------
    # If the user wants modules written, open a module file, otherwise
    # set the file device to standard output.
    if options.module:
        mfd = open(fnam + '.f03', 'w')
        mfd.write('!'+72*'@'+os.linesep+"  module " + 
                  fnam+os.linesep+'!'+72*'@'+os.linesep)
        mfd.write('    use, intrinsic :: ISO_C_BINDING' + os.linesep)
        mfd.write('    implicit none' + 2*os.linesep)
    else:
        mfd = sys.stdout

    #-------------------------------------------------------------------
    # Run scans for enums, typedefs, structs, prototypes, etc
    #-------------------------------------------------------------------
    # ObjectsList -- is used to store each object as it is parsed (i.e. they
    #                are grouped) in the order of parsing of each type.
    # allObjectsList -- is a sortable list which ultimately is used for
    #                   resolution.
    ObjectsList = list()
    allObjectsList = list()
    scan_only_list = [ (n,g,c,r) for s,n,g,c,r in scanlist if s ]
    for name,grammar,cls,req in scan_only_list:
        print "  Scanning for %s..." % ( name, )
        printHeader(lf, name)
        if req:
            dat = fppdat
        else:
            dat = fdat
        for match,start,end in grammar.scanString( dat ):
            # lf.write(str(match) + os.linesep)
            pprint.pprint(match, lf)
            if cls:
                a = cls(match)
                ObjectsList.append(a)
                allObjectsList.append((start, name, a))

    allObjectsList.sort() # This is ordered by start location in file to ensure best resolution
    resolution, toimport, newitems = buildResolutionDict(allObjectsList, resolution, toimport)

    # Grab any new items (only typedefs for now)
    newObjectsList = list()
    for item in newitems:
        for match,start,end in struct_define.scanString(item):
            a = ParsedStruct(match)
            print "Adding a=", a, "to the object lists"
            newObjectsList.append(a)
    
    #-------------------------------------------------------------------
    # Dump Fortran-style entries
    #-------------------------------------------------------------------
    for obj in newObjectsList:
        obj.toFortran(mfd, resolution, toimport)
    for obj in ObjectsList: 
        if isinstance(obj,ParsedEnum):
            obj.toFortran(mfd, resolution, toimport, options.enum_as_parameter )
        elif isinstance(obj,ParsedProto):
            obj.toFortran(mfd, resolution, toimport, modifiers)
        else:
            obj.toFortran(mfd, resolution, toimport)

    #-------------------------------------------------------------------
    # Close output module
    #-------------------------------------------------------------------
    if options.module:
        mfd.write( "  end module " + fnam + os.linesep)
        mfd.close()

if options.wrapper:
    wfd.write("implicit none"+os.linesep)
    wfd.write("end module "+options.wrapper+os.linesep)

if logfile: lf.close()
fd = open('items.txt','w')
printHeader(fd,"Resolution")
for k,v in resolution.items():
   fd.write( str(k)+":"+str(v) + os.linesep)
printHeader(fd,"ToImport")
for k,v in toimport.items():
   fd.write( str(k)+":"+str(v) + os.linesep)
fd.close()

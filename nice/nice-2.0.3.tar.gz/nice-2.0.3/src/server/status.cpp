#include "core.hpp"

void Core::statusWorker(){

	std::string statusintervalstr;
	statusarr["commands"] = {};

	int statusinterval = 30000000;

	if(this->getConfigValue("statusinterval", statusintervalstr)){
		this->logInfo("statusinterval of " + statusintervalstr + " read from config");
		statusinterval = std::stoi(statusintervalstr) * 1000000; // seconds to microseconds
	}else{
		this->logInfo("statusinterval missing from config. Defaulting to 30 seconds");
	}

	while(true){
		usleep(statusinterval);
		this->logInfo("starting status worker cycle");
		this->statusCycle();
		this->logInfo("completed status worker cycle");
	}

}

void Core::statusCycle(){

	std::vector<std::string> commands = this->statusGetCommands();

	for(auto command : commands){

		FILE* statcmd = popen(command.c_str(), "r");

		if (statcmd == nullptr) {
			this->logError("popen failed. failed to stat status job");
				continue;
		}

		char buffer[1028];
    	std::string stattxt;
    
   		while (!feof(statcmd)) {
    		if (fgets(buffer, sizeof(buffer), statcmd) != NULL) stattxt += buffer;
    	}

		int statint = pclose(statcmd);
		int statexitcode = WEXITSTATUS(statint);

		this->statusSetOutput(command, stattxt, statexitcode);

	}


}

void Core::statusAddCommand(std::string statuscommand){

	std::scoped_lock lock(statuslock);
	nlohmann::ordered_json statuselement;

	for (auto command : this->statusarr["commands"]){
		if(command.contains("command") && command["command"].is_string() && command["command"].get<std::string>() == statuscommand){
			return;
		}
	}

	statuselement["command"] = statuscommand;
	statuselement["output"]  = "";
	statuselement["status"]  = -1;
	statuselement["updated"] = 0;

	this->statusarr["commands"] += statuselement;

}

std::vector<std::string> Core::statusGetCommands(){

	std::scoped_lock lock(statuslock);
	std::vector<std::string> commands;

	for (auto command : this->statusarr["commands"]){
		if(command.contains("command") && command["command"].is_string()){
			commands.push_back(command["command"].get<std::string>());
		}
	}

	return commands;
}

void Core::statusSetOutput(std::string statuscommand, std::string output, int status){

	std::scoped_lock lock(statuslock);

	for (int i = 0; i < this->statusarr["commands"].size(); i++){
		if(this->statusarr["commands"][i].contains("command") && this->statusarr["commands"][i]["command"].is_string() && this->statusarr["commands"][i]["command"].get<std::string>() == statuscommand){
			this->statusarr["commands"][i]["status"] = status;
			if(status == 0){
				std::time_t now = time(0);
				this->statusarr["commands"][i]["output"]  = output;
				this->statusarr["commands"][i]["updated"] = now;
			}else{
				this->statusarr["commands"][i]["output"] = "";
				this->statusarr["commands"][i]["updated"] = 0;
			}
			break;
		}
	}
}

bool Core::statusTest(std::string statuscommand, int pid, std::time_t starttime){

	std::scoped_lock lock(statuslock);
	bool returnval = false;

	for (int i = 0; i < this->statusarr["commands"].size(); i++){
		if(this->statusarr["commands"][i].contains("command") && this->statusarr["commands"][i]["command"].is_string() && this->statusarr["commands"][i]["command"].get<std::string>() == statuscommand){
			std::time_t updatetime = this->statusarr["commands"][i]["updated"].get<std::time_t>();
			if(starttime > updatetime){
				returnval = true;
			}else if(this->statusarr["commands"][i]["status"] == 0){
				std::regex reg("\\b(" + std::to_string(pid) + ")\\b");
				std::string output = this->statusarr["commands"][i]["output"].get<std::string>();
				if(std::regex_search(output, reg)){
					returnval = true;
				}
			}
			break;
		}
	}

	return returnval;
}
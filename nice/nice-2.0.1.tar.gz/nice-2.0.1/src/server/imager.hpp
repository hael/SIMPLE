#ifndef IMAGER
#define IMAGER

#include "jpeg_decoder.h"

#include "filesystem.hpp"
#include "core.hpp"

struct MRCFileHeader {
			int 							nx;
			int								ny;
			int								nz;
			int								mode;
			int								nxstart;
			int								nystart;
			int								nzstart;	
			int								mx;
			int								my;
			int								mz;
			float							cellx;
			float							celly;
			float							cellz;
			int								cella;
			int								cellb;
			int								cellg;
			int								mapc;	
			int								mapr;
			int								maps;
			int								dmin;
			int								dmax;
			int								dmean;
			int								ispg;
			int								nsymbt;
			int								extra1;
			int								extra2;
			int								extra3;
			int								extra4;
			int								extra5;
			int								extra6;
			int								extra7;
			int								extra8;
			int								extra9;
			int								extra10;
			int								extra11;
			int								extra12;
			int								extra13;
			int								extra14;
			int								extra15;
			int								extra16;
			int								extra17;
			int								extra18;
			int								extra19;
			int								extra20;
			int								extra21;
			int								extra22;
			int								extra23;
			int								extra24;
			int								extra25;
			int								originx;
			int								originy;
			int								originz;
			char							map[4];
			char							machst[4];
			int								rms;
			int								nlabl;
			char							label1[80];
			char							label2[80];
			char							label3[80];
			char							label4[80];
			char							label5[80];
			char							label6[80];
			char							label7[80];
			char							label8[80];
			char							label9[80];
			char							label10[80];
};
		
struct PPMFileHeader{
	int nx;
	int ny;							
	int headerlength;
};
		
struct JPEGFileHeader{
	int nx;
	int ny;
};

class Imager {
	
	private:
		Core* core;
		float max;
		float min;
		float mean;
		float sd;
		std::string type;
		std::string datatype;
		std::string path;
		int datalength = 0;
		int stkindex;
		int xsprite;
		int ysprite = 0;
		int nxsprite;
		int nysprite = 1;
		int sourcenx;
		int sourceny;
		int targetheight;
		void* header = NULL;
		void* data = NULL;
		std::ifstream fh;
		bool open();
		bool readMRCHeader();
		bool readMRCData();
		bool readJPGHeader();
		bool readJPGData();
		bool maxMinNormalizeMRC();
		bool maxMinNormalizeJPG();
		bool reduceSizeMRC();
		bool reduceSizeJPG();
		std::vector<uint8_t> packMRCData();
		std::vector<uint8_t> packJPGData();
	public:
		Imager(Core* core);
		~Imager();
		bool read(std::string filename, int targetheight, int stkindex = 0, int xsprite = 0, int nxsprite = 0);
		bool maxMinNormalize();
		bool reduceSize();
		nlohmann::ordered_json pack();
};

#endif
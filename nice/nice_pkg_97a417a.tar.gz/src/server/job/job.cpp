#include "job.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Job::Job () {
    this->job_id = -1;
    this->parent_id = -1;
    this->interactive = false;
}

Job::Job (int workspace_id) {
    this->job_id = -1;
    this->parent_id = -1;
    this->interactive = false;
    this->LoadWorkspace(workspace_id);
}

Job::Job (nlohmann::ordered_json args) {
    this->job_id = -1;
    this->parent_id = -1;
    this->interactive = false;
    if(json_test_int(args, "currentjobid")){
        this->LoadJob(args["currentjobid"].get<int>());
    }else if(json_test_int(args, "currentworkspaceid")){
        this->LoadWorkspace(args["currentworkspaceid"].get<int>());
        if(json_test_bool(args, "interactive")){
            this->interactive = args["interactive"].get<bool>();
        }
        if(json_test_string(args, "jobmodule")){
            this->module = args["jobmodule"].get<std::string>();
        }
        if(json_test_string(args, "jobtype")){
            this->type = args["jobtype"].get<std::string>();
        }
        if(json_test_int(args, "parentid")){
            this->parent_id = args["parentid"].get<int>();
        }
        if(json_test_string(args, "jobname")){
            this->job_name = args["jobname"].get<std::string>();
        }
    }
    
}

bool Job::LoadJob(int job_id){
    pqxx::result job = sql_nontx_result("SELECT folder,workspace,type,module,status,displayid,parent,arguments FROM jobs WHERE id=" + std::to_string(job_id) + ";");
    if(job.size() > 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve single job from db");
        this->job_id = -1;
        return false;
    }else if(job.size() < 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve job from db");
        this->job_id = -1;
        return false;
    }
    if(job[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job folder is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job workspace is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][2].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job type is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][3].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job module is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][4].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job status is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][5].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job displayid is null");
        this->job_id = -1;
        return false;
    }
    if(job[0][6].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived job displayid is null");
        this->job_id = -1;
        return false;
    }

    this->LoadWorkspace(job[0][1].as<int>());
    this->job_id     = job_id;
    this->job_folder = this->workspace_folder + "/" + job[0][0].as<std::string>();
    this->job_folder_base = job[0][0].as<std::string>();
    this->type       = job[0][2].as<std::string>();
    this->module     = job[0][3].as<std::string>();
    this->status     = job[0][4].as<std::string>();
    this->display_id = job[0][5].as<int>();
    this->parent_id  = job[0][6].as<int>();
    //load arguments if present and valid json 
    if(!job[0][7].is_null()){
        if(nlohmann::ordered_json::accept(job[0][7].as<std::string>())){
            this->start_arguments = nlohmann::ordered_json::parse(job[0][7].as<std::string>());
        }
    }

    if(this->module == "SIMPLE"){
        Simple* simple = new Simple();
        this->job_arguments = simple->GetArguments(this->type);
        delete simple;
    }

    return true;
}

int Job::CreateJob(){
   if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uninitialised workspace");
        return FAILURE;
    }

    if(!folderExists(this->workspace_folder)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - " + this->workspace_folder + " does not exist");
        return MISSING_FOLDER;
    }

    pqxx::result existing_jobs = sql_nontx_result(std::string_view{"SELECT COUNT(id) FROM jobs WHERE workspace=" + std::to_string(this->workspace_id) + ";"});

    if(existing_jobs.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to count jobs");
        return FAILURE;
    }

    if(existing_jobs[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - existing job count is null");
        return FAILURE;
    }

    int job_display_id = existing_jobs[0][0].as<int>() + 1;

    std::string job_name   = this->job_name;
    std::string job_folder = std::to_string(job_display_id) + "_" + this->type;
    std::string job_path   = this->workspace_folder + "/" + job_folder;

    if(folderExists(job_path)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - " + job_path + " already exists");
        return PREEXISTING_FOLDER;
    }

    if(!ensureFolder(job_path)){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to create "  + job_path);
        return FAILED_MKFOLDER;
    }

    pqxx::result new_job = sql_result(std::string_view{"INSERT INTO jobs (workspace,displayid,name,folder,type,module,status,parent) VALUES "
        "(" + std::to_string(this->workspace_id) + "," + std::to_string(job_display_id) + ",'" + job_name + "','" + job_folder + "','" + this->type + "','" + this->module + "','building'," + std::to_string(this->parent_id) + ") RETURNING id;"});

    if(new_job.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to insert job into database");
        return FAILURE;
    }

    if(new_job[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted job id is null");
        return FAILURE;
    }

    int job_id = new_job[0][0].as<int>();

    if(job_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted job id is invalid");
        return FAILURE;
    }

    if(this->parent_id > 0){
        pqxx::result updated_parent = sql_result(std::string_view{"UPDATE jobs SET children = array_append(children, " + std::to_string(job_id) + ") WHERE id=" + std::to_string(this->parent_id) + ";"});
    }

    if(this->module == "SIMPLE"){
        Simple* simple = new Simple();
        this->job_arguments = simple->GetArguments(this->type);
        delete simple;
    }

    this->job_id     = job_id;
    this->display_id = job_display_id;
    this->job_folder = job_path;

    return SUCCESS;
}

int Job::Start(nlohmann::ordered_json args, std::string comm_addr_str, bool local){
    if(this->job_id < 0){
        this->CreateJob();
    }
    std::vector<int> processes;
    if(this->module == "SIMPLE"){
        Simple* simple = new Simple();
        std::string parent_jobfolder = "";
        if(this->parent_id > 0){
            Job* parent_job = new Job();
            parent_job->LoadJob(this->parent_id);
            parent_jobfolder = parent_job->job_folder;
            delete parent_job;
        }
        processes = simple->Queue(this->type, this->job_folder, args, -1, this->parent_id, parent_jobfolder, comm_addr_str, local); // TODO: update template id from input
        delete simple;
    }
    std::string processes_array = "ARRAY[";
    for(auto process : processes){
        processes_array += std::to_string(process) + ",";
    }
    processes_array.pop_back(); // remove trailing comma
    processes_array += ']';
    sql_request(std::string_view{"UPDATE jobs SET processes=" + processes_array + ",arguments='" + args["jobargs"].dump() + "',status='queued' WHERE id=" + std::to_string(this->job_id) + ";" });
    this->status = "queued";
    this->start_arguments = args["jobargs"];
    return SUCCESS;
}

nlohmann::ordered_json Job::TreeJobs(nlohmann::ordered_json joblist) {
    nlohmann::ordered_json returnarray = {};
    for (auto it = joblist.rbegin(); it != joblist.rend(); ++it) {
        if(it->contains("children")){
            for (auto it2 = it->at("children").rbegin(); it2 != it->at("children").rend(); ++it2) {
                int childid = it2->get<int>();
                auto p1 = joblist["J" + std::to_string(childid)].get_ptr<nlohmann::ordered_json::object_t*>();
                *it2 = *p1;
            }
        }
    }
    for (auto it = joblist.begin(); it != joblist.end(); ++it) {
        if(it->contains("parent") && it->at("parent").get<int>() < 0){
            returnarray.push_back(*it);
        }
    }
    return returnarray;
}

std::string Job::UpdateStatus(int job_id){
    bool failed    = false;
    bool running   = false;
    bool submitted = false;
    bool queued    = false;
    bool finished  = false;
    bool has_proc  = false;

    pqxx::result processes = sql_nontx_result(std::string_view{"SELECT status FROM processes WHERE id = ANY(ARRAY(SELECT processes FROM jobs WHERE id=" + std::to_string(job_id) + ")) ORDER BY id;"});
    for (pqxx::result::const_iterator process = processes.begin(); process != processes.end(); ++process) {
        has_proc = true;
        nlohmann::ordered_json process_json;
        // missing name 
        if(process[0].is_null()) continue;
        std::string process_status = process[0].as<std::string>();
        if(process_status == "failed"){
            failed = true;
        }else if(process_status == "running"){
            running = true;
        }else if(process_status == "submitted"){
            submitted = true;
        }else if(process_status == "queued"){
            queued = true;
        }else if(process_status == "finished"){
            finished = true;
        }
    }
    if(! has_proc) return this->status;
    
    if(failed){
        if(this->type == "stream"){
            pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='failed_stream' WHERE id = " + std::to_string(job_id) + ";"});
            if(update.size() != 1){
                spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
            }
            return "alert";
        }else{
            pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='failed' WHERE id = " + std::to_string(job_id) + ";"});
            if(update.size() != 1){
                spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
            }
            return "failed";
        }
    }else if(running){
        return "running";
    }else if(submitted){
        return "submitted";
    }else if(queued){
        return "queued";
    }else if(finished){
        pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='finished' WHERE id = " + std::to_string(job_id) + ";"});
        if(update.size() != 1){
            spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
        } 
        return "finished";
    }else{
        pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='unknown' WHERE id = " + std::to_string(job_id) + ";"});
        if(update.size() != 1){
            spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
        }
        return "unknown";
    }
}

void Job::SetFinished(){
    pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='finished' WHERE id = " + std::to_string(this->job_id) + ";"});
    if(update.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
    } 
}

void Job::SetDeleted(){
    pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET deleted=TRUE WHERE id = " + std::to_string(this->job_id) + ";"});
    if(update.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update deleted for job id " +  std::to_string(job_id));
    } 
}

void Job::SetRetrievable(){
    pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET retrievable=TRUE WHERE id = " + std::to_string(this->job_id) + ";"});
    if(update.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update retrievable for job id " +  std::to_string(job_id));
    } 
}

void Job::SetRetrieve(){
    pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET retrieve=TRUE WHERE id = " + std::to_string(this->job_id) + ";"});
    if(update.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update retrieve for job id " +  std::to_string(job_id));
    } 
}

void Job::SetQueued(){
    pqxx::result update = sql_nontx_result(std::string_view{"UPDATE jobs SET status='queued' WHERE id = " + std::to_string(this->job_id) + ";"});
    if(update.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to update status for job id " +  std::to_string(job_id));
    } 
}

void Job::SetRestart(){
    pqxx::result processes = sql_nontx_result(std::string_view{"UPDATE processes SET status='restarting',userinput=FALSE,endtime=NULL,restart=TRUE WHERE id = ANY(ARRAY(SELECT processes FROM jobs WHERE id=" + std::to_string(this->job_id) + ")) ORDER BY id;"});
    if(processes.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to restart processed for job id " +  std::to_string(job_id));
    }
    processes = sql_nontx_result(std::string_view{"UPDATE jobs SET status='restarting',diskspacemb=0 WHERE id=" + std::to_string(this->job_id) + ";"});
    if(processes.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to restart job id " +  std::to_string(job_id));
    }
}

nlohmann::ordered_json Job::ListJobs() {
    nlohmann::ordered_json returnjson;
    nlohmann::ordered_json jobs_json;
    pqxx::result jobs = sql_nontx_result(std::string_view{"SELECT id,displayid,parent,name,module,type,folder,status,deleted,retrievable,children FROM jobs WHERE workspace=" + std::to_string(this->workspace_id) + " ORDER BY id;"});
    for (pqxx::result::const_iterator job = jobs.begin(); job != jobs.end(); ++job) {
        nlohmann::ordered_json job_json;
        if(job[0].is_null() || job[1].is_null() || job[2].is_null()) continue;
        int jobid = job[0].as<int>();
        job_json["id"] = jobid;
        job_json["displayid"] = job[1].as<int>();
        job_json["parent"]    = job[2].as<int>();
        if(!job[3].is_null()) job_json["name"]   = job[3].as<std::string>();
        if(!job[4].is_null()) job_json["module"] = job[4].as<std::string>();
        if(!job[5].is_null()) {
            job_json["type"]   = job[5].as<std::string>();
            this->type = job[5].as<std::string>();
        }else{
            this->type = "";
        }
        if(!job[6].is_null()) job_json["folder"] = job[6].as<std::string>();
        if(!job[9].is_null() && job[9].get<bool>() == true){
            job_json["status"] = "retrievable";
        }else if(!job[8].is_null() && job[8].get<bool>() == true){
            job_json["status"] = "deleted";
        }else if(job[7].is_null() || (job[7].as<std::string>() != "finished" && job[7].as<std::string>() != "failed")){
            // retrieve and update status
            job_json["status"] = this->UpdateStatus(jobid); // move status update to data handler
        }else{
            job_json["status"] = job[7].as<std::string>();
        }
        if(!job[10].is_null()){
            job_json["children"] = {};
            auto children_arr = job[10].as_array();
            std::pair<pqxx::array_parser::juncture, std::string> elem;
            do{
                elem = children_arr.get_next();
                if (elem.first == pqxx::array_parser::juncture::string_value)
                    job_json["children"].push_back(std::stoul(elem.second));
            } while (elem.first != pqxx::array_parser::juncture::done);
        }
        jobs_json["J" + std::to_string(jobid)] = job_json;
    }
    returnjson["workspaceid"] = this->workspace_id;
    returnjson["jobtree"]     = this->TreeJobs(jobs_json);
    returnjson["success"]     = true;
    return returnjson;
}

nlohmann::ordered_json Job::ListBuildableJobs() {
    nlohmann::ordered_json returnjson;
    returnjson["modules"] = {};
    Simple* simple = new Simple();
    if(simple->ReadJobJson()){
        returnjson["modules"][simple->module] = simple->joblist;
    }
    delete simple;
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::BuildJob() {
    nlohmann::ordered_json returnjson;
    Simple* simple = new Simple();
    if(simple->ReadJobJson()){
        if(json_test_object(simple->jobargs, this->type)){
            returnjson["buildargs"] = simple->jobargs[this->type];
        }
    }
    delete simple;
    if(!this->start_arguments.empty()){
        returnjson["jobargs"] = this->start_arguments;
    }
    returnjson["success"] = true;
    return returnjson;
}


nlohmann::ordered_json Job::NewJob(){
    nlohmann::ordered_json returnjson;
    int create = this->CreateJob();
    if(create > 0){
        returnjson["success"] = false;
        if(create == FAILURE){
            // generic error
        }else if(create == PREEXISTING_PROJECT){
            // project exists
            returnjson["projectexists"] = true;
        }else if(create == PREEXISTING_FOLDER){
            // folder exists
            returnjson["folderexists"] = true;
        }else if(create == MISSING_FOLDER){
            // folder missing
            returnjson["foldermissing"] = true;
        }else if(create == FAILED_MKFOLDER){
            // folder missing
        }
    }else{
        returnjson["success"] = true;
    }
    return returnjson;
}

nlohmann::ordered_json Job::StatJob(){
    nlohmann::ordered_json returnjson;
    if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid workspace id");
        returnjson["success"] = false; 
    }else if(this->job_id < 0 && this->interactive){
        if(this->type == ""){
            returnjson["success"] = false;
            spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing job type");
            return returnjson;
        }
        if(this->module == ""){
            returnjson["success"] = false;
            spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing job module");
            return returnjson;
        }
        // interactive jobs without job id set need creating
        int create = this->CreateJob();
        if(create > 0){
            returnjson["success"] = false;
            if(create == FAILURE){
                // generic error
            }else if(create == PREEXISTING_PROJECT){
                // project exists
                returnjson["projectexists"] = true;
            }else if(create == PREEXISTING_FOLDER){
                // folder exists
                returnjson["folderexists"] = true;
            }else if(create == MISSING_FOLDER){
                // folder missing
                returnjson["foldermissing"] = true;
            }else if(create == FAILED_MKFOLDER){
                // folder missing
                returnjson["folderfail"] = true;
            }
            return returnjson;
        }
    }
    
    bool globallog = false;
    std::string stdout;
    if(fileExists(this->job_folder + "/nice_" + this->type + ".log")){
       stdout = ReadTextFile(this->job_folder + "/nice_" + this->type + ".log");
       globallog = true;
    }

    std::string stderr;
    if(fileExists(this->job_folder + "/nice_" + this->type + ".error")){
       stderr = ReadTextFile(this->job_folder + "/nice_" + this->type + ".error");
       globallog = true;
    }

    nlohmann::ordered_json processes_json = {};

    if(this->status != "building"){
        pqxx::result processes = sql_nontx_result(std::string_view{"SELECT id,name,status,userinput,stat,uservals FROM processes WHERE id = ANY(ARRAY(SELECT processes FROM jobs WHERE id=" + std::to_string(this->job_id) + ")) ORDER BY id;"});
        for (pqxx::result::const_iterator process = processes.begin(); process != processes.end(); ++process) {
            nlohmann::ordered_json process_json;
            // missing id
            if(process[0].is_null()) continue;
            // missing name
            if(process[1].is_null()) continue;
            int process_id = process[0].as<int>();
            std::string process_name = process[1].as<std::string>();
            process_json["id"] = process_id;
            if(!process[2].is_null()) process_json["status"] = process[2].as<std::string>();
            if(!process[3].is_null()) process_json["userinput"] = process[3].as<bool>();
            if(!process[4].is_null() && nlohmann::ordered_json::accept(process[4].as<std::string>())){
                process_json["stat"] = nlohmann::ordered_json::parse(process[4].as<std::string>());
            }else{
                if(this->module == "SIMPLE"){
                    Simple* simple = new Simple();
                    process_json["stat"] = simple->ProjectHeaderJson(this->job_folder);
                    delete simple;
                }
            }
            if(!process[5].is_null() && nlohmann::ordered_json::accept(process[5].as<std::string>())){
                process_json["uservals"] = nlohmann::ordered_json::parse(process[5].as<std::string>());
            }
            if(!globallog){
                if(fileExists(this->job_folder + "/nice_" + process_name + ".log")){
                  //  process_json["stdout"] = ReadTextFile(this->job_folder + "/nice_" + process_name + ".log"); 
                    process_json["stdout"] = this->job_folder + "/nice_" + process_name + ".log";
                }
                if(fileExists(this->job_folder + "/nice_" + process_name + ".error")){
                   // process_json["stderr"] = ReadTextFile(this->job_folder + "/nice_" + process_name + ".error"); 
                    process_json["stderr"] = this->job_folder + "/nice_" + process_name + ".error";
                }
            }
            processes_json[process_name] = process_json;
        }
    }

    nlohmann::ordered_json job_arguments = this->job_arguments;

    if(!this->start_arguments.empty()){
        for(auto& section_it : job_arguments.items()){
            for(auto& argument_it : section_it.value().items()){
                argument_it.value().emplace("disabled", true);
                if(argument_it.value().contains("key")){
                    std::string key = argument_it.value()["key"].get<std::string>();
                    if(this->start_arguments.contains(key)){
                        if(this->start_arguments[key].is_string()){
                            argument_it.value().emplace("value", this->start_arguments[key].get<std::string>());
                        }else if(this->start_arguments[key].is_number_float()){
                            argument_it.value().emplace("value", this->start_arguments[key].get<float>());
                        }else if(this->start_arguments[key].is_number_integer()){
                            argument_it.value().emplace("value", this->start_arguments[key].get<int>());
                        }else if(this->start_arguments[key].is_boolean()){
                            argument_it.value().emplace("value", this->start_arguments[key].get<bool>());
                        }
                    }
                }
            }
        }
    }

    returnjson["jobstats"] = {};
    returnjson["jobstats"]["id"]        = this->job_id;
    returnjson["jobstats"]["displayid"] = this->display_id;
    returnjson["jobstats"]["folder"]    = this->job_folder;
    returnjson["jobstats"]["name"]      = this->job_name;
    returnjson["jobstats"]["type"]      = this->type;
    returnjson["jobstats"]["status"]    = this->status;
    returnjson["jobstats"]["arguments"] = job_arguments;
    returnjson["jobstats"]["processes"] = processes_json;
    returnjson["jobstats"]["stdout"]    = stdout;
    returnjson["jobstats"]["stderr"]    = stderr;
    returnjson["success"] = true;   

    return returnjson;
}

nlohmann::ordered_json Job::StatJobData(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;
    if(this->workspace_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid workspace id");
        returnjson["success"] = false; 
    }else if(this->job_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid job id");
        returnjson["success"] = false; 
    }

    returnjson["success"] = true;

    if(this->module == "SIMPLE"){
        Simple* simple = new Simple();
        if(!simple->ProjectDataJson(&returnjson, this->job_folder, args)){
           returnjson["success"] = false; 
        }
        delete simple;
    }

    return returnjson;
}

nlohmann::ordered_json Job::StatHeadlinesJob(){
    nlohmann::ordered_json returnjson;
    if(this->job_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid job id");
        returnjson["success"] = false; 
        return returnjson;
    }
    returnjson["status"]        = {};
    returnjson["headlinestats"] = {};

    if(this->status != "building"){
        pqxx::result processes = sql_nontx_result(std::string_view{"SELECT id,name,status,stat FROM processes WHERE id = ANY(ARRAY(SELECT processes FROM jobs WHERE id=" + std::to_string(this->job_id) + ")) ORDER BY id;"});
        for (pqxx::result::const_iterator process = processes.begin(); process != processes.end(); ++process) {
            if(process[0].is_null()) continue;
            int process_id = process[0].as<int>();
            if(process[1].is_null()) continue;
            std::string process_name = process[1].as<std::string>();
            if(!process[2].is_null()) returnjson["status"][process_name] = process[2].as<std::string>();
            if(!process[3].is_null() && nlohmann::ordered_json::accept(process[3].as<std::string>())){
                nlohmann::ordered_json process_stat = nlohmann::ordered_json::parse(process[3].as<std::string>());
                if(json_test_object(process_stat, "headlinestats")){
                    returnjson["headlinestats"].merge_patch(process_stat["headlinestats"]); 
                }
            }
        }

        nlohmann::ordered_json thumbnails;
        json_recursive_iterate(returnjson["headlinestats"], [&thumbnails](nlohmann::ordered_json::const_iterator it){
            if(it->is_object() && it.key() == "thumbnail" && json_test_string(it.value(), "uid")){
                std::string uid = it.value()["uid"].get<std::string>();
                thumbnails.push_back(uid);
            }
        });

        returnjson["thumbnails"] = thumbnails;

        if(this->module == "SIMPLE"){
            Simple* simple = new Simple();
            this->job_arguments = simple->GetArguments(this->type);
            delete simple;
            if(!this->start_arguments.empty()){
                nlohmann::ordered_json arguments;
                for (auto& el : this->start_arguments.items()){
                    std::string key = el.key();
                    std::string val;
                    if(el.value().is_boolean()){
                        if(el.value().get<bool>()){
                            val = "yes";
                        }else{
                            val = "no";
                        }
                    }else{  
                        val = el.value();
                    }
                    json_recursive_iterate(this->job_arguments, [&arguments, key, val](nlohmann::ordered_json::const_iterator it){
                        if(it.value().contains("key") && json_test_string(it.value(), "key") && it.value()["key"].get<std::string>() == key){
                            if(it.value().contains("descr_short") && json_test_string(it.value(), "descr_short")){
                                arguments[it.value()["descr_short"].get<std::string>()] = val;
                            }
                        }
                    });
                }
                returnjson["arguments"] = arguments;
            }
        }

        pqxx::result timings = sql_nontx_result(std::string_view{"SELECT TO_CHAR((COALESCE(endtime, NOW()) - COALESCE(starttime, NOW())), 'HH24:MI:SS' ) AS elapsed, TO_CHAR(queuetime,'YYYY/MM/DD HH24:MI:SS') AS queuetime, TO_CHAR(starttime,'YYYY/MM/DD HH24:MI:SS') AS starttime, TO_CHAR(endtime,'YYYY/MM/DD HH24:MI:SS') AS endtime FROM processes WHERE id = ANY(ARRAY(SELECT processes FROM jobs WHERE id=" + std::to_string(this->job_id) + ")) order by queuetime limit 1"});

        if(timings.size() == 1){
            if(!timings[0][0].is_null()) returnjson["status"]["elapsed"]    = timings[0][0].as<std::string>();
            if(!timings[0][1].is_null()) returnjson["status"]["queue_time"] = timings[0][1].as<std::string>();
            if(!timings[0][2].is_null()) returnjson["status"]["start_time"] = timings[0][2].as<std::string>();
            if(!timings[0][3].is_null()) returnjson["status"]["end_time"]   = timings[0][3].as<std::string>();
        }
    }
   
    returnjson["success"] = true; 

    return returnjson;
}

nlohmann::ordered_json Job::StartJob(nlohmann::ordered_json args, std::string comm_addr_str, bool local){
    nlohmann::ordered_json returnjson;

    if(!json_test_object(args, "jobargs")){
        returnjson["success"] = false;
        return returnjson;
    }
    for(auto& [key, val] : args["jobargs"].items()){
        for(auto& [section, sectionval] : this->job_arguments.items()){
            for(auto& [argkey, argval] : sectionval.items()){
                if(json_test_string(argval, "key") && json_test_string(argval, "keytype")){
                    if(argval["key"].get<std::string>() == key){
                        if(argval["keytype"].get<std::string>() == "dir"){
                            if(!folderExists(val)){
                                returnjson["success"] = false;
                                returnjson["missingdir"] = key;
                                return returnjson;
                            }
                        }else if(argval["keytype"].get<std::string>() == "file"){
                            if(!fileExists(val)){
                                returnjson["success"] = false;
                                returnjson["missingfile"] = key;
                                return returnjson;
                            }
                        }
                    }
                }
            }
        }
    }
    this->Start(args, comm_addr_str,local);
    returnjson = this->StatJob();
    return returnjson;
}

nlohmann::ordered_json Job::RenameJob(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;
    if(!json_test_string(args, "jobname")){
        returnjson["success"] = false;
        return returnjson;
    }
    std::string job_name = args["jobname"].get<std::string>();
    sql_request(std::string_view{"UPDATE jobs SET name='" + job_name + "' WHERE id=" + std::to_string(this->job_id) + ";" });
    this->job_name = job_name;
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::DeleteJob(){
    nlohmann::ordered_json returnjson;
    this->SetDeleted();
    this->SetRetrievable();
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::RetrieveJob(){
    nlohmann::ordered_json returnjson;
    this->SetRetrieve();
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::RestartJob(){
    nlohmann::ordered_json returnjson;
    this->SetRestart();
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::CompleteProcesses(){
    nlohmann::ordered_json returnjson;
    if(this->module == "SIMPLE"){
        sql_request(std::string_view{"UPDATE processes SET updatearguments='{\"exit\":true}' WHERE id=ANY((SELECT processes FROM jobs WHERE module='SIMPLE' and id=" + std::to_string(this->job_id) + ")::BIGINT[]);" });
        if(this->type == "stream"){
            Simple* simple = new Simple();
            simple->LinkStream(this->job_folder);
            delete simple;
        }
    }
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Job::Complete(){
    nlohmann::ordered_json returnjson;
    this->SetFinished();
    returnjson["success"] = true;
    return returnjson;
}
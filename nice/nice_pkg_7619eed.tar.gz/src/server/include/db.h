#ifndef DB_H
#define DB_H

#include <string>
#include <pqxx/pqxx>


inline void sql_request(std::string_view sql){
	try{
		pqxx::connection c("dbname=nice");
		pqxx::work tx(c);
	    std::cout << "Connected to " << c.dbname() << '\n';
	     std::cout << "SQL " << sql << '\n';
	    pqxx::result result = tx.exec(sql);
	    tx.commit();
	    c.close();
	}catch (std::exception const &e){
        std::cerr << "ERROR: " << e.what() << '\n';
    }
}

inline void sql_request(std::string sql, std::basic_string<std::byte> bin_data){
	try{
		pqxx::connection c("dbname=nice");
		c.prepare("binary_sql", sql.c_str());
		pqxx::work tx(c);
	    std::cout << "Connected to " << c.dbname() << '\n';
	    pqxx::result r = tx.exec_prepared("binary_sql", bin_data);
	    tx.commit();
		c.close();
	}catch (std::exception const &e){
        std::cerr << "ERROR: " << e.what() << '\n';
    }
}

inline pqxx::result sql_result(std::string_view sql){
	pqxx::result result;
	try{
		pqxx::connection c("dbname=nice");
		pqxx::work tx(c);
	    std::cout << "Connected to " << c.dbname() << '\n';
	    result = tx.exec(sql);
	    tx.commit();
	    c.close();
	}catch (std::exception const &e){
        std::cerr << "ERROR: " << e.what() << '\n';
    }
    return result;
}

inline pqxx::result sql_nontx_result(std::string_view sql){
	pqxx::result result;
	try{
		pqxx::connection c("dbname=nice");
		pqxx::nontransaction ntx(c);
	    result = ntx.exec(sql);
	    c.close();
	}catch (std::exception const &e){
        std::cerr << "ERROR: " << e.what() << '\n';
    }
    return result;
}



#endif
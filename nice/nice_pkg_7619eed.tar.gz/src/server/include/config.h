#ifndef CONFIG_H
#define CONFIG_H

#include <iostream>
#include <thread>
#include <filesystem.h>
#include <sys.h>
#include <db.h>
#include <json.hpp>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/rotating_file_sink.h>

inline static nlohmann::ordered_json RetreiveConfig(){
	// always load latest config
	nlohmann::ordered_json config_json;
	pqxx::result config = sql_nontx_result("SELECT config FROM config ORDER BY id DESC LIMIT 1;");
	if(!config[0][0].is_null()){
        if(nlohmann::ordered_json::accept(config[0][0].as<std::string>())){
            config_json = nlohmann::ordered_json::parse(config[0][0].as<std::string>());
        }
    }
    return config_json;
}

inline static bool LoadConfig(std::string configpath){
	//log to stdout as command line 
	if(!fileExists(configpath)){
		std::cout << configpath << " does not exist" << std::endl;
		return false;
	}
	nlohmann::ordered_json config;
	std::ifstream config_fd;
    config_fd.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
    try{
        config_fd.open(configpath);
        if(nlohmann::ordered_json::accept(config_fd)){
            // return to fd start
            config_fd.clear();
            config_fd.seekg(0);
            // parse
            config = nlohmann::ordered_json::parse(config_fd);
        }else{
            std::cout << "Invalid JSON in config file " + configpath << std::endl;
            return false;
        }
    }catch (const nlohmann::ordered_json::parse_error& e){
        std::cout << "failed to parse JSON config file" << std::endl;
        return false;
    }catch (std::ofstream::failure e) {
        std::cout << "fstream failure to open control json" << std::endl;
        return false;
    }
    if(config_fd.is_open()) config_fd.close();

    pqxx::result new_config = sql_result(std::string_view{"INSERT INTO config (config) VALUES ('" + config.dump() + "') RETURNING id;"});

    if(new_config.size() != 1){
    	std::cout << "failed to insert config into database" << std::endl;
    	return false;
    }

    if(new_config[0][0].is_null()){
        std::cout << "inserted config id is null" << std::endl;
        return false;
    }

    return true;
}

inline static bool LoadTemplate(std::string name, std::string submitcommand, std::string defaulttemplate, std::string templatepath){
	//log to stdout as command line 
	if(!fileExists(templatepath)){
		std::cout << templatepath << " does not exist" << std::endl;
		return false;
	}
	std::string templatestring;
	std::ifstream templatefile;
	try{
		templatefile.open(templatepath);

		if(!templatefile){
			std::cout << "fstream failed to open template" << std::endl;
			return false;
		}

	 	std::ostringstream templatefiless;
	    templatefiless << templatefile.rdbuf();
	    templatestring = templatefiless.str();
	}catch (std::ifstream::failure e) {
   		std::cout << "fstream failure to open cluster template" << std::endl;
  	}
	
	if(templatefile.is_open())  templatefile.close();

	if(templatestring.find("'") != std::string::npos){
		std::cout << "template cannot contain the ' character" << std::endl;
		return false;
	}

	pqxx::result new_template = sql_result(std::string_view{"INSERT INTO templates (name, submitcommand, defaulttemplate, template) VALUES ('" + name + "','" + submitcommand + "'," + defaulttemplate + ",'" + templatestring + "') RETURNING id;"});

    if(new_template.size() != 1){
    	std::cout << "failed to insert template into database" << std::endl;
    	return false;
    }

   
    if(new_template[0][0].is_null()){
        std::cout << "inserted template id is null" << std::endl;
        return false;
    }

    int template_id = new_template[0][0].as<int>();

    if(defaulttemplate == "TRUE"){
    	pqxx::result reset_default = sql_result(std::string_view{"UPDATE templates SET defaulttemplate=FALSE;"});
    	reset_default = sql_result(std::string_view{"UPDATE templates SET defaulttemplate=TRUE WHERE id=" + std::to_string(template_id) + ";"});
    }

    return true;
}

inline static void PrintTemplates(){
	pqxx::result templates = sql_nontx_result("SELECT id, name, submitcommand, defaulttemplate, template FROM templates ORDER BY id;");
	for (pqxx::result::const_iterator tmplt = templates.begin(); tmplt != templates.end(); ++tmplt) {
        nlohmann::ordered_json process_json;
        if(tmplt[0].is_null()) continue;
      	if(tmplt[1].is_null()) continue;
      	if(tmplt[2].is_null()) continue;
      	if(tmplt[3].is_null()) continue;
      	if(tmplt[4].is_null()) continue;
      	std::cout << std::endl;
      	std::cout << "================================" << std::endl;
     	std::cout << "========== TEMPLATE " + std::to_string(tmplt[0].as<int>()) + " ==========" << std::endl;
     	std::cout << "================================" << std::endl;
     	std::cout << "template name : "  + tmplt[1].as<std::string>() << std::endl;
     	bool dflt = tmplt[3].as<bool>();
     	if(dflt){
     		std::cout << "default : TRUE" << std::endl;
     	}else{
     		std::cout << "default : FALSE" << std::endl;
     	}
     	std::cout << "submit command : "  + tmplt[2].as<std::string>() << std::endl;
     	std::cout << std::endl;
     	std::cout << tmplt[4].as<std::string>() << std::endl;
     	std::cout << std::endl;
     	std::cout << "================================" << std::endl;
     }
}


inline static void ListUsers(){
	pqxx::result users = sql_nontx_result("SELECT id,username,firstname,lastname,admin FROM users ORDER BY id;");
	std::cout << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << "============= USERS ============" << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << std::setw(20) << "username" <<  std::setw(20) << "firstname" << std::setw(20) << "lastname" << std::setw(10) << "admin" << std::endl;  
    std::cout << std::endl;
	for (pqxx::result::const_iterator user = users.begin(); user != users.end(); ++user) {
        nlohmann::ordered_json process_json;
        if(user[0].is_null()) continue;
      	if(user[1].is_null()) continue;
      	if(user[2].is_null()) continue;
      	if(user[3].is_null()) continue;
      	if(user[4].is_null()) continue;
      	bool admin = user[4].as<bool>();
     	if(admin){
   			std::cout << std::setw(20) << user[1].as<std::string>() <<  std::setw(20) << user[2].as<std::string>() << std::setw(20) << user[3].as<std::string>() << std::setw(10) << "TRUE" << std::endl;
   		}else{
   			std::cout << std::setw(20) << user[1].as<std::string>() <<  std::setw(20) << user[2].as<std::string>() << std::setw(20) << user[3].as<std::string>() << std::setw(10) << "FALSE" << std::endl;
   		}
    }
    std::cout << std::endl;
    std::cout << "================================" << std::endl;
}

#endif
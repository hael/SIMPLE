#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

#include <iostream>
#include <thread>
#include <ctime>
#include <map>
#include <json.hpp>
#include <sys.h>
#include <db.h>
#include <io.h>
#include <json_helpers.h>
#include <project.h>
#include <workspace.h>
#include <job.h>
#include <simple.h>
#include <imager.h>
#include <config.h>
#include <filesystem.h>
#include <quickdigest5.hpp>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/rotating_file_sink.h>

extern "C" {
    #include <mongoose.h>
}

enum ChunkType{
	MSGPACK,
	CACHED_JPEG,
	NULL_CHUNK,
	CACHED_BINARY
};

class HTTPServer {

	private:
		
		struct thread_data {
  			struct mg_mgr *mgr;
  			unsigned long conn_id;     // Parent connection ID
  			std::string json_str;      // Original HTTP request
  			std::string processid_str;
  			std::string jobid_str;
  			std::string thumbnail_uid;
  			std::string thumbnail_path;
  			std::string volume_path;
  			std::string comm_addr_str;
  			bool local;
		};

		struct user_data {
  			std::string username;     
  			std::string firstname;
  			std::string lastname;
  			std::string password;
  			std::string token;
  			bool admin;
		};

		struct chunk_data {
  			bool start;
  			bool end;
  			const char* ptr;
  			int  length;
  			enum ChunkType type;
		};

		std::thread workerthread;
		std::string ip = "0.0.0.0"; //localhost
		std::string logpath;
		std::string publicdir;
		std::string http_addr_str;
		std::string comm_addr_str;
		bool local;
		std::atomic<bool> healthy;
		std::atomic<bool> terminate;
		std::mutex cache_lock;
		std::map<std::string, struct user_data> user_cache;
		std::map<std::string, struct user_data> token_cache;
		void Listener();
		void LoadUsers();
		void RefreshTokens();
		bool ValidUser(void* ev_data, struct user_data* userdata);
		static void  RequestThread (void *(*f)(void *), void *p);
		static void  RequestHandler(struct mg_connection *c, int ev, void *ev_data);
		static void* RequestProcessJSON(void* p);
		static void* RequestProcessThumbnail(void* p);
		static void* RequestProcessVolume(void* p);
		static void SendMsgpackChunk(void* p, nlohmann::ordered_json chunkjson, bool start = true, bool end = true);
		static void SendJpegChunk(void* p, char* datastart, int datalength, bool start = true, bool end = true);
		static void SendNullChunk(void* p, bool start = true, bool end = true);
		static void SendBinaryChunk(void* p, char* datastart, int datalength, bool start = true, bool end = true);

	public:
		HTTPServer(std::string comm_addr_str, bool local = false);
		bool Status(bool quiet = false);
		void Start();
		void Stop();
		int port = 8100;
		std::string localtoken;

};

#endif
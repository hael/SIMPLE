#ifndef SIMPLE_H
#define SIMPLE_H

#include <iostream>
#include <fstream>
#include <vector>
#include <json.hpp>
#include <json_helpers.h>
#include <config.h>
#include <filesystem.h>
#include <jobbuilder.h>
#include <db.h>
#include <sys.h>
#include <workspace.h>
#include <spdlog/spdlog.h>
#include <process.h>
#include <jobtemplate.h>

class Simple : public JobBuilder {

	private:
		nlohmann::ordered_json ui;
		std::string preprocess_dir = "preprocessing";
		std::string optics_dir     = "assign_optics";
		std::string inipick_dir    = "initial_picking";
		std::string refgen_dir     = "reference_generation";
		std::string refpick_dir    = "reference_picking";
		std::string stream2d_dir   = "stream_2D";
		std::string stream3d_dir   = "stream_3D";
		nlohmann::ordered_json executables;

	public:
		Simple();
		bool ReadJobJson();
		void Dispatch(int process_id, bool restart, bool local);
		void LinkStream(std::string job_folder);
		bool InitialiseWorkspace(std::string path);
		bool ProjectDataJson(nlohmann::ordered_json* returnjson, std::string jobfolder, nlohmann::ordered_json args, bool folder = true);
		std::vector<int> Queue(std::string type, std::string jobfolder, nlohmann::ordered_json args, int template_id = -1, int parent_jobid = -1, std::string parent_jobfolder = "", std::string comm_addr_str = "", bool local = false);
		nlohmann::ordered_json GetArguments(std::string type);
		nlohmann::ordered_json ProcessArguments(nlohmann::ordered_json args, std::string type);
		nlohmann::ordered_json ProjectHeaderJson(std::string path, bool folder = true);
		nlohmann::ordered_json StatProjectFile(nlohmann::ordered_json args);
		nlohmann::ordered_json StatProjectFileData(nlohmann::ordered_json args);
		nlohmann::ordered_json ProjfileSelection(nlohmann::ordered_json args);
		nlohmann::ordered_json ProjfileSelectionArray(nlohmann::ordered_json args);
		nlohmann::ordered_json streamarguments = {
			{"data_source", {
				/*{
   					{"key", "mcsync_source"},
        			{"keytype", "binary"},
        			{"descr_short", "data source"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},*/
      			{
   					{"key", "dir_movies"},
        			{"keytype", "dir"},
        			{"descr_short", "movies directory"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "dir_meta"},
        			{"keytype", "dir"},
        			{"descr_short", "metadata directory"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "gainref"},
        			{"keytype", "file"},
        			{"descr_short", "gain reference"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
			}},
			{"collection_parameters", {
				{
   					{"key", "kv"},
        			{"keytype", "num"},
        			{"descr_short", "microscope voltage(kv)"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "cs"},
        			{"keytype", "num"},
        			{"descr_short", "spherical aberration(mm)"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "smpd"},
        			{"keytype", "num"},
        			{"descr_short", "pixel size(Å)"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "total_dose"},
        			{"keytype", "num"},
        			{"descr_short", "total dose(é/Å²)"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "scale"},
        			{"keytype", "ternary"},
        			{"descr_short", "bin data"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"options", {
        					"1X",
        					"2X",
        					"4X"
        				}
        			},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "flipgainx"},
        			{"keytype", "binary"},
        			{"descr_short", "flip gain in x"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "flipgainy"},
        			{"keytype", "binary"},
        			{"descr_short", "flip gain in y"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
			}},
			{"optional_parameters", {
				{
   					{"key", "refs2d"},
        			{"keytype", "file"},
        			{"descr_short", "2D clusters to use as picking references"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", true},
        			{"advanced", false},
        			{"online", false}
      			},
      			{
   					{"key", "dynreslim"},
        			{"keytype", "binary"},
        			{"descr_short", "dynreslim"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "stream_mean_threshold"},
        			{"keytype", "num"},
        			{"descr_short", "stream_mean_threshold"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "stream_rel_var_threshold"},
        			{"keytype", "num"},
        			{"descr_short", "stream_rel_var_threshold"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "stream_abs_var_threshold"},
        			{"keytype", "num"},
        			{"descr_short", "stream_abs_var_threshold"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "stream_minmax_threshold"},
        			{"keytype", "num"},
        			{"descr_short", "stream_minmax_threshold"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "stream_tvd_theshold"},
        			{"keytype", "num"},
        			{"descr_short", "stream_tvd_threshold"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "pool_threshold_factor"},
        			{"keytype", "num"},
        			{"descr_short", "pool_threshold_factor"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      			{
   					{"key", "abinitalgorithm"},
        			{"keytype", "text"},
        			{"descr_short", "2D abinitio algorithm"},
        			{"descr_long", ""},
        			{"descr_placeholder", ""},
        			{"required", false},
        			{"advanced", true},
        			{"online", false}
      			},
      		}},
      		
		};

};

#endif
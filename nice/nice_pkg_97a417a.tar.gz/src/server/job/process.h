#ifndef PROCESS_H
#define PROCESS_H

#include <iostream>
#include <fstream>
#include <chrono>
#include <json.hpp>
#include <json_helpers.h>
#include <filesystem.h>
#include <db.h>
#include <box.h>
#include <imager.h>
#include <tsqueue.h>
#include <tsvector.h>
#include <spdlog/spdlog.h>

class Process {

	private:
		int snapshot_jobdisplayid = 0;
	
	public:
		int process_id;     // unique id
		int template_id;
		std::string process_folder;
		std::string executable;
		std::string pre_exec_command;
		std::string name;
		std::string status;
		nlohmann::ordered_json arguments;
		nlohmann::ordered_json updatearguments;
		nlohmann::ordered_json uservals;
		Process(int process_id);
		Process(nlohmann::ordered_json args, int i); // i needed to distinguish
		Process(std::string name);
		void MarkQueued(int dependent_id, bool start_when_running = false);
		void MarkQueuedJob(int dependent_jobid);
		void MarkFinished();
		void MarkFailed();
		void MarkStopped();
		void MarkSubmitted();
		void MarkSkipped();
		void UpdateHeartbeat();
		void SetSnapshot(nlohmann::ordered_json snapshot);
		//void SetSnapshot(int snapshot_id);
		void SetUserInput(bool user_input);
		nlohmann::ordered_json UpdateArguments(nlohmann::ordered_json process_json);
		nlohmann::ordered_json GetUpdates();
		void UpdateStats(nlohmann::ordered_json process_json, TSQueue<nlohmann::ordered_json>* q, TSVector<std::string>* uids);
		void SetThumbnail(nlohmann::ordered_json thumbnail_json, std::string boxfile = "");
		void AddPreExecCommand(std::string command);
		void AddExecArguments(std::string module, std::string executable, std::string execdir, nlohmann::ordered_json jobargs, std::string preexeccommand = "", int template_id = -1);
		
		//Process(int process_id);
};

#endif
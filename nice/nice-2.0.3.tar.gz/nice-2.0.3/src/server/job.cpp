#include "handler.hpp"

nlohmann::ordered_json Handler::ListJobs(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("ListJobs : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ListJobs : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("ListJobs : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("ListJobs : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobhash")){
		this->core->logError("ListJobs : server failed to reply: jobhash missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobhash missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ListJobs : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ListJobs : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobhash").is_string()){
		this->core->logError("ListJobs : server failed to reply: jobhash is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobhash is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("ListJobs : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("ListJobs : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	std::string jobhash  (requestjson->at("jobhash").get<std::string>());

	int workspaceid = requestjson->at("workspaceid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();

	if(!this->SelectWorkspace(projectid, workspaceid, user)){
		this->core->logError("ListJobs : server failed to reply: failed to activate workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to find activate workspace";
		return returnjson;
	}

	std::map<std::string, std::string> workspace;

	if(!this->core->getWorkspace(workspaceid, "", "admin", &workspace)){
		this->core->logError("ListJobs : server failed to reply: failed to retreive workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retreive workspace";
		return returnjson;
	}

	if(workspace.find("subfolder") == workspace.end()){
		this->core->logError("ListJobs : server failed to reply: subfolder missing from workspace array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: subfolder missing from workspace array";
		return returnjson;	
	}

	std::map<std::string, std::string> project;

	if(!this->core->getProject(projectid, "", "admin", &project)){
		this->core->logError("ListJobs : server failed to reply: failed to retreive project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retreive project";
		return returnjson;
	}

	if(project.find("folder") == project.end()){
		this->core->logError("ListJobs : server failed to reply: folder missing from project array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing from project array";
		return returnjson;	
	}

	std::string projectfolder 	   = project["folder"];
	std::string workspacesubfolder = workspace["subfolder"];

	std::string sql = "SELECT * FROM jobs WHERE workspaceid=" + std::to_string(workspaceid) + ";";

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ListJobs : server failed to reply: failed to modify workspace in database");
		returnjson["success"] = false;
		returnjson["error"] = "ListJobs : failed to modify workspace in database";
		return returnjson;
	}

	nlohmann::ordered_json jobs = {};

	for (auto & job : returnvals){
		nlohmann::ordered_json jobjson = {};
		jobjson["id"]    	 = job["id"];
		jobjson["jobid"]     = job["jobid"];
		jobjson["jobtype"]   = job["jobtype"];
		jobjson["parentid"]  = job["parentid"];
		jobjson["deleted"]   = job["deleted"];
		jobjson["module"]    = job["module"];
		jobjson["version"]   = job["version"];
		jobjson["status"]    = job["status"];
		jobjson["jobname"]   = job["jobname"];
		jobjson["minimised"] = job["minimised"];
		jobjson["suggested"] = job["suggested"];
		jobjson["suggestedname"] = job["suggestedname"];
		jobjson["statuspercent"] = job["statuspercent"];
		jobjson["children"]  = {};

		if(job.contains("jobstats") && job["jobstats"].length() > 1){
			jobjson["jobstats"] = nlohmann::ordered_json::parse(job["jobstats"]);
		}

		if(job.contains("interactive")){
			jobjson["interactive"] = job["interactive"];
		}

		jobjson["jobfolder"] = projectfolder + "/" + workspacesubfolder + "/" + job["subfolder"];

		jobs.push_back(jobjson);
	}
	
	returnjson["jobhash"] = std::to_string(std::hash<std::string>{}(jobs.dump()));

	if(jobhash != returnjson["jobhash"].get<std::string>()){
		returnjson["jobs"] = jobs;
 	}

	returnjson["success"] = true;
	returnjson["info"] = "workspace loaded";
	
	return returnjson;

}

nlohmann::ordered_json Handler::RenameJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("RenameJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("RenameJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobname")){
		this->core->logError("RenameJob : server failed to reply: jobname missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("RenameJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("RenameJob : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("RenameJob : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("RenameJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("RenameJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobname").is_string()){
		this->core->logError("RenameJob : server failed to reply: jobname is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("RenameJob : server failed to reply: jobid is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("RenameJob : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("RenameJob : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	std::string jobname  (requestjson->at("jobname").get<std::string>());

	int jobid  	    = requestjson->at("jobid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();

	std::string sql = "UPDATE jobs SET jobname='" + jobname + "' WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("RenameJob : server failed to reply: failed to modify jobname in database");
		returnjson["success"] = false;
		returnjson["error"] = "RenameJob : failed to modify jobname in database";
		return returnjson;
	}

	this->updateModified(workspaceid, projectid);
	
	returnjson["success"] = true;
	returnjson["info"] = "job name updated";

	return returnjson;

}

nlohmann::ordered_json Handler::CleanupJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("CleanupJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("CleanupJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("CleanupJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("CleanupJob : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("CleanupJob : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("CleanupJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("CleanupJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("CleanupJob : server failed to reply: jobid is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("CleanupJob : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("CleanupJob : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int jobid  	    = requestjson->at("jobid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();

	std::string sql = "UPDATE jobs SET statusbackup = status WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("CleanupJob : server failed to reply: failed to copy status to statusbackup");
		returnjson["success"] = false;
		returnjson["error"] = "CleanupJob : failed to copy status to statusbackup";
		return returnjson;
	}

	sql = "UPDATE jobs SET status='cleanup' WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("CleanupJob : server failed to reply: failed to set status in database");
		returnjson["success"] = false;
		returnjson["error"] = "CleanupJob : failed to set status in database";
		return returnjson;
	}

	this->updateModified(workspaceid, projectid);
	
	returnjson["success"] = true;
	returnjson["info"] = "job queued for cleanup";

	return returnjson;

}

nlohmann::ordered_json Handler::DeleteJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("DeleteJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("DeleteJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("DeleteJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("DeleteJob : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("DeleteJob : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("DeleteJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("DeleteJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("DeleteJob : server failed to reply: jobid is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("DeleteJob : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("DeleteJob : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int jobid  	    = requestjson->at("jobid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();

	std::string sql = "UPDATE jobs SET status='deleted' WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("DeleteJob : server failed to reply: failed to modify jobname in database");
		returnjson["success"] = false;
		returnjson["error"] = "DeleteJob : failed to modify jobname in database";
		return returnjson;
	}

	this->updateModified(workspaceid, projectid);
	
	returnjson["success"] = true;
	returnjson["info"] = "job queued for deletion";

	return returnjson;

}

nlohmann::ordered_json Handler::MinimiseJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("MinimiseJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("MinimiseJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("MinimiseJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("MinimiseJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("MinimiseJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("MinimiseJob : server failed to reply: jobid is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not a string";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int jobid  = requestjson->at("jobid").get<int>();

	std::string sql = "UPDATE jobs SET minimised=TRUE WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("MinimiseJob : server failed to reply: failed to modify minimised in database");
		returnjson["success"] = false;
		returnjson["error"] = "MinimiseJob : failed to modify minimised in database";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"] = "job tree branch minimised";

	return returnjson;

}

nlohmann::ordered_json Handler::MaximiseJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("MaximiseJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("MaximiseJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("MaximiseJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("MaximiseJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("MaximiseJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("MaximiseJob : server failed to reply: jobid is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not a string";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int jobid  = requestjson->at("jobid").get<int>();

	std::string sql = "UPDATE jobs SET minimised=FALSE WHERE id=" + std::to_string(jobid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("MaximiseJob : server failed to reply: failed to modify minimised in database");
		returnjson["success"] = false;
		returnjson["error"] = "MaximiseJob : failed to modify minimised in database";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"] = "job tree branch minimised";

	return returnjson;

}

nlohmann::ordered_json Handler::GetJobs(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;

	returnjson["modules"] = {};
	returnjson["jobs"]    = {};

	if(this->core->SIMPLE_enabled){
		nlohmann::ordered_json simplejson;
		if(this->core->SIMPLE_getJobs(&simplejson)){
			returnjson["modules"] += "SIMPLE";
			for(auto job :simplejson["jobs"]){
				returnjson["jobs"] += job;
			} 
		}else{
			this->core->logError("GetJobs : failed to retreive SIMPLE Jobs");
		}
	}

	if(this->core->RELION_enabled){
		nlohmann::ordered_json relionjson;
		if(this->core->RELION_getJobs(&relionjson)){
			returnjson["modules"] += "RELION";
			for(auto job : relionjson["jobs"]){
				returnjson["jobs"] += job;
			} 
		}else{
			this->core->logError("GetJobs : failed to retreive RELION Jobs");
		}
	}

	returnjson["modules"] += "nice";
	
	// manual picker
	nlohmann::ordered_json manualpickjson;

	manualpickjson["name"] = "manual_pick";
    manualpickjson["descr_long"] = "is an interface for manual particle picking";
    manualpickjson["descr_short"] = "is an interface for manual particle picking";
    manualpickjson["advanced"] = false;
    manualpickjson["module"] = "nice";
    manualpickjson["interactive"] = "picker";

    returnjson["jobs"] += manualpickjson;

    // cryosparc link
    if(this->core->CRYOSPARC_enabled){

		nlohmann::ordered_json cslinkjson;

		cslinkjson["name"] = "link_cryosparc";
	    cslinkjson["descr_long"] = "link to Cryosparc instance. Will create a project and workspace matching the curren Nice worspace, and import data automatically";
	    cslinkjson["descr_short"] = "link to Cryosparc instance";
	    cslinkjson["advanced"] = false;
	    cslinkjson["module"] = "nice";
		cslinkjson["interactive"] = "link_cryosparc";
	    returnjson["jobs"] += cslinkjson;
	}

    // simple stream
    if(this->core->SIMPLE_enabled){

		nlohmann::ordered_json simplestreamjson;

		simplestreamjson["name"] = "stream";
	    simplestreamjson["descr_long"] = "";
	    simplestreamjson["descr_short"] = "";
	    simplestreamjson["advanced"] = false;
	    simplestreamjson["module"] = "SIMPLE";
		simplestreamjson["interactive"] = "simple_stream";
	    returnjson["jobs"] += simplestreamjson;
	}


	returnjson["success"] = true;
	returnjson["info"] = "jobs list retrieved";

	return returnjson;

}

nlohmann::ordered_json Handler::GetJobOptions(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetJobOptions : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetJobOptions : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("module")){
		this->core->logError("GetJobOptions : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		return returnjson;
	}

	if(!requestjson->contains("type")){
		this->core->logError("GetJobOptions : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		return returnjson;
	}

	bool rerun = false;

	if(requestjson->contains("rerunid") && !requestjson->at("rerunid").is_null()){
		rerun = true;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetJobOptions : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetJobOptions : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("GetJobOptions : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("GetJobOptions : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		return returnjson;
	}

	if(rerun && !requestjson->at("rerunid").is_number_integer()){
		this->core->logError("GetJobOptions : server failed to reply: rerunid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: rerunid is not an integer";
		return returnjson;
	}

	std::string user     (requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	std::string module   (requestjson->at("module").get<std::string>());
	std::string type     (requestjson->at("type").get<std::string>());

	returnjson["options"] = {};
	returnjson["executable"] = "";

	if(module == "SIMPLE" && this->core->SIMPLE_enabled){
		nlohmann::ordered_json simplejson;
		if(this->core->SIMPLE_getJobOptions(type, &simplejson)){
			returnjson["options"] = simplejson["options"];
			returnjson["executable"] = simplejson["executable"];
		}else{
			this->core->logError("GetJobOptions : server failed to reply: failed to retrieve SIMPLE job options");
			returnjson["success"] = false;
			returnjson["error"] = "server failed to reply: failed to retrieve SIMPLE job options";
			return returnjson;
		}
	}else if(module == "RELION" && this->core->RELION_enabled){
		nlohmann::ordered_json relionjson;
		if(this->core->RELION_getJobOptions(type, &relionjson)){
			returnjson["options"] = relionjson["options"];
			returnjson["executable"] = relionjson["executable"];
			if(relionjson.contains("programid")){
				returnjson["programid"] = relionjson["programid"];
			}
		}else{
			this->core->logError("GetJobOptions : server failed to reply: failed to retrieve RELION job options");
			returnjson["success"] = false;
			returnjson["error"] = "server failed to reply: failed to retrieve RELION job options";
			return returnjson;
		}
	}else{
		this->core->logError("GetJobOptions : server failed to reply: module is not enabled");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not enabled";
		return returnjson;
	}

	if(rerun){

		int rerunid = requestjson->at("rerunid").get<int>();
		std::string sql = "SELECT * FROM jobs WHERE id=" + std::to_string(rerunid) + ";"; 
	
		std::vector<std::map<std::string, std::string>> rerunvals;

		if(!this->core->queryDB(sql, &rerunvals)){
			this->core->logError("GetJobOptions : server failed to reply: failed to retrieve rerun job from database");
			returnjson["success"] = false;
			returnjson["error"] = "GetJobOptions : failed to retrieve rerun job from database";
			return returnjson;
		}

		if(rerunvals.size() == 1 && rerunvals[0].find("arguments") != rerunvals[0].end()){
			std::string argstring = rerunvals[0]["arguments"];
			nlohmann::ordered_json args = nlohmann::ordered_json::parse(argstring);
			returnjson["rerunargs"] = args;
		}

	}

	returnjson["success"] = true;
	returnjson["info"] = "job options retrieved";

	return returnjson;

}

nlohmann::ordered_json Handler::CreateJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("CreateJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("CreateJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("module")){
		this->core->logError("CreateJob : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		return returnjson;
	}

	if(!requestjson->contains("version")){
		this->core->logError("CreateJob : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		return returnjson;
	}

	if(!requestjson->contains("type")){
		this->core->logError("CreateJob : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		return returnjson;
	}

	if(!requestjson->contains("typeid")){
		this->core->logError("CreateJob : server failed to reply: typeid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: typeid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("CreateJob : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("CreateJob : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("executable")){
		this->core->logError("CreateJob : server failed to reply: executable missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: executable missing from request";
		return returnjson;
	}

	if(!requestjson->contains("arguments")){
		this->core->logError("CreateJob : server failed to reply: arguments missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: arguments missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobname")){
		this->core->logError("CreateJob : server failed to reply: jobname missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname missing from request";
		return returnjson;
	}

	if(!requestjson->contains("parentid")){
		this->core->logError("CreateJob : server failed to reply: parentid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("CreateJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("CreateJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("CreateJob : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("CreateJob : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		return returnjson;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("CreateJob : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobname").is_string()){
		this->core->logError("CreateJob : server failed to reply: jobname is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname is not a string";
		return returnjson;
	}

	if(!requestjson->at("executable").is_string()){
		this->core->logError("CreateJob : server failed to reply: executable is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: executable is not a string";
		return returnjson;
	}

	if(!requestjson->at("arguments").is_object()){
		this->core->logError("CreateJob : server failed to reply: arguments is not an object");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: arguments is not an object";
		return returnjson;
	}

	if(!requestjson->at("typeid").is_number_integer()){
		this->core->logError("CreateJob : server failed to reply: typeid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: typeid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("CreateJob : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("CreateJob : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("parentid").is_number_integer()){
		this->core->logError("CreateJob : server failed to reply: parentid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid is not an integer";
		return returnjson;
	}

	std::string user       (requestjson->at("user").get<std::string>());
	std::string userlevel  (requestjson->at("userlevel").get<std::string>());
	std::string module     (requestjson->at("module").get<std::string>());
	std::string version    (requestjson->at("version").get<std::string>());
	std::string type       (requestjson->at("type").get<std::string>());
	std::string jobname    (requestjson->at("jobname").get<std::string>());
	std::string executable (requestjson->at("executable").get<std::string>());

	int jobtypeid   = requestjson->at("typeid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int parentid    = requestjson->at("parentid").get<int>();

	nlohmann::ordered_json arguments = requestjson->at("arguments");
	arguments["niceexec"] = executable;

	std::string sql = "SELECT COUNT(*) FROM jobs WHERE workspaceid=" + std::to_string(workspaceid) + ";"; 
	
	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("CreateJob : server failed to reply: failed to retrieve job count from database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to retrieve job count from database";
		return returnjson;
	}

	int jobid = std::stoi(returnvals[0]["COUNT(*)"]) + 1;

	std::string subfolder = std::to_string(jobid) + "_" + type;

	std::string suggested = "NULL";
	std::string suggestedname = "NULL";

	if(module == "SIMPLE"){
		sql = "SELECT * FROM jobs WHERE id=" + std::to_string(parentid) + ";";
		std::vector<std::map<std::string, std::string>> parentargs;
		if(this->core->queryDB(sql, &parentargs)){
			if(!this->core->SIMPLE_suggestChild(version, type, parentargs, &suggested, &suggestedname)){
				suggested = "NULL";
				suggestedname = "NULL";
			}
		}
		
	}else if(module == "RELION"){
		sql = "SELECT * FROM jobs WHERE id=" + std::to_string(parentid) + ";";
		std::vector<std::map<std::string, std::string>> parentargs;
		if(this->core->queryDB(sql, &parentargs)){
			if(!this->core->RELION_suggestChild(version, type, parentargs, &suggested, &suggestedname)){
				suggested = "NULL";
				suggestedname = "NULL";
			}
		}
	}
	
	sql = "INSERT INTO jobs (workspaceid,"
							"jobid,"
							"subfolder,"
							"module,"
							"version,"
							"jobtype,"
							"jobtypeid,"
							"arguments,"
							"updatearguments,"
							"parentid,"
							"jobname,"
							"status,"
							"suggested,"
							"suggestedname,"
							"owner"
							") VALUES ("
							"'" + std::to_string(workspaceid) + "',"
							"'" + std::to_string(jobid) + "',"
							"'" + subfolder + "',"
							"'" + module + "',"
							"'" + version + "',"
							"'" + type + "',"
							"'" + std::to_string(jobtypeid) + "',"
							"'" + arguments.dump() + "',"
							"'" + arguments.dump() + "',"
							"'" + std::to_string(parentid) + "',"
							"'" + jobname + "',"
							"'queued',"
							+ suggested + ","
							+ suggestedname + ","
							"'" + user + "'"
							");";

	if(!this->core->queryDB(sql)){
		this->core->logError("CreateJob : server failed to reply: failed to insert job into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to insert job into database";
		return returnjson;
	}

	if(!this->updateModified(projectid, workspaceid)){
		this->core->logError("CreateJob : server failed to reply: failed to update modified");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to update modified";
		return returnjson;
	}

	returnjson["success"] = true;
	returnjson["info"] = "job created";

	return returnjson;

}

nlohmann::ordered_json Handler::CreateInteractiveJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("CreateInteractiveJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("CreateInteractiveJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("module")){
		this->core->logError("CreateInteractiveJob : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		return returnjson;
	}

	if(!requestjson->contains("version")){
		this->core->logError("CreateInteractiveJob : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("CreateInteractiveJob : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("CreateInteractiveJob : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobname")){
		this->core->logError("CreateInteractiveJob : server failed to reply: jobname missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname missing from request";
		return returnjson;
	}

	if(!requestjson->contains("type")){
		this->core->logError("CreateInteractiveJob : server failed to reply: type missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type missing from request";
		return returnjson;
	}

	if(!requestjson->contains("interactive")){
		this->core->logError("CreateInteractiveJob : server failed to reply: interactive missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: interactive missing from request";
		return returnjson;
	}

	if(!requestjson->contains("parentid")){
		this->core->logError("CreateInteractiveJob : server failed to reply: parentid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		return returnjson;
	}

	if(!requestjson->at("type").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: type is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: type is not a string";
		return returnjson;
	}

	if(!requestjson->at("interactive").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: interactive is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: interactive is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobname").is_string()){
		this->core->logError("CreateInteractiveJob : server failed to reply: jobname is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobname is not a string";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("CreateInteractiveJob : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("CreateInteractiveJob : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("parentid").is_number_integer()){
		this->core->logError("CreateInteractiveJob : server failed to reply: parentid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid is not an integer";
		return returnjson;
	}

	std::string user        (requestjson->at("user").get<std::string>());
	std::string userlevel   (requestjson->at("userlevel").get<std::string>());
	std::string module      (requestjson->at("module").get<std::string>());
	std::string version     (requestjson->at("version").get<std::string>());
	std::string type        (requestjson->at("type").get<std::string>());
	std::string jobname     (requestjson->at("jobname").get<std::string>());
	std::string interactive (requestjson->at("interactive").get<std::string>());

	int projectid   = requestjson->at("projectid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int parentid    = requestjson->at("parentid").get<int>();

	std::map<std::string, std::string> workspace;

	if(!this->core->getWorkspace(workspaceid, "", "admin", &workspace)){
		this->core->logError("CreateInteractiveJob : failed to retrieve workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retrieve workspace";
		return returnjson;
	}

	std::map<std::string, std::string> project;

	if(!this->core->getProject(projectid, "", "admin", &project)){
		this->core->logError("CreateInteractiveJob : failed to retrieve project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retrieve project";
		return returnjson;
	}

	if(workspace.find("subfolder") == workspace.end()){
		this->core->logError("CreateInteractiveJob : subfolder missing for workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: subfolder missing for workspace";
		return returnjson;
	}

	if(workspace.find("name") == workspace.end()){
		this->core->logError("CreateInteractiveJob : name missing for workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: name missing for workspace";
		return returnjson;
	}
	
	if(project.find("folder") == project.end()){
		this->core->logError("CreateInteractiveJob : folder missing for project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing for project";
		return returnjson;
	}

	if(project.find("name") == project.end()){
		this->core->logError("CreateInteractiveJob : name missing for project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: name missing for project";
		return returnjson;
	}

	nlohmann::ordered_json arguments = {};

	std::string sql = "SELECT COUNT(*) FROM jobs WHERE workspaceid=" + std::to_string(workspaceid) + ";"; 
	
	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("CreateJob : server failed to reply: failed to retrieve job count from database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to retrieve job count from database";
		return returnjson;
	}

	int jobid = std::stoi(returnvals[0]["COUNT(*)"]) + 1;

	std::string subfolder = std::to_string(jobid) + "_" + type;

	std::string jobfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + subfolder;

	if(!ensureFolder(jobfolder)){
		this->core->logError("CreateInteractiveJob : failed to create job folder");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to create job folder";
		return returnjson;
	}

	returnjson["jobfolder"] = jobfolder;

	std::string suggested = "NULL";
	std::string suggestedname = "NULL";

	if(parentid >= 0){
		sql = "SELECT * FROM jobs WHERE id=" + std::to_string(parentid) + ";";
		std::vector<std::map<std::string, std::string>> parentargs;

		if(this->core->queryDB(sql, &parentargs)){
			if(module == "SIMPLE"){
				if(!this->core->SIMPLE_suggestChild(version, type, parentargs, &suggested, &suggestedname)){
					suggested = "NULL";
					suggestedname = "NULL";
				}
			}	
		}else if(module == "RELION"){
			if(this->core->queryDB(sql, &parentargs)){
				if(!this->core->RELION_suggestChild(version, type, parentargs, &suggested, &suggestedname)){
					suggested = "NULL";
					suggestedname = "NULL";
				}
			}
		}
		std::string parentfolder = project["folder"] + "/" + workspace["subfolder"] + "/" + parentargs[0]["subfolder"];
		returnjson["parentfolder"] = parentfolder;
	}

	returnjson["jobid"] = jobid;
	returnjson["username"] = user; // can be removed?
	returnjson["workspacename"] = workspace["name"]; // can be removed?
	returnjson["projectname"]   = project["name"]; // can be removed?

	sql = "INSERT INTO jobs (workspaceid,"
							"jobid,"
							"subfolder,"
							"module,"
							"version,"
							"jobtype,"
							"jobtypeid,"
							"arguments,"
							"updatearguments,"
							"parentid,"
							"jobname,"
							"status,"
							"suggested,"
							"suggestedname,"
							"interactive,"
							"owner"
							") VALUES ("
							"'" + std::to_string(workspaceid) + "',"
							"'" + std::to_string(jobid) + "',"
							"'" + subfolder + "',"
							"'" + module + "',"
							"'" + version + "',"
							"'" + type + "',"
							"-1,"
							"'" + arguments.dump() + "',"
							"'" + arguments.dump() + "',"
							"'" + std::to_string(parentid) + "',"
							"'" + jobname + "',"
							"'interactive',"
							+ suggested + ","
							+ suggestedname + ","
							"'" + interactive + "',"
							"'" + user + "'"
							");";

	int id = -1;

	if(!this->core->queryDB(sql, &id)){
		this->core->logError("CreateJob : server failed to reply: failed to insert job into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to insert job into database";
		return returnjson;
	}

	returnjson["id"] = id;

	if(!this->updateModified(projectid, workspaceid)){
		this->core->logError("CreateJob : server failed to reply: failed to update modified");
		returnjson["success"] = false;
		returnjson["error"] = "CreateJob : failed to update modified";
		return returnjson;
	}


	returnjson["success"] = true;
	returnjson["info"] = "job created";

	return returnjson;

}

nlohmann::ordered_json Handler::StopJob(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("StopJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("StopJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("StopJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("StopJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("StopJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("StopJob : server failed to reply: jobid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not an integer";
		return returnjson;
	}

	std::string user       (requestjson->at("user").get<std::string>());
	std::string userlevel  (requestjson->at("userlevel").get<std::string>());

	int jobid = requestjson->at("jobid").get<int>();

	std::string sql = "UPDATE jobs SET status='stopping' WHERE id=" + std::to_string(jobid) + ";"; 

	if(!this->core->queryDB(sql)){
		this->core->logError("StopJob : server failed to reply: failed to update database");
		returnjson["success"] = false;
		returnjson["error"] = "StopJob : failed to update database";
		return returnjson;
	}

	returnjson["success"] = true;
	returnjson["info"] = "job queued for termination";

	return returnjson;

}

nlohmann::ordered_json Handler::ViewJob(nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson;

	if(!requestjson->contains("user")){
		this->core->logError("ViewJob : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ViewJob : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("jobid")){
		this->core->logError("ViewJob : server failed to reply: jobid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ViewJob : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ViewJob : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("jobid").is_number_integer()){
		this->core->logError("ViewJob : server failed to reply: jobid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobid is not an integer";
		return returnjson;
	}

	std::string user       (requestjson->at("user").get<std::string>());
	std::string userlevel  (requestjson->at("userlevel").get<std::string>());

	int jobid   = requestjson->at("jobid").get<int>();

	std::string sql = "SELECT * FROM jobs WHERE id=" + std::to_string(jobid) + ";";
	
	std::vector<std::map<std::string, std::string>> jobarr;

	if(!this->core->queryDB(sql, &jobarr)){
		this->core->logError("ViewJob : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	if(jobarr.size() != 1){
		this->core->logError("ViewJob : server failed to reply: job array length incorrect");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: job array length incorrect";
		return returnjson;
	}

	std::map<std::string, std::string> job = jobarr[0];

	if(job.find("workspaceid") == job.end()){
		this->core->logError("ViewJob : server failed to reply: workspaceid missing from array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from array";
		return returnjson;	
	}

	int workspaceid = std::stoi(job["workspaceid"]);

	std::map<std::string, std::string> workspace;

	if(!this->core->getWorkspace(workspaceid, "", "admin", &workspace)){
		this->core->logError("ViewJob : server failed to reply: failed to retreive workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retreive workspace";
		return returnjson;
	}

	if(workspace.find("project") == workspace.end()){
		this->core->logError("ViewJob : server failed to reply: project missing from workspace array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: project missing from workspace array";
		return returnjson;	
	}

	int projectid = std::stoi(workspace["project"]);

	std::map<std::string, std::string> project;

	if(!this->core->getProject(projectid, "", "admin", &project)){
		this->core->logError("ViewJob : server failed to reply: failed to retreive project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to retreive project";
		return returnjson;
	}

	if(job.find("module") == job.end()){
		this->core->logError("ViewJob : server failed to reply: module missing from job array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from job array";
		return returnjson;	
	}

	if(job.find("version") == job.end()){
		this->core->logError("ViewJob : server failed to reply: version missing from job array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from job array";
		return returnjson;	
	}

	if(job.find("jobtype") == job.end()){
		this->core->logError("ViewJob : server failed to reply: jobtype missing from job array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype missing from job array";
		return returnjson;	
	}

	if(job.find("subfolder") == job.end()){
		this->core->logError("ViewJob : server failed to reply: subfolder missing from job array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: subfolder missing from job array";
		return returnjson;	
	}

	if(job.find("status") == job.end()){
		this->core->logError("ViewJob : server failed to reply: status missing from job array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: status missing from job array";
		return returnjson;	
	}
	
	if(workspace.find("subfolder") == workspace.end()){
		this->core->logError("ViewJob : server failed to reply: subfolder missing from workspace array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: subfolder missing from workspace array";
		return returnjson;	
	}

	if(project.find("folder") == project.end()){
		this->core->logError("ViewJob : server failed to reply: folder missing from project array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing from project array";
		return returnjson;	
	}

	std::string module  = job["module"];
	std::string version = job["version"];
	std::string jobtype = job["jobtype"];

	std::string projectfolder 	   = project["folder"];
	std::string workspacesubfolder = workspace["subfolder"];
	std::string jobsubfolder       = job["subfolder"];
	std::string jobstatus          = job["status"];

	std::string jobfolder = projectfolder + "/" + workspacesubfolder + "/" + jobsubfolder;

	if(!folderExists(jobfolder)){
		this->core->logError("ViewJob : server failed to reply: job folder does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: job folder does not exist";
		return returnjson;	
	}

	if(fileExists(jobfolder + "/nice.log")){
		if(!returnjson.contains("logtab")) returnjson["logtab"] = {};
		returnjson["logtab"]["log"] = jobfolder + "/nice.log";
	}

	if(fileExists(jobfolder + "/nice.error")){
		if(!returnjson.contains("logtab")) returnjson["logtab"] = {};
		returnjson["logtab"]["error"] = jobfolder + "/nice.error";
	}

	if(fileExists(jobfolder + "/micrographs.star")){
		if(!returnjson.contains("micstab")) returnjson["micstab"] = {};
		returnjson["micstab"]["starfile"] = jobfolder + "/micrographs.star";
	}

	if(jobstatus == "finished" && fileExists(jobfolder + "/clusters2D.star")){
		if(!returnjson.contains("cls2Dtab")) returnjson["cls2Dtab"] = {};
		returnjson["cls2Dtab"]["finalstar"] = jobfolder + "/clusters2D.star";
	}

	if(fileExists(jobfolder + "/optics_groups.star")){
		if(!returnjson.contains("opticstab")) returnjson["opticstab"] = {};
		returnjson["opticstab"]["starfile"] = jobfolder + "/optics_groups.star";
	}

	int lastfound = 0;
	for(int i = 0; i < 1000; i++){

		std::ostringstream itstr;
    	itstr << std::setw(3) << std::setfill('0') << i;
    	// SIMPLE
		if(fileExists(jobfolder + "/clusters2D_iter" + itstr.str() + ".star")){ 
			if(!returnjson.contains("cls2Dtab")){
				returnjson["cls2Dtab"] = {};
			}
			if(!returnjson["cls2Dtab"].contains("iterations")){
				returnjson["cls2Dtab"]["iterations"] = {};
			}
			returnjson["cls2Dtab"]["iterations"] += jobfolder + "/clusters2D_iter" + itstr.str() + ".star";
			lastfound = i;
		// RELION
		}else if(fileExists(jobfolder + "/run_it" + itstr.str() + "_model.star")){
			if(!returnjson.contains("cls2Dtab")){
				returnjson["cls2Dtab"] = {};
			}
			if(!returnjson["cls2Dtab"].contains("iterations")){
				returnjson["cls2Dtab"]["iterations"] = {};
			}
			returnjson["cls2Dtab"]["iterations"] += jobfolder + "/run_it" + itstr.str() + "_model.star";
			lastfound = i;
		}else{
			if(i > lastfound + 10){
				break;
			}
		}
	}

	if(returnjson.contains("cls2Dtab") && returnjson["cls2Dtab"].contains("iterations") && returnjson["cls2Dtab"]["iterations"].size() > 0){
		returnjson["cls2Dtab"]["lateststar"] = returnjson["cls2Dtab"]["iterations"][returnjson["cls2Dtab"]["iterations"].size() - 1];
	}

	if(fileExists(jobfolder + "/.parameters")){
		if(!returnjson.contains("parameterstab")) returnjson["parameterstab"] = {};
		returnjson["parameterstab"]["paramsfile"] = jobfolder + "/.parameters";
	}else if(fileExists(jobfolder + "/.cline")){
		if(!returnjson.contains("parameterstab")) returnjson["parameterstab"] = {};
		returnjson["parameterstab"]["paramsfile"] = jobfolder + "/.cline";
	}

	returnjson["module"]    = module;
	returnjson["version"]   = version;
	returnjson["jobtype"]   = jobtype;
	returnjson["jobstatus"] = jobstatus;

	returnjson["success"] = true;
	returnjson["info"] = "job output loaded";

	return returnjson;

}
#ifndef JOB_H
#define JOB_H

#include <iostream>
#include <fstream>
#include <json.hpp>
#include <json_helpers.h>
#include <filesystem.h>
#include <db.h>
#include <io.h>
#include <simple.h>
#include <single.h>
#include <workspace.h>
#include <process.h>
#include <nice_tools.h>
#include <spdlog/spdlog.h>

class Job : public Workspace {

	private:
		int parent_id;
		std::string job_name;   // job name
		std::string module;     // job module
		std::string type;       // job type
		std::string status;     // job status
		bool interactive;
		nlohmann::ordered_json job_arguments;   // all possible arguments
		nlohmann::ordered_json start_arguments; // arguments set for this job
		std::string UpdateStatus(int job_id);
	
	public:
		Job();
		Job(int workspace_id);
		Job(nlohmann::ordered_json args);
		int job_id;     // unique id
		int display_id; // id within workspace
		std::string job_folder; // full path to job folder
		std::string job_folder_base; // job folder name
		bool LoadJob(int job_id);
		int CreateJob();
		int Start(nlohmann::ordered_json args, std::string comm_addr_str, bool local);
		void SetFinished();
		void SetDeleted();
		void SetQueued();
		void SetRetrievable();
		void SetRetrieve();
		void SetRestart();
		void SetFailed();
		nlohmann::ordered_json NewJob();
		nlohmann::ordered_json StatJob();
		nlohmann::ordered_json StatJobData(nlohmann::ordered_json args);
		nlohmann::ordered_json ListJobs();
		nlohmann::ordered_json ListBuildableJobs();
		nlohmann::ordered_json BuildJob();
		nlohmann::ordered_json DeleteJob();
		nlohmann::ordered_json RetrieveJob();
		nlohmann::ordered_json RestartJob();
		nlohmann::ordered_json StartJob(nlohmann::ordered_json args, std::string comm_addr_str, bool local);
		nlohmann::ordered_json TreeJobs(nlohmann::ordered_json joblist);
		nlohmann::ordered_json StatHeadlinesJob();
		nlohmann::ordered_json RenameJob(nlohmann::ordered_json args);
		nlohmann::ordered_json CompleteProcesses();
		nlohmann::ordered_json Complete();
};

#endif
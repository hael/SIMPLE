#include "core.hpp"

bool Core::ApplySchema (){	

	std::vector<std::string> projectsql = {
  		"CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT);",
		"ALTER TABLE projects ADD COLUMN name string NULL;",
		"ALTER TABLE projects ADD COLUMN uid string NULL;",
		"ALTER TABLE projects ADD COLUMN gid string NULL;",
		"ALTER TABLE projects ADD COLUMN owner string NULL;",
		"ALTER TABLE projects ADD COLUMN folder string NULL;",
	 	"ALTER TABLE projects ADD COLUMN description string NULL;",
		"ALTER TABLE projects ADD COLUMN created DATETIME DEFAULT CURRENT_TIMESTAMP;",
	 	"ALTER TABLE projects ADD COLUMN gidaccess BOOLEAN DEFAULT TRUE;",
	  	"ALTER TABLE projects ADD COLUMN modified DATETIME DEFAULT CURRENT_TIMESTAMP;",
		"ALTER TABLE projects ADD COLUMN active BOOLEAN NULL;",
	 	"ALTER TABLE projects ADD COLUMN deleted BOOLEAN NULL;",
	};

	std::vector<std::string> workspacesql = {
		"CREATE TABLE IF NOT EXISTS workspaces(id INTEGER PRIMARY KEY AUTOINCREMENT);",
		"ALTER TABLE workspaces ADD COLUMN name string NULL;",
		"ALTER TABLE workspaces ADD COLUMN project INTEGER NULL;",
		"ALTER TABLE workspaces ADD COLUMN subfolder string NULL;",
		"ALTER TABLE workspaces ADD COLUMN modified DATETIME CURRENT_TIMESTAMP;",
		"ALTER TABLE workspaces ADD COLUMN active BOOLEAN NULL;",
		"ALTER TABLE workspaces ADD COLUMN deleted BOOLEAN NULL;",
		"ALTER TABLE workspaces ADD COLUMN trashusage INTEGER default 0;",
		"ALTER TABLE workspaces ADD COLUMN emptytrash BOOLEAN DEFAULT FALSE;",
	};

	std::vector<std::string> usersql = {
		"CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT);",
		"ALTER TABLE users ADD COLUMN name string NULL;",
		"ALTER TABLE users ADD COLUMN uid string NULL;",
		"ALTER TABLE users ADD COLUMN gid string NULL;",
		"ALTER TABLE users ADD COLUMN level string NULL;",
		"ALTER TABLE users ADD COLUMN colourscheme string NULL;",
		"ALTER TABLE users ADD COLUMN pass string NULL;",
		"ALTER TABLE users ADD COLUMN selectedworkspaceid INTEGER NULL;",
		"ALTER TABLE users ADD COLUMN selectedprojectid INTEGER NULL;",
	};

	std::vector<std::string> jobsql = {	
		"CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT);",
		"ALTER TABLE jobs ADD COLUMN jobid int NULL;",
		"ALTER TABLE jobs ADD COLUMN workspaceid int NULL;",
		"ALTER TABLE jobs ADD COLUMN subfolder string NULL;",
		"ALTER TABLE jobs ADD COLUMN executable string NULL;",
		"ALTER TABLE jobs ADD COLUMN arguments string NULL;",
		"ALTER TABLE jobs ADD COLUMN module string NULL;",
		"ALTER TABLE jobs ADD COLUMN version string NULL;",
		"ALTER TABLE jobs ADD COLUMN jobtype string NULL;",
		"ALTER TABLE jobs ADD COLUMN jobtypeid int DEFAULT -1;",
		"ALTER TABLE jobs ADD COLUMN parentid string DEFAULT 'none';",
		"ALTER TABLE jobs ADD COLUMN jobname string DEFAULT '';",
		"ALTER TABLE jobs ADD COLUMN status string DEFAULT 'queued';",
		"ALTER TABLE jobs ADD COLUMN statusbackup string NULL;",
		"ALTER TABLE jobs ADD COLUMN statuspercent int DEFAULT -1;",
		"ALTER TABLE jobs ADD COLUMN submitcommand string NULL;",
 		"ALTER TABLE jobs ADD COLUMN cancelcommand string NULL;",
		"ALTER TABLE jobs ADD COLUMN statuscommand string NULL;",
  		"ALTER TABLE jobs ADD COLUMN created DATETIME DEFAULT CURRENT_TIMESTAMP;",
  		"ALTER TABLE jobs ADD COLUMN starttime DATETIME DEFAULT NULL;",
  		"ALTER TABLE jobs ADD COLUMN endtime DATETIME DEFAULT NULL;",
		"ALTER TABLE jobs ADD COLUMN minimised BOOLEAN NULL;",
 		"ALTER TABLE jobs ADD COLUMN updatearguments string NULL;",
 		"ALTER TABLE jobs ADD COLUMN diskusage int DEFAULT 0;",
 		"ALTER TABLE jobs ADD COLUMN cleanup BOOLEAN DEFAULT FALSE;",
		"ALTER TABLE jobs ADD COLUMN deleted BOOLEAN DEFAULT FALSE;",
  		"ALTER TABLE jobs ADD COLUMN jobstats string NULL;",
  		"ALTER TABLE jobs ADD COLUMN suggested string NULL;",
  		"ALTER TABLE jobs ADD COLUMN suggestedname string NULL;",
  		"ALTER TABLE jobs ADD COLUMN interactive string NULL;",
  		"ALTER TABLE jobs ADD COLUMN owner string NULL;",
	};


	for(auto &sql : projectsql){
		if(!this->queryDB(sql, true, false)){
			this->logFatal("ApplySchema : failed to apply project database sql : " + sql);
		}
	}

	for(auto &sql : workspacesql){
		if(!this->queryDB(sql, true, false)){
			this->logFatal("ApplySchema : failed to apply workspace database sql : " + sql);
		}
	}

	for(auto &sql : usersql){
		if(!this->queryDB(sql, true, false)){
			this->logFatal("ApplySchema : failed to apply user database sql : " + sql);
		}
	}

	for(auto &sql : jobsql){
		if(!this->queryDB(sql, true, false)){
			this->logFatal("ApplySchema : failed to apply job database sql : " + sql);
		}
	}

	this->logInfo("database schema applied");
	return true;
}
var searchData=
[
  ['get_20information_20out_20of_20xml',['Get information out of XML',['../_example_3.html',1,'']]]
];

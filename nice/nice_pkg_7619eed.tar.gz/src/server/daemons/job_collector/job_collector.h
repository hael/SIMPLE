#ifndef JOB_COLLECTOR_H
#define JOB_COLLECTOR_H

#include <iostream>
#include <thread>
#include <chrono>
#include <string>
#include <unistd.h>
#include <json.hpp>
#include <sys.h>
#include <db.h>
#include <job.h>
#include <process.h>
#include <config.h>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <tsqueue.h>
#include <tsvector.h>

extern "C" {
    #include <mongoose.h>
}

class JobCollector {

	private:
		std::thread workerthread;
		std::thread thumbnailthreads[8];
		std::string logpath;
		std::string ip = "0.0.0.0"; // localhost
		int port = 8099;
		int n_thumbnail_workers = 4;
		bool local;
		std::atomic<bool> healthy;
		std::atomic<bool> terminate;
		void Listener();
		void Thumbnailer();
		static void  RequestThread (void *(*f)(void *), void *p);
		static void  RequestHandler(struct mg_connection *c, int ev, void *ev_data);
		static void* RequestProcess(void* p);
		
		struct thread_data {
  			struct mg_mgr *mgr;
  			unsigned long conn_id;  // Parent connection ID
  			std::string json_str;  // Original HTTP request
  			std::string jobid_str;
  			std::string processid_str;
  			void* useful_pointer;
		};

	public:
		JobCollector(bool local = false);
		std::string comm_addr_str;
		int thread_id;
		TSQueue<nlohmann::ordered_json> q;
		TSVector<std::string> uids;
		bool Status(bool quiet = false);
		void Start();
		void Stop();

};



#endif
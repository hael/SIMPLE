#ifndef SIMPLE_STREAM
#define SIMPLE_STREAM

#include <vector>
#include <iostream>

#include "core.hpp"
#include "star.hpp"

class SIMPLE_Stream{
	
	private:
		Core* core;
		nlohmann::ordered_json DataTab();
		nlohmann::ordered_json PreprocTab();
		nlohmann::ordered_json OpticsTab();
		nlohmann::ordered_json PickTrainTab();
		nlohmann::ordered_json PickTab();
		nlohmann::ordered_json Stream2DTab();
		nlohmann::ordered_json Stream3DTab();

		bool StreamInit(nlohmann::ordered_json arguments);
		bool StreamInitPreproc(nlohmann::ordered_json arguments, bool restart = false);
		bool StreamInitRefPick(nlohmann::ordered_json arguments, bool restart = false);
		bool StreamInitAssignOptics(nlohmann::ordered_json arguments, bool restart = false);
		bool FillTemplate(std::string clustertemplate, std::string title, std::string prg, nlohmann::ordered_json jobargs);
		bool TestStatus(std::string prg);
		std::string rootfolder;
		nlohmann::ordered_json stats;
		nlohmann::ordered_json control;
		int id;

	public:
		SIMPLE_Stream(Core* core, std::string rootfolder, int jobid);
		void TabData(nlohmann::ordered_json* returnjson);
		void OpticsData(nlohmann::ordered_json* returnjson, std::string filename);
		void StreamControl(std::string func, nlohmann::ordered_json arguments, nlohmann::ordered_json* returnjson);
		bool GetStats(nlohmann::ordered_json* statsjson);
		bool Dispatch();
};




#endif

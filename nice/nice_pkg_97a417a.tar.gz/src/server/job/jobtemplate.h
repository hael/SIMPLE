#ifndef JOBTEMPLATE_H
#define JOBTEMPLATE_H

#include <iostream>
#include <fstream>
#include <db.h>
#include <spdlog/spdlog.h>

// temporarily here

class JobTemplate {
	private:
		std::string substituted_template;
		std::string script_dir;
		std::string script_path;
	public:
		int template_id;
		std::string template_string;
		std::string submission_command;
		JobTemplate();
		JobTemplate(int template_id);
		JobTemplate(bool local);
		void Substitute(std::string command_string, int nthr = 1);
		bool Write(std::string script_dir, std::string script_name);
		bool Submit();
};

#endif
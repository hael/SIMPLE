#ifndef CORE
#define CORE

#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <thread>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include <tuple>

#include "json.hpp"
#include "sqlite3.h"
#include "tinyxml2.h"
#include "spdlog/spdlog.h"
#include "spdlog/sinks/daily_file_sink.h"
#include "spdlog/sinks/stdout_color_sinks.h"

#include "filesystem.hpp"

class Core {
	friend class Handler;
	private:
		std::string bindir;
		std::string conffile;
		std::string logdir;
		std::string dbpath;
		std::string dbdir;
		std::string defaultpath;
		tinyxml2::XMLDocument xmldoc;
		sqlite3* db = NULL;
		nlohmann::ordered_json statusarr;
		std::mutex statuslock;

		void dataWorker();
		void dispatchWorker();
		void collectWorker();
		void statusWorker();
		void cleanupCycle();
		void deleteCycle();
		void trashCycle();
		void dispatchCycle();
		void dispatchFail(int jobid);
		void dispatchSubmitted(int jobid, std::string submitcommand, std::string cancelcommand, std::string statuscommand);
		void collectCycle();
		void collectFail(int jobid);
		void collectFinish(int jobid);
		void collectStopped(int jobid, std::string stopstatus = "stopped");
		void collectRunning(int jobid);
		void collectProgress(int jobid, int progress);
		void collectStats(int jobid, nlohmann::ordered_json stats);
		void statusCycle();
		void statusAddCommand(std::string statuscommand);
		bool openDB();
		bool openDB(bool* dbuserinit);
		bool queryDB(std::string sql, bool ignoreduplicate = false, bool verbose = true);
		bool queryDB(std::string sql, std::vector<std::map<std::string, std::string>>* returnvals);
		bool queryDB(std::string sql, int* rowid);
		bool ApplySchema();
		bool createLocalClusterDef(std::string module, std::string filename);
		std::string generateToken( size_t length );

		// CRYOSPARC //
		bool CRYOSPARC_enabled = NULL;
		bool CRYOSPARC_test();
		void CRYOSPARC_export2instance(std::string jobfolder, std::string projectname, std::string workspacename, std::string username, std::string micsstar, std::string ptclsstar);

		// RELION //
		bool RELION_enabled = NULL;
		bool RELION_test();
		bool RELION_getJobs(nlohmann::ordered_json* joblist);
		bool RELION_getJobOptions(std::string jobname, nlohmann::ordered_json* joboptions);
		bool RELION_workspaceInit(std::string path);
		bool RELION_jobInit(std::string version, std::string type, int jobtypeid, std::string jobfolder, std::string clustertemplate, nlohmann::ordered_json jobargs, std::string parentsubfolder);
		bool RELION_fillTemplate(std::string clustertemplate, std::string prg, int jobtypeid, nlohmann::ordered_json jobargs, std::string jobfolder, std::string parentsubfolder, std::string* returnstring);
		bool RELION_suggestChild(std::string version, std::string jobtype, std::vector<std::map<std::string, std::string>> parent, std::string* suggestedjobtype, std::string* suggestedjobname);
		bool RELION_selectionInit(nlohmann::json* requestjson);
		bool RELION_progress(std::string jobfolder, int* progress);
		bool RELION_stats(std::string jobfolder, nlohmann::ordered_json* stats);
		void RELION_cleanup(std::string version);
		void RELION_getClusters(nlohmann::ordered_json* clusterlist);
		void RELION_jobStop(std::string version, std::string type, std::string jobfolder, std::string cancelcommand, std::string statuscommand, std::time_t starttime);
		void RELION_finishJob(std::string jobfolder, std::string jobtype);
		void RELION_images(std::string version, std::string type, nlohmann::ordered_json* images);
		int  RELION_cls2Dptcls(std::string version, std::string filename, nlohmann::ordered_json* cls2Dstar);
		int  RELION_cls2Dclsall(std::string version, nlohmann::ordered_json* cls2Dstar);
		std::tuple<std::string, std::string> RELION_DataInOut(std::string jobtype);

		// SIMPLE //
		bool SIMPLE_enabled = NULL;
		bool SIMPLE_test();
		bool SIMPLE_getJobs(nlohmann::ordered_json* joblist);
		bool SIMPLE_getJobOptions(std::string jobname, nlohmann::ordered_json* joboptions);
		bool SIMPLE_workspaceInit(std::string path);
		bool SIMPLE_jobInit(std::string version, std::string type, std::string jobfolder, std::string clustertemplate, nlohmann::ordered_json jobargs, std::string parentsubfolder);
		bool SIMPLE_fillTemplate(std::string clustertemplate, std::string prg, nlohmann::ordered_json jobargs, std::string jobfolder, std::string parentsubfolder, std::string* returnstring);
		bool SIMPLE_suggestChild(std::string version, std::string jobtype, std::vector<std::map<std::string, std::string>> parent, std::string* suggestedjobtype, std::string* suggestedjobname);
		bool SIMPLE_stopStatus(std::string version, std::string type, std::string* stopstatus);
		bool SIMPLE_selectionInit(nlohmann::json* requestjson);
		bool SIMPLE_onlineSelection(nlohmann::json* requestjson);
		bool SIMPLE_progress(std::string jobfolder, int* progress);
		bool SIMPLE_stats(std::string jobfolder, nlohmann::ordered_json* stats);
		void SIMPLE_cleanup(std::string version);
		void SIMPLE_getClusters(nlohmann::ordered_json* clusterlist);
		void SIMPLE_jobStop(std::string version, std::string type, std::string jobfolder, std::string cancelcommand, std::string statuscommand, std::time_t starttime);
		void SIMPLE_images(std::string version, std::string type, nlohmann::ordered_json* images);
		void SIMPLE_paths(std::string version, std::string type, std::string key, nlohmann::ordered_json stringpath, nlohmann::ordered_json* images);
		int  SIMPLE_micsptcls(std::string version, nlohmann::ordered_json* micsstar);
		int  SIMPLE_cls2Dptcls(std::string version, nlohmann::ordered_json* cls2Dstar);
		int  SIMPLE_cls2Dclsall(std::string version, nlohmann::ordered_json* cls2Dstar);
		int  SIMPLE_micsall(std::string version, nlohmann::ordered_json* micsstar);
	
	public:
		Core(std::string bindir, bool local);
		std::string publicdir;
		void logInfo(std::string logtext,  bool external = true);
		void logError(std::string logtext, bool external = true);
		void logFatal(std::string logtext, bool external = true);
		void reloadConfig();

		bool getUserCreds(std::string username, nlohmann::ordered_json* user);
		bool getConfigValue (std::string key, std::string& value);
		bool getProject  (int projectid, std::string username, std::string userlevel, std::map<std::string, std::string>* returnvals);
		bool getWorkspace(int workspaceid, std::string username, std::string userlevel, std::map<std::string, std::string>* returnvals);

		std::vector<std::string> statusGetCommands();
		void statusSetOutput(std::string command, std::string output, int status);
		bool statusTest(std::string statuscommand, int pid, std::time_t starttime);
	//	bool getText (tinyxml2::XMLElement* elementin, std::string elementname, std::string& value);
	//	tinyxml2::XMLNode* getNode (std::string elementname);
	//	tinyxml2::XMLNode* getNode (tinyxml2::XMLNode* node, std::string elementname);
	//	bool iterateNode (tinyxml2::XMLNode* node, void (*cb)(tinyxml2::XMLNode*));
};

extern Core* core;

#endif

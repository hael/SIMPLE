#ifndef STAR
#define STAR

#include <vector>

#include <iostream>


static std::vector<std::string> lineArray(std::string line){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == ' '){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != ' '){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static std::vector<std::string> lineArray(std::string line, char delimiter){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == delimiter){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != delimiter){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static nlohmann::ordered_json readSTAR(std::string filename){
	
	nlohmann::ordered_json data;
	data = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;
	std::string block;
	std::vector<std::string> headers;
	int linecount = 0;
	
	bool datablock = false;
	bool loopblock = false;
	
	while(std::getline(buf, line)){
		if(line.find("version") != 0){
			std::vector<std::string> linearray;
			linearray = lineArray(line);
			if(linearray.size() > 0){
				if (linearray[0].find("data_") == 0){
					loopblock = false;
					datablock = true;
					headers.clear();
					block = linearray[0];
					data[block] = {};
				} else if (datablock && linearray[0].find("loop_") == 0){
					loopblock = true;
					linecount = 0;
					data[block]["loop"] = {};
				} else if (datablock && ! loopblock && (linearray[0].find("_rln") == 0 || linearray[0].find("_spl") == 0)){
					data[block][linearray[0]] = linearray[1];
				} else if (datablock && loopblock && (linearray[0].find("_rln") == 0 || linearray[0].find("_spl") == 0)){
					headers.push_back(linearray[0]);
				} else if (loopblock && linearray.size() == headers.size()){
					nlohmann::ordered_json loopline;
					loopline = {};
					for(int i = 0; i < headers.size(); i++){
						loopline[headers[i]] = linearray[i];	
					}
					data[block]["loop"] += loopline;
					
					linecount++;
				
				}
			}
		}
	}

	return data;

}


static nlohmann::ordered_json readSTAR(std::string filename, int limit){
	
	nlohmann::ordered_json data;
	data = {};
	
	std::ifstream input (filename.c_str()); 
	
	std::string line;
	std::string block;
	std::vector<std::string> headers;
	int linecount = 0;
	
	bool datablock = false;
	bool loopblock = false;
	
	while(std::getline(input, line)){
		if(line.find("version") != 0){
			std::vector<std::string> linearray;
			linearray = lineArray(line);
			if(linearray.size() > 0){
				if (linearray[0].find("data_") == 0){
					loopblock = false;
					datablock = true;
					headers.clear();
					block = linearray[0];
					data[block] = {};
				} else if (datablock && linearray[0].find("loop_") == 0){
					loopblock = true;
					linecount = 0;
					data[block]["loop"] = {};
				} else if (datablock && ! loopblock && (linearray[0].find("_rln") == 0 || linearray[0].find("_spl") == 0)){
					data[block][linearray[0]] = linearray[1];
				} else if (datablock && loopblock && (linearray[0].find("_rln") == 0 || linearray[0].find("_spl") == 0)){
					headers.push_back(linearray[0]);
				} else if (loopblock && linearray.size() == headers.size()){
					nlohmann::ordered_json loopline;
					loopline = {};
					for(int i = 0; i < headers.size(); i++){
						loopline[headers[i]] = linearray[i];	
					}
					data[block]["loop"] += loopline;
					
					linecount++;
					std::cout << "STAR LIMIT " << linecount << " " << limit << std::endl;
					if(limit > 0 && linecount == limit){
						break;
					}
				
				}
			}
		}
	}

	return data;

}

static nlohmann::ordered_json readSTAR(std::string filename, std::string pattern, int limit = 0){
	
	nlohmann::ordered_json data;
	data = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;
	std::string block;
	std::vector<std::string> headers;
	int linecount = 0;
	
	bool datablock = false;
	bool loopblock = false;
	
	while(std::getline(buf, line)){
		if(line.find("version") != 0 ){
			std::vector<std::string> linearray;
			linearray = lineArray(line);
			if(linearray.size() > 0){
				if (linearray[0].find("data_") == 0){
					loopblock = false;
					datablock = true;
					headers.clear();
					block = linearray[0];
					data[block] = {};
				} else if (datablock && linearray[0].find("loop_") == 0){
					loopblock = true;
					linecount = 0;
					data[block]["loop"] = {};
				} else if (datablock && ! loopblock && linearray[0].find("_rln") == 0 && linearray[0].find("_spl") == 0){
					data[block][linearray[0]] = linearray[1];
				} else if (datablock && loopblock && (linearray[0].find("_rln") == 0 || linearray[0].find("_spl") == 0)){
					headers.push_back(linearray[0]);
				} else if (loopblock && linearray.size() == headers.size() && line.find(pattern) != std::string::npos){
					nlohmann::ordered_json loopline;
					loopline = {};
					for(int i = 0; i < headers.size(); i++){
						loopline[headers[i]] = linearray[i];	
					}
					data[block]["loop"] += loopline;
					
					linecount++;
					if(limit > 0 && linecount == limit){
						break;
					}
				}
			}
		}
	}

	return data;

}

static nlohmann::ordered_json readHeaderlessSTAR(std::string filename){

	nlohmann::ordered_json data;
	data["data"] = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;

	while(std::getline(buf, line)){
		
		std::vector<std::string> linearray;
		linearray = lineArray(line);
		nlohmann::ordered_json linejson = {};
		
		if(linearray.size() > 0){
			for(int i = 0; i < linearray.size(); i++){
				linejson += linearray[i];
			}
		}
		//data["data"] += linearray;
		data["data"] += linejson;
	}

	return data;

}

static bool writeSTAR(std::string filename, nlohmann::ordered_json stardata){
	
	std::ofstream output (filename.c_str(), std::ofstream::out|std::ofstream::trunc); 

	for (auto& element : stardata.items()){
		std::string sectionname = element.key();
		nlohmann::ordered_json section = element.value();
		
		output << std::endl;
		output << sectionname << std::endl;
		output << std::endl;

		if(section.contains("loop") && section["loop"].size() > 0){
			
			output << "loop_" << std::endl;

			int linecount = 1;

			for (auto& [key, val] : section["loop"][0].items()){
				output << key << " #" << linecount << std::endl;
				linecount++;
			}

			for(int i = 0; i < section["loop"].size(); i++){ //might be faster with iterators
			
				output << std::endl;
			
				for (auto& [key, val] : section["loop"][i].items()){
				
					output << val.get<std::string>() << "  ";
				
				}
			
			}

		}else{
			for (auto& [key, val] : section.items()){
				output << key << " " << val.get<std::string>() << std::endl;
			}
		}

		output << std::endl;

	}

	output.close();

	return true;

}


static bool writeSTARold(std::string filename, nlohmann::ordered_json stardata){
	
	std::ofstream output (filename.c_str(), std::ofstream::out|std::ofstream::trunc); 

	if(stardata.contains("data_optics") && stardata["data_optics"]["loop"].size() > 0){
		
		output << std::endl;
		output << "data_optics" << std::endl;
		output << std::endl;
		output << "loop_" << std::endl;
		
		int linecount = 1;
		
		for (auto& [key, val] : stardata["data_optics"]["loop"][0].items()){
			output << key << " #" << linecount << std::endl;
			linecount++;
		}
		
		
		for(int i = 0; i < stardata["data_optics"]["loop"].size(); i++){ //might be faster with iterators
			
			output << std::endl;
			
			for (auto& [key, val] : stardata["data_optics"]["loop"][i].items()){
				
				output << val.get<std::string>() << "  ";
				
			}
			
		}
		
		output << std::endl;
		
	}
	
	if(stardata.contains("data_micrographs") && stardata["data_micrographs"]["loop"].size() > 0){
		
		output << std::endl;
		output << "data_micrographs" << std::endl;
		output << std::endl;
		output << "loop_" << std::endl;
		
		int linecount = 1;
		
		for (auto& [key, val] : stardata["data_micrographs"]["loop"][0].items()){
			output << key << " #" << linecount << std::endl;
			linecount++;
		}
		
		
		for(int i = 0; i < stardata["data_micrographs"]["loop"].size(); i++){ //might be faster with iterators
			
			output << std::endl;
			
			for (auto& [key, val] : stardata["data_micrographs"]["loop"][i].items()){
				
				output << val.get<std::string>() << "  ";
				
			}
			
		}
		
		output << std::endl;
		
	}

	if(stardata.contains("data_particles") && stardata["data_particles"]["loop"].size() > 0){
		
		output << std::endl;
		output << "data_particles" << std::endl;
		output << std::endl;
		output << "loop_" << std::endl;
		
		int linecount = 1;
		
		for (auto& [key, val] : stardata["data_particles"]["loop"][0].items()){
			output << key << " #" << linecount << std::endl;
			linecount++;
		}
		
		
		for(int i = 0; i < stardata["data_particles"]["loop"].size(); i++){ //might be faster with iterators
			
			output << std::endl;
			
			for (auto& [key, val] : stardata["data_particles"]["loop"][i].items()){
				
				output << val.get<std::string>() << "  ";
				
			}
			
		}
		
		output << std::endl;
		
	}

	output.close();

	return true;

}


#endif

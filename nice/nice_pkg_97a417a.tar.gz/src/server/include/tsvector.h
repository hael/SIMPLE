#ifndef TSVECTOR
#define TSVECTOR

#include <mutex>
#include <vector>
#include <algorithm>

// Thread-safe queue
template <typename T>
class TSVector {
	private:
	    std::vector<T> m_vector;
	    std::mutex m_mutex;

	public:
	    void push_back(T item){
	    	m_mutex.lock();
	        m_vector.push_back(item);
	        m_mutex.unlock();
	    }

	    bool contains(T testitem, bool add = false){
	    	m_mutex.lock();
	    	bool returnbool = std::any_of(m_vector.begin(), m_vector.end(), [testitem](T item){return item == testitem;});
	    	if(add && !returnbool){
	    		m_vector.push_back(testitem);
	    	}
	    	m_mutex.unlock();
	    	return returnbool;
	    }
};

#endif
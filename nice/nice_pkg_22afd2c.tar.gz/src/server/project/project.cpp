#include <project.h>
#include <workspace.h>

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Project::Project () {
    this->project_id = -1;
}

Project::Project (nlohmann::ordered_json args) {
    this->project_id = -1;
    if(json_test_int(args, "currentprojectid")){
        this->LoadProject(args["currentprojectid"].get<int>());
    }
}

bool Project::LoadProject(int project_id){
    pqxx::result project = sql_nontx_result("SELECT folder,name FROM projects WHERE id=" + std::to_string(project_id) + ";");
    if(project.size() > 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve single project from db");
        this->project_id = -1;
        return false;
    }else if(project.size() < 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed retrieve project from db");
        this->project_id = -1;
        return false;
    }
    if(project[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived project folder is null");
        this->project_id = -1;
        return false;
    }
    if(project[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - retreived project name is null");
        this->project_id = -1;
        return false;
    }
    this->project_id     = project_id;
    this->project_folder = project[0][0].as<std::string>();
    this->project_name   = project[0][1].as<std::string>();
    return true;
}

int Project::CreateProject(std::string projectname, std::string projectfolder){

    pqxx::result existing_projects = sql_nontx_result("SELECT name,folder FROM projects WHERE name='" + projectname + "' OR folder='" + projectfolder + "';");

    if(existing_projects.size() > 0){
        for (pqxx::result::const_iterator project = existing_projects.begin(); project != existing_projects.end(); ++project) {
            if(!project[0].is_null() && project[0].as<std::string>() == projectname){
                return PREEXISTING_PROJECT;
            }
            if(!project[1].is_null() && project[1].as<std::string>() == projectfolder){
                return PREEXISTING_FOLDER;
            }
        }
    }

    if(!folderExists(projectfolder)){
        return MISSING_FOLDER;
    }

    pqxx::result new_project = sql_result(std::string_view{"INSERT INTO projects (name,folder) VALUES ('" + projectname + "','" + projectfolder + "') RETURNING id;"});

    if(new_project.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to insert project into database");
        return FAILURE;
    }

    if(new_project[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted project id is null");
        return FAILURE;
    }

    int project_id = new_project[0][0].as<int>();

    if(project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted project id is invalid");
        return FAILURE;
    }

    Workspace workspace(project_id);
    int create = workspace.CreateWorkspace();

    if(create > 0){
        return create;
    }

    this->project_id     = project_id;
    this->project_folder = projectfolder;

    return SUCCESS;
}

nlohmann::ordered_json Project::NewProject(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;
    if(!json_test_string(args, "projectname") || !json_test_string(args, "projectfolder") ){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid args " + args.dump());
        returnjson["success"] = false;
        return returnjson;
    }
    std::string projectname   = args["projectname"].get<std::string>();
    std::string projectfolder = args["projectfolder"].get<std::string>();

    int create = this->CreateProject(projectname, projectfolder);

    if(create > 0){
        returnjson["success"] = false;
        if(create == FAILURE){
            // generic error
        }else if(create == PREEXISTING_PROJECT){
            // project exists
            returnjson["projectexists"] = true;
        }else if(create == PREEXISTING_FOLDER){
            // folder exists
            returnjson["folderexists"] = true;
        }else if(create == MISSING_FOLDER){
            // folder missing
            returnjson["foldermissing"] = true;
        }else if(create == FAILED_MKFOLDER){
            // folder missing
        }

    }else{
        returnjson["success"] = true;
        nlohmann::ordered_json projectstat = this->StatProject();
        if(json_test_object(projectstat, "projectstats")){
            returnjson["project"] = projectstat["projectstats"];
        }   
    }

    return returnjson;
}

nlohmann::ordered_json Project::ListAllProjects(){
    nlohmann::ordered_json returnjson;
    returnjson["projects"] = {};
    pqxx::result existing_projects = sql_nontx_result("SELECT id,name,folder FROM projects ORDER BY id ASC;");
    for (pqxx::result::const_iterator project = existing_projects.begin(); project != existing_projects.end(); ++project) {
        nlohmann::ordered_json projectjson;
        if(project[0].is_null() || project[1].is_null() || project[2].is_null()) continue;
        projectjson["id"]     = project[0].as<int>();
        projectjson["name"]   = project[1].as<std::string>();
        projectjson["folder"] = project[2].as<std::string>();
        returnjson["projects"].push_back(projectjson);
    }
    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Project::ListRecentProjects(){
    nlohmann::ordered_json returnjson = {};
    returnjson["recentprojects"] = {};

    returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Project::StatProject(){
    nlohmann::ordered_json returnjson;
    if(this->project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid project id");
        returnjson["success"] = false; 
    }else{
        returnjson["projectstats"] = {};
        returnjson["projectstats"]["id"]     = this->project_id;
        returnjson["projectstats"]["folder"] = this->project_folder;
        returnjson["projectstats"]["name"]   = this->project_name;
        returnjson["success"] = true; 
    }
    return returnjson;
}

nlohmann::ordered_json Project::Rename(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;
    if(this->project_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid project id");
        returnjson["success"] = false; 
        return returnjson;
    }
    if(!json_test_string(args, "projectname")){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing project name");
        returnjson["success"] = false; 
        return returnjson;
    }

    std::string projectname = args["projectname"].get<std::string>();
    sql_request(std::string_view{"UPDATE projects SET name='" + projectname + "' WHERE id=" + std::to_string(this->project_id)  + ";"});
    this->project_name = projectname;
    returnjson["projectname"] = this->project_name;
    returnjson["success"]     = true; 
    return returnjson;
}
#include "http_server.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

HTTPServer::HTTPServer (std::string comm_addr_str, bool local) {
    // logfile path
    this->logpath = getRootDir() + "/var/log/HTTPServer.txt";
    // create logger if not already existing
    if(spdlog::get("HTTPServer") == nullptr){
        auto logger = spdlog::rotating_logger_mt("HTTPServer", this->logpath, 1048576 * 5, 5);
    }
    // public directory
    this->publicdir = getRootDir() + "/var/www/public";
    if(!folderExists(this->publicdir)) {
        spdlog::get("master")->error("HTTPServer failed to initialize. " + this->publicdir + " does not exist");
        return;
    }
    // config
    nlohmann::ordered_json config = RetreiveConfig();
    if(json_test_int(config, "http_port"))  this->port = config["http_port"].get<int>();
    if(json_test_string(config, "http_ip")) this->ip   = config["http_ip"].get<std::string>();
    this->local = local;
    this->http_addr_str = "http://" + this->ip + ":" + std::to_string(this->port);
    this->comm_addr_str = comm_addr_str;
    // start
    this->Start();
    // console log running
    spdlog::get("master")->info("HTTPServer running. Logs will be written to " + this->logpath);
}

bool HTTPServer::Status (bool quiet) {
    // current status
    bool thread_status = this->healthy;
    // reset status
    this->healthy = false;
    // log if not healthy and not quiet
    if(!thread_status && !quiet){
        spdlog::get("master")->error("HTTPServer failed. More details may be found in " + this->logpath);
        spdlog::get("HTTPServer")->error("HTTPServer failed");
    }
    return thread_status;
}

void HTTPServer::Stop () {
    // console log stop
    spdlog::get("master")->info("HTTPServer stopping");
    // send signal
    this->terminate = true;
    // wait for status
    while(this->Status(true)){
        sleep(1);
    }
    // log stopped
    spdlog::get("master")->info("HTTPServer stopped");
    spdlog::get("HTTPServer")->info("HTTPServer stopped");
}

void HTTPServer::Start () {
    // console log start
    spdlog::get("master")->info("HTTPServer starting");
    spdlog::get("HTTPServer")->info("HTTPServer starting");
    // start daemon thread
    this->terminate = false;
    this->workerthread = std::thread(&HTTPServer::Listener, this);
    this->workerthread.detach();
}

void HTTPServer::Listener () {
    // init time 
    time_t now = time(NULL);
    struct tm now_datetime = *localtime(&now);
    // init user token renewal trigger
    bool renew_tokens = false;
    // Set log level
    mg_log_set(MG_LL_INFO);  
    // Create and Initialize event manager
    struct mg_mgr mgr;
    mg_mgr_init(&mgr); 
    // Create connection
    struct mg_connection *c;
    if(this->local){
        for (int trial = 0; trial < 10; trial++){
            this->port = this->port + trial;
            this->http_addr_str = "http://localhost:" + std::to_string(this->port);
            c = mg_http_listen(&mgr, this->http_addr_str.c_str(), HTTPServer::RequestHandler, this);
            if(c == NULL){
                spdlog::get("HTTPServer")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - port in use. Trialling next");
            }else{
                spdlog::get("HTTPServer")->info(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - listening on " + this->http_addr_str);
                break;
            }
        }
        // lock caches
        std::lock_guard<std::mutex> guard(this->cache_lock);
        this->LoadUsers();
    }else{
        c = mg_http_listen(&mgr, this->http_addr_str.c_str(), HTTPServer::RequestHandler, this);
    }
    if (c == NULL) {
        spdlog::get("HTTPServer")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - can't open connection");
        return;
    }
    // Initialize wakeup scheme
    mg_wakeup_init(&mgr);
    //main loop
    int counter    = 0; 
    int block_ms   = 100; 
    int test_count = 30 * 60 * 1000 / block_ms; // 30 minutes
    while (true){
        this->healthy = true;
        mg_mgr_poll(&mgr, block_ms);  // Infinite event loop, blocks for up to test_count ms
        if(counter == test_count){
            // renew tokens every sunday
            now = time(NULL);
            now_datetime = *localtime(&now);
            if(!renew_tokens && now_datetime.tm_wday > 0){
                renew_tokens = true;
            }
            if(renew_tokens && now_datetime.tm_wday == 0){
                renew_tokens = false;
                this->RefreshTokens();
            }
            counter = 0;
        }
        counter++;
        if(this->terminate) break;
  }
  mg_mgr_free(&mgr);         // Free resources
}

void HTTPServer::RequestHandler(struct mg_connection *c, int ev, void *ev_data) {
    //self is this
    HTTPServer* self = (HTTPServer*) c->fn_data;
    if (ev == MG_EV_HTTP_MSG) {
        struct mg_http_message* hm = (struct mg_http_message*) ev_data;
        struct mg_iobuf* r = &c->recv;
        struct user_data userdata;
        bool valid_login = self->ValidUser(ev_data, &userdata);
        if(mg_match(hm->uri, mg_str("/"), NULL)){
            struct mg_http_serve_opts opts = {
                    .extra_headers = "Cache-Control: private,max-age=10800\r\nCross-Origin-Opener-Policy: same-origin\r\nCross-Origin-Embedder-Policy: require-corp\r\n",
                    .mime_types    = "html=text/html"
            };
            std::string html_path;
            if(valid_login){
                html_path = self->publicdir + "/nice.html";
            }else{
                html_path = self->publicdir + "/login.html";
            }
            mg_http_serve_file(c, hm, html_path.c_str(), &opts);
        }else if(mg_match(hm->uri, mg_str("/login"), NULL)){
            struct mg_http_serve_opts opts = {
                    .extra_headers = "Cache-Control: private,max-age=10800\r\n",
                    .mime_types    = "html=text/html"
            };
            if(valid_login){
                std::string headers = "Content-Type: application/json\r\nCross-Origin-Opener-Policy: same-origin\r\n"
                    "Cross-Origin-Embedder-Policy: require-corp\r\nCache-Control: no-store,no-cache,max-age=0\r\n"
                    "Set-Cookie: access_token=" + userdata.token + "; Max-Age=604800\r\n";// 1 week cookie
                mg_http_reply(c, 200, headers.c_str(),"{}\n");
            }else{
                std::string username_correct = "false";
                std::string password_correct = "false";
                if(userdata.username == ""){
                    username_correct = "true";
                }else{
                    password_correct = "true";
                }
                mg_http_reply(c, 401, "Content-Type: application/json\r\nCross-Origin-Opener-Policy: same-origin\r\n"
                    "Cross-Origin-Embedder-Policy: require-corp\r\nCache-Control: no-store,no-cache,max-age=0\r\n"
                    "Clear-Site-Data: \"cookies\"\r\n",
                    "{%m:%m,%m:%m}\n", MG_ESC("username"), MG_ESC(username_correct.c_str()), MG_ESC("password"), MG_ESC(password_correct.c_str()));
            }
        }else if(mg_match(hm->uri, mg_str("/api/json"), NULL)){
            struct thread_data* data = (struct thread_data*) calloc(1, sizeof(*data));
            data->conn_id = c->id;
            data->mgr     = c->mgr;
            data->json_str.resize(hm->body.len);
            data->comm_addr_str = self->comm_addr_str;
            data->local = self->local;
            memcpy(&data->json_str[0], &hm->body.buf[0], hm->body.len);
            HTTPServer::RequestThread(HTTPServer::RequestProcessJSON, data);
        }else if(mg_match(hm->uri, mg_str("/api/thumbnail/#"), NULL)){
            std::string uri(hm->uri.buf, hm->uri.len);
            std::string uid = uri.substr(15);
            struct thread_data* data = (struct thread_data*) calloc(1, sizeof(*data));
            data->conn_id = c->id;
            data->mgr     = c->mgr;
            data->thumbnail_uid = uid;
            data->comm_addr_str = self->comm_addr_str;
            data->local = self->local;
                   
            HTTPServer::RequestThread(HTTPServer::RequestProcessThumbnail, data);
        }else if(mg_match(hm->uri, mg_str("/api/thumbpath/#"), NULL)){
            std::string uri(hm->uri.buf, hm->uri.len);
            std::string thumbpath = uri.substr(14);
            struct thread_data* data = (struct thread_data*) calloc(1, sizeof(*data));
            data->conn_id = c->id;
            data->mgr     = c->mgr;
            data->thumbnail_path = thumbpath;
            data->comm_addr_str = self->comm_addr_str;
            data->local = self->local;
            std::string query(hm->query.buf, hm->query.len);
            if(query.substr(0, 7) == "boxfile"){
                if(query.find("&nocache") != std::string::npos){
                    data->boxfile_path = query.substr(8, query.find("&nocache") - 8);
                }else{
                   data->boxfile_path = query.substr(8); 
                }
            }
            HTTPServer::RequestThread(HTTPServer::RequestProcessThumbnail, data);
        }else if(mg_match(hm->uri, mg_str("/api/volpath/#"), NULL)){
            std::string uri(hm->uri.buf, hm->uri.len);
            std::string volpath = uri.substr(12);
            struct thread_data* data = (struct thread_data*) calloc(1, sizeof(*data));
            data->conn_id = c->id;
            data->mgr     = c->mgr;
            data->volume_path = volpath;
            data->comm_addr_str = self->comm_addr_str;
            data->local = self->local;
            HTTPServer::RequestThread(HTTPServer::RequestProcessVolume, data);   
        }else{
            struct mg_http_serve_opts opts = {
                    .root_dir = self->publicdir.c_str(),
                    .extra_headers = "Cache-Control: private,max-age=10800\r\nCross-Origin-Opener-Policy: same-origin\r\nCross-Origin-Embedder-Policy: require-corp\r\n",
                    .mime_types = "wasm=application/wasm"};
            mg_http_serve_dir(c, hm, &opts);
        }
        r->len = 0;                  // Tell Mongoose we've consumed data
    } else if (ev == MG_EV_WAKEUP) {
        struct mg_str *data = (struct mg_str *) ev_data;
        struct chunk_data* chunkdata = *(struct chunk_data **) data->buf;
        if(chunkdata->type == MSGPACK){
            if(chunkdata->start){
               mg_printf(c, "HTTP/1.1 200 OK\r\nContent-Type: application/msgpack\r\nTransfer-Encoding: chunked\r\n\r\n"); 
            }
            mg_http_write_chunk(c, (char*)&chunkdata->length, sizeof(int));
            mg_http_write_chunk(c, chunkdata->ptr, chunkdata->length);
            if(chunkdata->end){
                mg_http_printf_chunk(c, "");  // last empty chunk
            }
            free((void*)chunkdata->ptr);
        }else if(chunkdata->type == CACHED_JPEG){
            if(chunkdata->start){
               mg_printf(c, "HTTP/1.1 200 OK\r\nCache-Control: private,max-age=3600\r\nContent-Type: image/jpeg\r\nTransfer-Encoding: chunked\r\n\r\n"); 
            }
            mg_http_write_chunk(c, chunkdata->ptr, chunkdata->length);
            if(chunkdata->end){
                mg_http_printf_chunk(c, "");  // last empty chunk
            }
            free((void*)chunkdata->ptr);
        }else if(chunkdata->type == NULL_CHUNK){
            if(chunkdata->start){
               mg_printf(c, "HTTP/1.1 200 OK\r\nCache-Control: private,max-age=0,no-cache\r\nContent-Type: image/jpeg\r\nTransfer-Encoding: chunked\r\n\r\n"); 
            }
            if(chunkdata->end){
                mg_http_printf_chunk(c, "");  // last empty chunk
            }
        }else if(chunkdata->type == CACHED_BINARY){
            if(chunkdata->start){
               mg_printf(c, "HTTP/1.1 200 OK\r\nCache-Control: private,max-age=3600\r\nContent-Type: application/octet-stream\r\nTransfer-Encoding: chunked\r\n\r\n"); 
            }
            mg_http_write_chunk(c, chunkdata->ptr, chunkdata->length);
            if(chunkdata->end){
                mg_http_printf_chunk(c, "");  // last empty chunk
            }
        }
        free(chunkdata);
    } else if (ev == MG_EV_CLOSE) {
        MG_INFO(("SERVER disconnected"));
    } else if (ev == MG_EV_ERROR) {
        MG_INFO(("SERVER error: %s", (char *) ev_data));
    }
  (void) ev_data;
}

void HTTPServer::RequestThread(void *(*f)(void *), void *p) {
    pthread_t thread_id = (pthread_t) 0;
    pthread_attr_t attr;
    (void) pthread_attr_init(&attr);
    (void) pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&thread_id, &attr, f, p);
    pthread_attr_destroy(&attr);
}

void* HTTPServer::RequestProcessJSON(void* p) {
  struct thread_data* data = (struct thread_data*) p;
  nlohmann::ordered_json returnjson;
  if(nlohmann::ordered_json::accept(data->json_str)){
    nlohmann::ordered_json jobstat_json = nlohmann::ordered_json::parse(data->json_str);
    std::cout << jobstat_json.dump() << std::endl; // for testing
    if(json_test_string(jobstat_json, "fnc") && json_test_object(jobstat_json, "args")){
        std::string fnc = jobstat_json["fnc"].get<std::string>();
        if(fnc == "newproject"){
            Project* project = new Project();
            SendMsgpackChunk(p, project->NewProject(jobstat_json["args"]));
            delete project;
        }else if(fnc == "newworkspace"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->NewWorkspace(),      true,  false);
            SendMsgpackChunk(p, workspace->StatWorkspace(),     false, false);
            SendMsgpackChunk(p, workspace->ListAllWorkspaces(), false, true);   
            delete workspace;   
        }else if(fnc == "newjob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->NewJob());
            delete job;
        }else if(fnc == "listprojects"){
            Project* project = new Project(jobstat_json["args"]);
            SendMsgpackChunk(p, project->StatProject(),        true,  false);
            SendMsgpackChunk(p, project->ListRecentProjects(), false, false);
            SendMsgpackChunk(p, project->ListAllProjects(),    false, true);   
            delete project;
        }else if(fnc == "listworkspaces"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->StatWorkspace(),    true, false);
            SendMsgpackChunk(p, workspace->ListRecentWorkspaces(), false, false);
            SendMsgpackChunk(p, workspace->ListAllWorkspaces(), false, true);   
            delete workspace;
        }else if(fnc == "renameproject"){
            Project* project = new Project(jobstat_json["args"]);
            SendMsgpackChunk(p, project->Rename(jobstat_json["args"]));
        }else if(fnc == "renameworkspace"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->Rename(jobstat_json["args"]));   
        }else if(fnc == "listjobs"){
            Job* job = new Job(jobstat_json["args"]);
            nlohmann::ordered_json jobslist = job->ListJobs();
            if(json_test_string(jobstat_json["args"], "reloadhash")){
                std::string existinghash = jobstat_json["args"]["reloadhash"].get<std::string>();
                std::string newhash      = QuickDigest5::toHash(jobslist.dump());
                if(existinghash == newhash){
                    nlohmann::ordered_json returnhash;
                    returnhash["success"] = true;
                    returnhash["reloadhash"] = newhash;
                    SendMsgpackChunk(p, returnhash);  
                }else{
                   jobslist["reloadhash"] = newhash;
                   SendMsgpackChunk(p, jobslist);   
                }
            }else{
                SendMsgpackChunk(p, jobslist);  
            }
            delete job;
        }else if(fnc == "listbuildablejobs"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->ListBuildableJobs());  
            delete job;
        }else if(fnc == "buildjob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->BuildJob());  
            delete job;   
        }else if(fnc == "statproject"){
            Project* project = new Project(jobstat_json["args"]);
            SendMsgpackChunk(p, project->StatProject(), true, false);
            delete project;
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            workspace->LoadLastAccessedWorkspace();
            SendMsgpackChunk(p, workspace->StatWorkspace(), false, true);
            delete workspace;
        }else if(fnc == "statprojectfile"){
            Simple* simple = new Simple();
            SendMsgpackChunk(p, simple->StatProjectFile(jobstat_json["args"]));
            delete simple;
        }else if(fnc == "statprojectfiledata"){
            Simple* simple = new Simple();
            SendMsgpackChunk(p, simple->StatProjectFileData(jobstat_json["args"]));
            delete simple;
        }else if(fnc == "projfileselection"){
            Simple* simple = new Simple();
            SendMsgpackChunk(p, simple->ProjfileSelection(jobstat_json["args"]));
            delete simple;   
        }else if(fnc == "getselectionarray"){
            Simple* simple = new Simple();
            if(json_test_int(jobstat_json["args"], "currentjobid")){
                Job* job = new Job(jobstat_json["args"]);
                jobstat_json["args"]["projfile"] = job->job_folder + "/workspace.simple";
                delete job;
            }
            SendMsgpackChunk(p, simple->ProjfileSelectionArray(jobstat_json["args"]));
            delete simple;
        }else if(fnc == "statjob"){
            Job* job = new Job(jobstat_json["args"]);
            nlohmann::ordered_json jobstat = job->StatJob();
            if(json_test_string(jobstat_json["args"], "reloadhash")){
                std::string existinghash = jobstat_json["args"]["reloadhash"].get<std::string>();
                std::string newhash      = QuickDigest5::toHash(jobstat.dump());
                if(existinghash == newhash){
                    nlohmann::ordered_json returnhash;
                    returnhash["success"] = true;
                    returnhash["reloadhash"] = newhash;
                    SendMsgpackChunk(p, returnhash);  
                }else{
                   jobstat["reloadhash"] = newhash;
                   SendMsgpackChunk(p, jobstat);   
                }
            }else{
                SendMsgpackChunk(p, jobstat);  
            }
            delete job;
        }else if(fnc == "statjobdata"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->StatJobData(jobstat_json["args"]));
            delete job;  
        }else if(fnc == "statheadlinesjob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->StatHeadlinesJob());
            delete job;    
        }else if(fnc == "accessworkspace"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->AccessWorkspace());
            delete workspace;
        }else if(fnc == "start"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->StartJob(jobstat_json["args"], data->comm_addr_str, data->local));
            delete job;
        }else if(fnc == "updateprocess"){
            Process* process = new Process(jobstat_json["args"], 1);
            if(json_test_bool(jobstat_json["args"], "snapshot") && jobstat_json["args"]["snapshot"]){
                Job* snapshot_job = new Job(jobstat_json["args"]);
                snapshot_job->CreateJob();
                snapshot_job->SetQueued();
                if(json_test_object(jobstat_json["args"], "updatearguments")){
                   jobstat_json["args"]["updatearguments"]["snapshot"]           = snapshot_job->job_folder + "/workspace.simple"; // only handles simple ATM 
                   jobstat_json["args"]["updatearguments"]["snapshot_jobid"]     = snapshot_job->job_id;
                   jobstat_json["args"]["updatearguments"]["snapshot_displayid"] = snapshot_job->display_id;
                }
                delete snapshot_job;
                process->SetUserInput(false);
            }
            SendMsgpackChunk(p, process->UpdateArguments(jobstat_json["args"]));
            delete process;  
        }else if(fnc == "renamejob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->RenameJob(jobstat_json["args"]));
            delete job;
        }else if(fnc == "deletejob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->DeleteJob());
            delete job;
        }else if(fnc == "clearworkspacetrash"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->ClearTrash());
            delete workspace;
        }else if(fnc == "clearprojecttrash"){
            Workspace* workspace = new Workspace(jobstat_json["args"]);
            SendMsgpackChunk(p, workspace->ClearProjectTrash());
            delete workspace;
        }else if(fnc == "retrievejob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->RetrieveJob());
            delete job;
        }else if(fnc == "restartjob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->RestartJob());
            delete job;   
        }else if(fnc == "completeprocesses"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->CompleteProcesses());
            delete job;
        }else if(fnc == "completejob"){
            Job* job = new Job(jobstat_json["args"]);
            SendMsgpackChunk(p, job->Complete());
            delete job;
        }else if(fnc == "statlog"){
            SendMsgpackChunk(p, StatLog(jobstat_json["args"]));
        }else if(fnc == "statdir"){
            SendMsgpackChunk(p, StatDir(jobstat_json["args"]));
        }else if(fnc == "saveboxes"){
             SendMsgpackChunk(p, SaveBoxes(jobstat_json["args"]));
        }else{
            returnjson["success"] = false;
            SendMsgpackChunk(p, returnjson);
        }
    }else{
        returnjson["success"] = false;
        SendMsgpackChunk(p, returnjson);
    }
  }else{
    returnjson["success"] = false;
    SendMsgpackChunk(p, returnjson);
  }
  free(data);
  return NULL;
}

void* HTTPServer::RequestProcessThumbnail(void* p) {
  struct thread_data* data = (struct thread_data*) p;
  Imager* imager;
  if(data->thumbnail_uid != ""){
    imager = new Imager(data->thumbnail_uid);
  }else if(data->thumbnail_path != ""){
    imager = new Imager(1, data->thumbnail_path, data->boxfile_path);
  }else{
    SendNullChunk(p);
    free(data);
    return NULL;
  }
  if(imager->type == THUMBNAIL_JPEG){
    SendJpegChunk(p, imager->binary_data, imager->datalength);
  }else{
    SendNullChunk(p);
  }
  delete imager;
  free(data);
  return NULL;
}

void* HTTPServer::RequestProcessVolume(void* p) {
  struct thread_data* data = (struct thread_data*) p;
  Imager* imager;
  if(data->volume_path != ""){
    imager = new Imager(2, data->volume_path);
  }else{
    SendNullChunk(p);
    free(data);
    return NULL;
  }
  if(imager->type == BINARY){
    SendBinaryChunk(p, imager->binary_data, imager->datalength);
  }else{
    SendNullChunk(p);
  }
  delete imager;
  free(data);
  return NULL;
}
void HTTPServer::SendMsgpackChunk(void* p, nlohmann::ordered_json chunkjson, bool start, bool end){
    struct thread_data* data = (struct thread_data*) p;
    std::vector<std::uint8_t> returnmsgpack = nlohmann::ordered_json::to_msgpack(chunkjson);
    struct chunk_data* chunkdata = (struct chunk_data*) malloc(sizeof(*chunkdata));
    chunkdata->start  = start;
    chunkdata->end    = end;
    chunkdata->length = returnmsgpack.size();
    chunkdata->ptr    = (const char*) malloc(chunkdata->length);
    chunkdata->type   = MSGPACK;
    memcpy((void*)chunkdata->ptr, &returnmsgpack[0], chunkdata->length);
    mg_wakeup(data->mgr, data->conn_id, &chunkdata, sizeof(*chunkdata));
}

void HTTPServer::SendJpegChunk(void* p, char* datastart, int datalength, bool start, bool end){
    struct thread_data* data = (struct thread_data*) p;
    struct chunk_data* chunkdata = (struct chunk_data*) malloc(sizeof(*chunkdata));
    chunkdata->start  = start;
    chunkdata->end    = end;
    chunkdata->length = datalength;
    chunkdata->ptr    = datastart;
    chunkdata->type   = CACHED_JPEG;
    mg_wakeup(data->mgr, data->conn_id, &chunkdata, sizeof(*chunkdata));
}

void HTTPServer::SendNullChunk(void* p, bool start, bool end){
    struct thread_data* data = (struct thread_data*) p;
    struct chunk_data* chunkdata = (struct chunk_data*) malloc(sizeof(*chunkdata));
    chunkdata->start  = start;
    chunkdata->end    = end;
    chunkdata->length = 0;
    chunkdata->type   = NULL_CHUNK;
    mg_wakeup(data->mgr, data->conn_id, &chunkdata, sizeof(*chunkdata));
}

void HTTPServer::SendBinaryChunk(void* p, char* datastart, int datalength, bool start, bool end){
    struct thread_data* data = (struct thread_data*) p;
    struct chunk_data* chunkdata = (struct chunk_data*) malloc(sizeof(*chunkdata));
    chunkdata->start  = start;
    chunkdata->end    = end;
    chunkdata->length = datalength;
    chunkdata->ptr    = datastart;
    chunkdata->type   = CACHED_BINARY;
    mg_wakeup(data->mgr, data->conn_id, &chunkdata, sizeof(*chunkdata));
}

bool HTTPServer::ValidUser(void* ev_data, struct user_data* userdata) {
    bool returnval;
    struct mg_http_message* hm = (struct mg_http_message*) ev_data;
    char user[100], pass[100];
    mg_http_creds(hm, user, sizeof(user), pass, sizeof(pass));
    // lock caches
    spdlog::get("HTTPServer")->info("caches |" + std::string(user) + "|" + std::string(pass));
    std::lock_guard<std::mutex> guard(this->cache_lock);
    bool update_cache = false;
    // test if cached
    if (user[0] == '\0' && pass[0] != '\0'){
        // token auth
        std::string token_str = std::string(pass);
        if(this->token_cache.contains(token_str)){
            // quick exit
            *userdata = this->token_cache[token_str];
            return true;
        }else{
            update_cache = true;
        }
    }else if(user[0] != '\0' && pass[0] != '\0'){
        // username/password auth
        std::string user_str = std::string(user);
        std::string pass_str = std::string(pass);
        if(this->user_cache.contains(user_str)){
            *userdata = this->user_cache[user_str];
            if(this->user_cache[user_str].password == pass){
                // quick exit
                spdlog::get("HTTPServer")->info("successful username/password login for user " + user_str);
                return true;
            }else{
                update_cache = true;
            }
        }else{
            update_cache = true;
        }
    }else{
        // invalid
        spdlog::get("HTTPServer")->warn("invalid user credentials for user " + std::string(user));
        return false;
    }
    // reload cache from db if required
    if(update_cache){
        this->LoadUsers();
    }
    // test if authorised
   if (user[0] == '\0'){
        // token auth
        std::string token_str = std::string(user);
        if(this->token_cache.contains(token_str)){
            *userdata = this->token_cache[token_str];
            return true;
        }
    }else if(user[0] != '\0' && pass[0] != '\0'){
        // username/password auth
        std::string user_str = std::string(user);
        std::string pass_str = std::string(pass);
        if(this->user_cache.contains(user_str)){
            *userdata = this->user_cache[user_str];
            if(this->user_cache[user_str].password == pass){
                // quick exit
                spdlog::get("HTTPServer")->info("successful username/password login for user " + user_str);
                return true;
            }
        }
    }
    spdlog::get("HTTPServer")->warn("failed login attempt for user " + std::string(user));
    return false;
}

void HTTPServer::LoadUsers() {
    spdlog::get("HTTPServer")->info("loading user data");
    pqxx::result users = sql_nontx_result("SELECT username,firstname,lastname,password,token,admin FROM users WHERE password IS NOT NULL AND token IS NOT NULL;");
    this->user_cache.clear();
    this->token_cache.clear();
    if(this->local){
        struct user_data userdata;
        userdata.username  = getenv("USER");
        userdata.firstname = getenv("USER");
        userdata.lastname  = "";
        userdata.password  = gen_random(8);
        if(this->localtoken != ""){
            userdata.token = this->localtoken;
        }else{
            userdata.token = gen_random(32); 
        }
        userdata.admin     = true;
        if(userdata.username != "" && userdata.password != "" && userdata.token != ""){
            this->user_cache[userdata.username] = userdata;
            this->token_cache[userdata.token]   = userdata;
            this->localtoken = userdata.token;
        }
    }else{
        for (pqxx::result::const_iterator user = users.begin(); user != users.end(); ++user) {
            struct user_data userdata;
            if(!user[0].is_null()) userdata.username  = user[0].as<std::string>();
            if(!user[1].is_null()) userdata.firstname = user[1].as<std::string>();
            if(!user[2].is_null()) userdata.lastname  = user[2].as<std::string>();
            if(!user[3].is_null()) userdata.password  = user[3].as<std::string>();
            if(!user[4].is_null()) userdata.token     = user[4].as<std::string>();
            if(!user[5].is_null()) userdata.admin     = user[5].as<bool>();
            if(userdata.username != "" && userdata.password != "" && userdata.token != ""){
                this->user_cache[userdata.username] = userdata;
                this->token_cache[userdata.token]   = userdata;
            }
        }
    }
    spdlog::get("HTTPServer")->info("loaded user data for " + std::to_string(users.size()) + " users");
}

void HTTPServer::RefreshTokens() {
    if(!this->local){
        pqxx::result users = sql_nontx_result("SELECT id from users;");
        for (pqxx::result::const_iterator user = users.begin(); user != users.end(); ++user) {
            if(!user[0].is_null()) {
                int userid = user[0].as<int>();
                sql_request("update users set token=(SELECT md5(random()::text)) where id=" + std::to_string(userid));
            }
        }
        spdlog::get("HTTPServer")->info("Regenerated login tokens");
    }
}
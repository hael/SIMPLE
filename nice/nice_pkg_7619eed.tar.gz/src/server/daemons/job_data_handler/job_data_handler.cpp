#include "job_data_handler.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE

JobDataHandler::JobDataHandler () {
    // logfile path
    this->logpath = getRootDir() + "/var/log/JobDataHandler.txt";
    // create logger if not already existing
    if(spdlog::get("JobDataHandler") == nullptr){
      auto logger = spdlog::rotating_logger_mt("JobDataHandler", this->logpath, 1048576 * 5, 5);
    }
    // start
    this->Start();
    // console log running
    spdlog::get("master")->info("JobDataHandler running. Logs will be written to " + this->logpath);
}

bool JobDataHandler::Status (bool quiet) {
    // current status
    bool thread_status = this->healthy;
    // reset status
    this->healthy = false;
    // log if not healthy and not quiet
    if(!thread_status && !quiet){
        spdlog::get("master")->error("JobDataHandler failed. More details may be found in " + this->logpath);
        spdlog::get("JobDataHandler")->error("JobDataHandler failed. More details may be found in " + this->logpath);
    }
    return thread_status;
}

void JobDataHandler::Stop () {
    // console log stop
    spdlog::get("master")->info("JobDataHandler stopping");
    // send signal
    this->terminate = true;
    // wait for status
    while(this->Status(true)){
        sleep(1);
    }
    // log stopped
    spdlog::get("master")->info("JobDataHandler stopped");
    spdlog::get("JobDataHandler")->info("JobDataHandler stopped");
}

void JobDataHandler::Start () {
    // console log start
    spdlog::get("master")->info("JobDataHandler starting");
    spdlog::get("JobDataHandler")->info("JobDataHandler starting");
    // start daemon thread
    this->terminate = false;
    this->workerthread = std::thread(&JobDataHandler::Worker, this);
    this->workerthread.detach();
}

void JobDataHandler::Worker () {
    while (true){
        this->healthy = true;
        this->Cycle();
        sleep(30);
        if(this->terminate) break;
    }
}

void JobDataHandler::Cycle(){
    // disk space used
    std::cout << "JobDataHandler::Cycle" << std::endl;
    // get all finished/failed/stopped jobs
    pqxx::result duable_processes = sql_nontx_result("SELECT id FROM jobs WHERE diskspacemb<0 AND (status='finished' OR status='failed' OR status='stopped');");
    for (pqxx::result::const_iterator duable_process = duable_processes.begin(); duable_process != duable_processes.end(); ++duable_process) {
        if(duable_process[0].is_null()) continue;
        int job_id = duable_process[0].as<int>();
        Job* job = new Job();
        job->LoadJob(job_id);
        if(folderExists(job->job_folder)){
            sql_request("UPDATE jobs SET diskspacemb=" + std::to_string(std::uintmax_t(directorySize(job->job_folder) / (1024 * 1024))) + " WHERE id=" + std::to_string(job_id) + ";");
        }
        delete job;
    }
    // Move deleted to trash
    pqxx::result trashable_jobs = sql_nontx_result("SELECT id FROM jobs WHERE deleted=TRUE AND trashed=FALSE;");
    for (pqxx::result::const_iterator trashable_job = trashable_jobs.begin(); trashable_job != trashable_jobs.end(); ++trashable_job) {
        if(trashable_job[0].is_null()) continue;
        int job_id = trashable_job[0].as<int>();
        Job* job = new Job();
        job->LoadJob(job_id);
        ensureFolder(job->workspace_folder + "/TRASH");
        if(folderExists(job->job_folder)){
            moveFolder(job->job_folder, job->workspace_folder + "/TRASH/" + job->job_folder_base);
            sql_request("UPDATE jobs SET trashed=TRUE,retrievable=TRUE WHERE id=" + std::to_string(job_id) + ";");     
        }
        delete job;
    }
    // Empty workspace Trash
    pqxx::result trashable_workspaces = sql_nontx_result("SELECT id FROM workspaces WHERE cleartrash=TRUE;");
    for (pqxx::result::const_iterator trashable_workspace = trashable_workspaces.begin(); trashable_workspace != trashable_workspaces.end(); ++trashable_workspace) {
        if(trashable_workspace[0].is_null()) continue;
        int workspace_id = trashable_workspace[0].as<int>();
        Workspace* workspace = new Workspace();
        workspace->LoadWorkspace(workspace_id);
        if(folderExists(workspace->workspace_folder + "/TRASH")){
            std::vector<std::string> dirs;
            std::vector<std::string> files;
            if(ls1fDir(workspace->workspace_folder + "/TRASH", &dirs, &files)) {
                for(auto dir : dirs){
                    std::cout << "Deleting : " << workspace->workspace_folder + "/TRASH/" + dir << std::endl;
                    removeDirRecursive(workspace->workspace_folder + "/TRASH/" + dir );
                }
            }
        }
        sql_request("UPDATE workspaces SET cleartrash=FALSE WHERE id=" + std::to_string(workspace_id) + ";");
        delete workspace;
    } 
    //Update retrievable
    pqxx::result retreivable_jobs = sql_nontx_result("SELECT id FROM jobs WHERE retrievable=TRUE AND trashed=TRUE;");
    for (pqxx::result::const_iterator retreivable_job = retreivable_jobs.begin(); retreivable_job != retreivable_jobs.end(); ++retreivable_job) {
        if(retreivable_job[0].is_null()) continue;
        int job_id = retreivable_job[0].as<int>();
        Job* job = new Job();
        job->LoadJob(job_id);
        if(!(folderExists(job->workspace_folder) + "/TRASH" && folderExists(job->workspace_folder + "/TRASH/" + job->job_folder_base))){
            sql_request("UPDATE jobs SET retrievable=FALSE,diskspacemb=-1 WHERE id=" + std::to_string(job_id) + ";"); 
        }
        delete job;
    }
    // Retreive
    pqxx::result retreive_jobs = sql_nontx_result("SELECT id FROM jobs WHERE retrieve=TRUE;");
    for (pqxx::result::const_iterator retreive_job = retreive_jobs.begin(); retreive_job != retreive_jobs.end(); ++retreive_job) {
        if(retreive_job[0].is_null()) continue;
        int job_id = retreive_job[0].as<int>();
        Job* job = new Job();
        job->LoadJob(job_id);
        if(folderExists(job->workspace_folder) + "/TRASH" && folderExists(job->workspace_folder + "/TRASH/" + job->job_folder_base)){
            moveFolder(job->workspace_folder + "/TRASH/" + job->job_folder_base, job->job_folder);
            sql_request("UPDATE jobs SET retrievable=FALSE,trashed=FALSE,deleted=FALSE,retrieve=FALSE WHERE id=" + std::to_string(job_id) + ";"); 
        }
        delete job;
    }


}





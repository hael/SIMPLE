#include "job_collector.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

JobCollector::JobCollector (bool local) {
    // logfile path
    this->logpath = getRootDir() + "/var/log/JobCollector.txt";
    // create logger if not already existing
    if(spdlog::get("JobCollector") == nullptr){
      auto logger = spdlog::rotating_logger_mt("JobCollector", this->logpath, 1048576 * 5, 5);
    }
    this->local = local;
    char host[256];
    if(gethostname(host, sizeof(host)) == -1){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get hostname");
        return;
    }
    struct hostent* host_entry = gethostbyname(host);
    if(host_entry == NULL){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get host entry");
        return;
    }
    this->ip = inet_ntoa(*((struct in_addr*) host_entry->h_addr_list[0]));
    // config
    nlohmann::ordered_json config = RetreiveConfig();
    if(json_test_int(config, "comm_port"))  this->port = config["comm_port"].get<int>();
    if(json_test_string(config, "comm_ip")) this->ip   = config["comm_ip"].get<std::string>();
    if(json_test_int(config, "thumbnail_workers")) this->n_thumbnail_workers = config["thumbnail_workers"].get<int>();
    this->comm_addr_str = this->ip + ":" + std::to_string(this->port);
    // start
    this->Start();
    // console log running
    spdlog::get("master")->info("JobCollector running. Logs will be written to " + this->logpath);
}

bool JobCollector::Status (bool quiet) {
    // current status
    bool thread_status = this->healthy;
    // reset status
    this->healthy = false;
    // log if not healthy and not quiet
    if(!thread_status && !quiet){
        spdlog::get("master")->error("JobCollector failed. More details may be found in " + this->logpath);
        spdlog::get("JobCollector")->error("JobCollector failed. More details may be found in " + this->logpath);
    }
    return thread_status;
}

void JobCollector::Stop () {
    // console log stop
    spdlog::get("master")->info("JobCollector stopping");
    // send signal
    this->terminate = true;
    // wait for status
    while(this->Status(true)){
        sleep(1);
    }
    // log stopped
    spdlog::get("master")->info("JobCollector stopped");
    spdlog::get("JobCollector")->info("JobCollector stopped");
}

void JobCollector::Start () {
    // console log start
    spdlog::get("master")->info("JobCollector starting");
    spdlog::get("JobCollector")->info("JobCollector starting");
    // start daemon thread
    this->terminate = false;
    this->workerthread = std::thread(&JobCollector::Listener, this);
    this->workerthread.detach();

    // popluate uids
    pqxx::result uids = sql_result("SELECT uid FROM thumbnails;");
    
    for(int i=0; i < uids.size(); i++){
      if(!uids[i][0].is_null()){
        this->uids.push_back(uids[i][0].as<std::string>());
        std::cout <<"ADDED " + uids[i][0].as<std::string>() + " to UIDS";
      }
    }

    for(int i = 1; i <= this->n_thumbnail_workers; i++){
      this->thread_id = i;
      this->thumbnailthreads[i] = std::thread(&JobCollector::Thumbnailer, this);
      this->thumbnailthreads[i].detach();
      sleep(0.5);
    }
}

void JobCollector::Listener () {
  struct mg_mgr mgr;  // Event manager
  struct mg_connection *c;
  mg_log_set(MG_LL_INFO);  // Set log level
  mg_mgr_init(&mgr);       // Initialize event manager
  if(this->local){
    for (int trial = 0; trial < 10; trial++){
      this->port = this->port + trial;
      struct hostent* host_entry = gethostbyname("localhost");
      if(host_entry == NULL){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get localhost entry");
        return;
      }
      this->comm_addr_str = inet_ntoa(*((struct in_addr*) host_entry->h_addr_list[0]));
      this->comm_addr_str += ':' + std::to_string(this->port);

      std::string addr_str = "tcp://" + this->comm_addr_str;
      c = mg_listen(&mgr, addr_str.c_str(), JobCollector::RequestHandler, this);  // Create server connection
      if(c == NULL){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - port in use. Trialling next");
      }else{
        spdlog::get("JobCollector")->info(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - listening on " + addr_str);
        break;
      }
    }
  }else{
    std::string addr_str = "tcp://" + this->comm_addr_str;
    c = mg_listen(&mgr, addr_str.c_str(), JobCollector::RequestHandler, this);  // Create server connection
  }
  if (c == NULL) {
    MG_INFO(("SERVER cant' open a connection"));
  }
  mg_wakeup_init(&mgr);
  while (true){
    this->healthy = true;
    mg_mgr_poll(&mgr, 100);  // Infinite event loop, blocks for upto 100ms
    if(this->terminate) break;
  }
  mg_mgr_free(&mgr);         // Free resources
}

void JobCollector::RequestHandler(struct mg_connection *c, int ev, void *ev_data) {
  if (ev == MG_EV_OPEN && c->is_listening == 0) {
    MG_INFO(("SERVER is listening"));
    struct thread_data* data = (struct thread_data*) calloc(1, sizeof(*data));
    data->conn_id = c->id;
    data->mgr     = c->mgr;
    data->useful_pointer = c->fn_data;
    c->fn_data    = data;
  } else if (ev == MG_EV_READ) {
    struct mg_iobuf* r = &c->recv;
    struct thread_data* data = (struct thread_data*) c->fn_data;
    JobCollector* self = (JobCollector*) data->useful_pointer;
    int json_str_size = data->json_str.size();
    data->json_str.resize(json_str_size + r->len);
    memcpy(&data->json_str[json_str_size], &r->buf[0], r->len);
    // if null terminated => end of message
    if(data->json_str.back() == '\0'){
      std::string processid_str = data->json_str.substr(0,10);
      std::string json_str      = data->json_str.substr(10);
      json_str.pop_back();
      data->processid_str       = processid_str;
      data->json_str            = json_str;
      JobCollector::RequestThread(JobCollector::RequestProcess, data);
    }
    r->len = 0;                  // Tell Mongoose we've consumed data
  } else if (ev == MG_EV_WAKEUP) {
    struct mg_str *data = (struct mg_str *) ev_data;
    mg_send(c, "#N1C3", 5);
    mg_send(c, &data->len, sizeof(data->len));
    mg_send(c, data->buf, data->len);
  } else if (ev == MG_EV_CLOSE) {
    MG_INFO(("SERVER disconnected"));
  } else if (ev == MG_EV_ERROR) {
    MG_INFO(("SERVER error: %s", (char *) ev_data));
  }
  (void) ev_data;
}

void JobCollector::RequestThread(void *(*f)(void *), void *p) {
  pthread_t thread_id = (pthread_t) 0;
  pthread_attr_t attr;
  (void) pthread_attr_init(&attr);
  (void) pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  pthread_create(&thread_id, &attr, f, p);
  pthread_attr_destroy(&attr);
}

void* JobCollector::RequestProcess(void* p) {
  struct thread_data* data = (struct thread_data*) p;
  int process_id = std::stoi(data->processid_str);
  JobCollector* self = (JobCollector*) data->useful_pointer;
  Process* process = new Process(process_id);

  if(nlohmann::ordered_json::accept(data->json_str)){
    nlohmann::ordered_json jobstat_json = nlohmann::ordered_json::parse(data->json_str);
    process->UpdateStats(jobstat_json, &self->q, &self->uids);
  }else{
    process->UpdateHeartbeat();
  }

  nlohmann::ordered_json returnjson = process->GetUpdates();
  std::string returnjson_str = returnjson.dump(0);
  mg_wakeup(data->mgr, data->conn_id, returnjson_str.c_str(), returnjson_str.size()); // see mongoose docs to change hi to malloc array
  delete process;
  free(data);
  return NULL;
}

void JobCollector::Thumbnailer () {
  int thread_id = this->thread_id;
  std::string threadname = "thumbnailer (" + std::to_string(thread_id) + ")";
  while (true){
    bool dosleep = false;
    nlohmann::ordered_json thumbjson = this->q.pop();
    if(thumbjson.is_null()){
      dosleep = true;
    }else{
      if(thumbjson.contains("process_id") && json_test_int(thumbjson, "process_id")){
        auto start = std::chrono::high_resolution_clock::now();
        int process_id = thumbjson["process_id"].get<int>();
        Process* process = new Process(process_id);
        if(thumbjson.contains("boxfile") && json_test_string(thumbjson, "boxfile")){
          process->SetThumbnail(thumbjson, thumbjson["boxfile"].get<std::string>());
        }else{
          process->SetThumbnail(thumbjson);
        }
        delete process;
        auto stop = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
        std::cout << threadname << " imported thumbnail in : " << duration.count() << " microseconds" << std::endl;
      }
    }
    if(dosleep){
      usleep(100000);
    }
    if(this->terminate) break;
  }
}
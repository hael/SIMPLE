#include "simple_stream.hpp"

SIMPLE_Stream::SIMPLE_Stream(Core* core, std::string rootfolder, int id){
	this->core = core;
	this->core->logInfo("initialising SIMPLE_Stream");
	this->rootfolder = rootfolder;
	this->id = id;
	this->core->logInfo("SIMPLE_Stream initialisation complete");
}

void SIMPLE_Stream::TabData(nlohmann::ordered_json* returnjson){

	this->core->getStats(this->id, &this->stats);

	if(fileExists(this->rootfolder + "/.control.json")){
		std::ifstream controlfile(this->rootfolder + "/.control.json");
		this->control = nlohmann::ordered_json::parse(controlfile);
		controlfile.close();
	}

	nlohmann::ordered_json tabdata = {};

	tabdata.push_back(this->DataTab());
	tabdata.push_back(this->PreprocTab());
	tabdata.push_back(this->OpticsTab());
	tabdata.push_back(this->PickTrainTab());
	tabdata.push_back(this->PickTab());
	tabdata.push_back(this->Stream2DTab());
	tabdata.push_back(this->Stream3DTab());

	returnjson->emplace("tabdata", "");
	returnjson->at("tabdata") = tabdata;

	returnjson->emplace("jobfolder", "");
	returnjson->at("jobfolder") = this->rootfolder;
}

nlohmann::ordered_json SIMPLE_Stream::DataTab(){

	nlohmann::ordered_json tabstats;

	if(this->stats.contains("data")){
		tabstats = this->stats["data"];
	}

	nlohmann::ordered_json tabdata = {};

	tabdata["title"] = "data";

	tabdata["options"] = {};

	// input source options
	nlohmann::ordered_json inputoption;
	inputoption["key"]   = "niceinputtype";
	inputoption["title"] = "data source";
	inputoption["type"]  = "binary";
	inputoption["binaryoptions"] = {};
	nlohmann::ordered_json binaryoption1;
	binaryoption1.push_back("McSync");
	binaryoption1.push_back("McSync");
	inputoption["binaryoptions"].push_back(binaryoption1);
	nlohmann::ordered_json binaryoption2;
	binaryoption2.push_back("folder");
	binaryoption2.push_back("folder");
	inputoption["binaryoptions"].push_back(binaryoption2);
	inputoption["global"] = true; 
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("niceinputtype")){
		inputoption["static"] = this->control["init"]["arguments"]["niceinputtype"].get<std::string>();
	}
	tabdata["options"].push_back(inputoption);

	// folders options
	nlohmann::ordered_json movoption;
	movoption["key"]   = "dir_movies";
	movoption["title"] = "movies directory";
	movoption["type"]  = "dir";
	movoption["globaloption"] = "folder";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("dir_movies")){
		movoption["static"] = this->control["init"]["arguments"]["dir_movies"].get<std::string>();
	}
	tabdata["options"].push_back(movoption);

	nlohmann::ordered_json gainoption;
	gainoption["key"]   = "gainref";
	gainoption["title"] = "gain reference";
	gainoption["type"]  = "dir";
	gainoption["globaloption"] = "folder";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("gainref")){
		gainoption["static"] = this->control["init"]["arguments"]["gainref"].get<std::string>();
	}
	tabdata["options"].push_back(gainoption);

	nlohmann::ordered_json metaoption;
	metaoption["key"]   = "dir_meta";
	metaoption["title"] = "metadata directory";
	metaoption["type"]  = "dir";
	metaoption["globaloption"] = "folder";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("dir_meta")){
		metaoption["static"] = this->control["init"]["arguments"]["dir_meta"].get<std::string>();
	}
	tabdata["options"].push_back(metaoption);

	// mcsync options

	// global options
	nlohmann::ordered_json kvoption;
	kvoption["key"]   = "kv";
	kvoption["title"] = "microscope voltage(kv)";
	kvoption["type"]  = "num";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("kv")){
		kvoption["static"] = this->control["init"]["arguments"]["kv"].get<std::string>();
	}
	tabdata["options"].push_back(kvoption);

	nlohmann::ordered_json csoption;
	csoption["key"]   = "cs";
	csoption["title"] = "spherical aberration(mm)";
	csoption["type"]  = "num";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("cs")){
		csoption["static"] = this->control["init"]["arguments"]["cs"].get<std::string>();
	}
	tabdata["options"].push_back(csoption);

	nlohmann::ordered_json doseoption;
	doseoption["key"]   = "total_dose";
	doseoption["title"] = "total dose(é/Å²)";
	doseoption["type"]  = "num";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("total_dose")){
		doseoption["static"] = this->control["init"]["arguments"]["total_dose"].get<std::string>();
	}
	tabdata["options"].push_back(doseoption);

	nlohmann::ordered_json smpdoption;
	smpdoption["key"]   = "smpd";
	smpdoption["title"] = "pixel size(Å)";
	smpdoption["type"]  = "num";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("smpd")){
		smpdoption["static"] = this->control["init"]["arguments"]["smpd"].get<std::string>();
	}
	tabdata["options"].push_back(smpdoption);

	nlohmann::ordered_json binoption;
	binoption["key"]   = "scale";
	binoption["title"] = "bin data (x2)";
	binoption["type"]  = "binary";
	binoption["binaryoptions"] = {};
	nlohmann::ordered_json binoption1;
	binoption1.push_back("");
	binoption1.push_back("1");
	binoption["binaryoptions"].push_back(binoption1);
	nlohmann::ordered_json binoption2;
	binoption2.push_back("");
	binoption2.push_back("0.5");
	binoption["binaryoptions"].push_back(binoption2);
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("scale")){
		binoption["static"] = this->control["init"]["arguments"]["scale"].get<std::string>();
	}
	tabdata["options"].push_back(binoption);

	// particle diameter
	nlohmann::ordered_json moldiamoption;
	moldiamoption["key"]   = "moldiam";
	moldiamoption["title"] = "estimated particle diameter(Å)";
	moldiamoption["type"]  = "num";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("moldiam")){
		moldiamoption["static"] = this->control["init"]["arguments"]["moldiam"].get<std::string>();
	}
	tabdata["options"].push_back(moldiamoption);

	// pre existing pickrefs options
	nlohmann::ordered_json pickrefsoption;
	pickrefsoption["key"]   = "pickrefs";
	pickrefsoption["title"] = "pre-existing 2D picking references";
	pickrefsoption["type"]  = "dir";
	if( this->control.contains("init") 
	 && this->control["init"].contains("arguments")
	 && this->control["init"]["arguments"].is_object()
	 && this->control["init"]["arguments"].contains("pickrefs")){
		pickrefsoption["static"] = this->control["init"]["arguments"]["pickrefs"].get<std::string>();
	}
	tabdata["options"].push_back(pickrefsoption);

	tabdata["start"] = true;

	if(tabstats.contains("status")){
		tabdata["status"] = tabstats["status"];
		if(tabdata["status"].get<std::string>() == "running"){
			tabdata["start"] = false;
		}
	}else{
		tabdata["status"] = "queued";
	}

	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::PreprocTab(){

	nlohmann::ordered_json tabstats;

	if(this->stats.contains("preproc")){
		tabstats = this->stats["preproc"];
	}

	nlohmann::ordered_json tabdata = {};

	tabdata["title"] = "preprocessing";

	tabdata["start"] = false;

	if(tabstats.contains("status")){
		tabdata["status"] = tabstats["status"];
	}else{
		tabdata["status"] = "other";
	}

	if(tabstats.contains("log")){
		tabdata["log"] = tabstats["log"];
	}

	if(tabstats.contains("error")){
		tabdata["error"] = tabstats["error"];
	}

	if(tabstats.contains("micsstar")){
		tabdata["micsstar"] = tabstats["micsstar"];
	}

	if(this->stats.contains("sections") && this->stats["sections"].contains("micrographs")){
		tabdata["stats"] = this->stats["sections"]["micrographs"];
	}
	
	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::OpticsTab(){

	nlohmann::ordered_json tabstats;

	if(this->stats.contains("optics")){
		tabstats = this->stats["optics"];
	}

	nlohmann::ordered_json tabdata = {};

	tabdata["title"] = "optics grouping";

	tabdata["start"] = false;

	if(tabstats.contains("status")){
		tabdata["status"] = tabstats["status"];
	}else{
		tabdata["status"] = "other";
	}

	if(tabstats.contains("log")){
		tabdata["log"] = tabstats["log"];
	}

	if(tabstats.contains("error")){
		tabdata["error"] = tabstats["error"];
	}

	if(tabstats.contains("opticsstar")){
		tabdata["opticsstar"] = tabstats["opticsstar"];
	}

	if(this->stats.contains("sections") && this->stats["sections"].contains("optics")){
		tabdata["stats"] = this->stats["sections"]["optics"];
	}

	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::PickTrainTab(){
	nlohmann::ordered_json tabdata = {};
	tabdata["title"] = "pick training";
	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::PickTab(){

	nlohmann::ordered_json tabstats;

	if(this->stats.contains("refpick")){
		tabstats = this->stats["refpick"];
	}

	nlohmann::ordered_json tabdata = {};

	tabdata["title"] = "picking";

	tabdata["start"] = false;

	if(tabstats.contains("status")){
		tabdata["status"] = tabstats["status"];
	}else{
		tabdata["status"] = "other";
	}

	if(tabstats.contains("log")){
		tabdata["log"] = tabstats["log"];
	}

	if(tabstats.contains("error")){
		tabdata["error"] = tabstats["error"];
	}

	if(tabstats.contains("micsstar")){
		tabdata["micsstar"] = tabstats["micsstar"];
	}

	if(this->stats.contains("sections") && this->stats["sections"].contains("picking")){
		tabdata["stats"] = this->stats["sections"]["picking"];
	}

	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::Stream2DTab(){
	nlohmann::ordered_json tabdata = {};
	tabdata["title"] = "2D stream";
	return tabdata;
}

nlohmann::ordered_json SIMPLE_Stream::Stream3DTab(){
	nlohmann::ordered_json tabdata = {};
	tabdata["title"] = "3D stream";
	return tabdata;
}

void SIMPLE_Stream::OpticsData(nlohmann::ordered_json* returnjson, std::string filename){

	if(!fileExists(filename)) return;

	returnjson->emplace("opticsgroups", nlohmann::ordered_json::array());

	nlohmann::ordered_json opticsstar = readSTAR(filename);

	for(auto plotgroup : opticsstar.items()){
		std::string groupname = plotgroup.key();
		if(groupname.find("data_opticsgroup_") != std::string::npos){
			nlohmann::ordered_json groupdata = plotgroup.value();
			if(groupdata.contains("loop") && groupdata["loop"].is_array() && groupdata["loop"].size() > 0){
				if(groupdata["loop"][0].contains("_splBeamshiftX") &&
				   groupdata["loop"][0].contains("_splBeamshiftY") &&
				   groupdata["loop"][0].contains("_rlnOpticsGroup")){
				   	nlohmann::ordered_json groupjson = {};
					groupjson["groupid"] = std::stoi(groupdata["loop"][0]["_rlnOpticsGroup"].get<std::string>());
					groupjson["points"] = {};
					for(auto groupline : groupdata["loop"]){
						nlohmann::ordered_json xyjson = {};
						float shiftx = std::stof(groupline["_splBeamshiftX"].get<std::string>());
						float shifty = std::stof(groupline["_splBeamshiftY"].get<std::string>());
						xyjson["x"] = shiftx;
						xyjson["y"] = shifty;
						groupjson["points"] += xyjson;
					}
					returnjson->at("opticsgroups").push_back(groupjson);
				}
			}
		}
	}
}


bool SIMPLE_Stream::StreamInit(nlohmann::ordered_json arguments){

	if(!this->core->SIMPLE_enabled){
		return false;
	}

	if(!this->core->SIMPLE_workspaceInit(this->rootfolder)){
		return false;
	}

	// create initial control file -> only updated by dispatch after this
	this->control["init"]["arguments"] = arguments;
	std::ofstream controlfile(this->rootfolder + "/.control.json");
    controlfile << this->control;
    controlfile.close();
   
	return true;
}

bool SIMPLE_Stream::StreamInitPreproc(nlohmann::ordered_json arguments, bool restart){

	if(!this->core->SIMPLE_enabled){
		return false;
	}

	nlohmann::ordered_json job;

	job["exec"] = "simple_stream";
	job["prg"]  = "preproc";

	job["arguments"] = {};

	if(arguments.contains("dir_movies") && arguments["dir_movies"].is_string()){
		job["arguments"]["dir_movies"] = arguments["dir_movies"].get<std::string>();
	}else{
		return false;
	}

	if(arguments.contains("dir_meta") && arguments["dir_meta"].is_string()){
		job["arguments"]["dir_meta"] = arguments["dir_meta"].get<std::string>();
	}else{
		return false;
	}

	if(arguments.contains("cs") && arguments["cs"].is_string()){
		job["arguments"]["cs"] = arguments["cs"].get<std::string>();
	}else{
		return false;
	}

	if(arguments.contains("kv") && arguments["kv"].is_string()){
		job["arguments"]["kv"] = arguments["kv"].get<std::string>();
	}else{
		return false;
	}

	if(arguments.contains("smpd") && arguments["smpd"].is_string()){
		job["arguments"]["smpd"] = arguments["smpd"].get<std::string>();
	}else{
		return false;
	}

	// hard coded
	job["arguments"]["fraca"]  = "0.1";
	job["arguments"]["nparts"] = "10";
	job["arguments"]["nthr"]   = "4";

	if(restart){
		job["arguments"]["dir_exec"] = "preprocessing";
		if(fileExists(this->rootfolder + "/nice_preproc.exit")) removeFile(this->rootfolder + "/nice_preproc.exit");
		if(fileExists(this->rootfolder + "/nice_preproc.pid"))  removeFile(this->rootfolder + "/nice_preproc.pid");
		if(fileExists(this->rootfolder + "/preprocessing/SIMPLE_TERM_STREAM")) removeFile(this->rootfolder + "/preprocessing/SIMPLE_TERM_STREAM");
	}else{
		job["arguments"]["outdir"] = "preprocessing";
	}

	std::ofstream jobfile(this->rootfolder + "/.preproc.json");
    jobfile << job;
    jobfile.close();

	return true;
}

bool SIMPLE_Stream::StreamInitRefPick(nlohmann::ordered_json arguments, bool restart){

	if(!this->core->SIMPLE_enabled){
		return false;
	}

	nlohmann::ordered_json job;

	job["exec"] = "simple_stream";
	job["prg"]  = "pick_extract";

	job["arguments"] = {};

	if(arguments.contains("pickrefs")){
		if(arguments["pickrefs"].is_string()){
			job["arguments"]["pickrefs"] = arguments["pickrefs"].get<std::string>();
		}else{
			return false;
		}
	}else{
		return true; // not ready for refpick yet!
	}

	if(arguments.contains("moldiam") && arguments["moldiam"].is_string()){
		job["arguments"]["moldiam"] = arguments["moldiam"].get<std::string>();
	}else{
		return false;
	}

	// hard coded
	job["arguments"]["nparts"] = "10";
	job["arguments"]["nthr"]   = "4";
	job["arguments"]["dir_target"] = "preprocessing";
	
	if(restart){
		job["arguments"]["dir_exec"] = "reference_pick_extract";
		if(fileExists(this->rootfolder + "/nice_refpick.exit")) removeFile(this->rootfolder + "/nice_refpick.exit");
		if(fileExists(this->rootfolder + "/nice_refpick.pid"))  removeFile(this->rootfolder + "/nice_refpick.pid");
		if(fileExists(this->rootfolder + "/reference_pick_extract/SIMPLE_TERM_STREAM")) removeFile(this->rootfolder + "/reference_pick_extract/SIMPLE_TERM_STREAM");
	}else{
		job["arguments"]["outdir"] = "reference_pick_extract";
	}

	std::ofstream jobfile(this->rootfolder + "/.refpick.json");
    jobfile << job;
    jobfile.close();

	return true;
}

bool SIMPLE_Stream::StreamInitAssignOptics(nlohmann::ordered_json arguments, bool restart){

	if(!this->core->SIMPLE_enabled){
		return false;
	}

	nlohmann::ordered_json job;

	job["exec"] = "simple_stream";
	job["prg"]  = "assign_optics";

	job["arguments"] = {};

	// hard coded
	job["arguments"]["dir_target"] = "preprocessing";
	
	if(restart){
		job["arguments"]["dir_exec"] = "assign_optics";
		if(fileExists(this->rootfolder + "/nice_optics.exit")) removeFile(this->rootfolder + "/nice_optics.exit");
		if(fileExists(this->rootfolder + "/nice_optics.pid"))  removeFile(this->rootfolder + "/nice_optics.pid");
		if(fileExists(this->rootfolder + "/assign_optics/SIMPLE_TERM_STREAM")) removeFile(this->rootfolder + "/assign_optics/SIMPLE_TERM_STREAM");
	}else{
		job["arguments"]["outdir"] = "assign_optics";
	}

	std::ofstream jobfile(this->rootfolder + "/.optics.json");
    jobfile << job;
    jobfile.close();

	return true;
}

void SIMPLE_Stream::StreamControl(std::string func, nlohmann::ordered_json arguments, nlohmann::ordered_json* returnjson){

	if(func == "start"){

		if(!this->StreamInit(arguments)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise stream");
			return;
		}

		if(!this->StreamInitPreproc(arguments)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise preproc");
			return;
		}

		if(!this->StreamInitRefPick(arguments)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise refpick");
			return;
		}

		if(!this->StreamInitAssignOptics(arguments)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise optics assignment");
			return;
		}

	}else if(func == "restartpreproc"){
		if(!this->StreamInitPreproc(arguments, true)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise preproc");
			return;
		}
	}else if(func == "restartrefpick"){
		if(!this->StreamInitRefPick(arguments, true)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise preproc");
			return;
		}
	}else if(func == "restartoptics"){
		if(!this->StreamInitAssignOptics(arguments, true)){
			returnjson->emplace("success", false);
			returnjson->emplace("error", "failed to initialise optics assignment");
			return;
		}	
	}else if(func == "stoppreproc"){
		if(!fileExists(this->rootfolder +"/preprocessing/SIMPLE_TERM_STREAM")){
			std::ofstream termfile(this->rootfolder +"/preprocessing/SIMPLE_TERM_STREAM");
    		termfile.close();
		}
	}else if(func == "stoprefpick"){
		if(!fileExists(this->rootfolder +"/reference_pick_extract/SIMPLE_TERM_STREAM")){
			std::ofstream termfile(this->rootfolder +"/reference_pick_extract/SIMPLE_TERM_STREAM");
    		termfile.close();
		}
	}else if(func == "stopoptics"){
		if(!fileExists(this->rootfolder +"/assign_optics/SIMPLE_TERM_STREAM")){
			std::ofstream termfile(this->rootfolder +"/assign_optics/SIMPLE_TERM_STREAM");
    		termfile.close();
		}
	}

	returnjson->emplace("success", true);
	returnjson->emplace("info", "stream control initiated");

}

bool SIMPLE_Stream::TestStatus(std::string prg){

	if(this->control.empty() && fileExists(this->rootfolder + "/.control.json")){
		std::ifstream controlfile(this->rootfolder + "/.control.json");
		this->control = nlohmann::ordered_json::parse(controlfile);
		controlfile.close();
	}
	
	if(fileExists(this->rootfolder + "/nice_" + prg + ".exit")) return false;

	if(fileExists(this->rootfolder + "/nice_" + prg + ".pid")){
		std::string buffer;
		std::ifstream pidfile(this->rootfolder + "/nice_" + prg + ".pid");
		getline (pidfile, buffer);
		pidfile.close();
						
		if(buffer == "") return false;

		int pid = std::stoi(buffer);
		std::time_t starttime = time(0);

		// Query status handler
		if(this->control.contains(prg) && this->control[prg].contains("statuscommand")){

			std::string statuscommand = this->control[prg]["statuscommand"];
			
			this->core->statusAddCommand(statuscommand); // confirm command is in array after restart
			
			if(this->core->statusTest(statuscommand, pid, starttime)){
				return true;
			}else{
				if(!fileExists(this->rootfolder + "/nice_" + prg + ".exit")){
					std::ofstream exitfilehandle(this->rootfolder + "/nice_" + prg + ".exit");
					exitfilehandle << 1 << std::endl;
					exitfilehandle.close();
				}
				return false;
			}
		}
	}

	return false;
}

bool SIMPLE_Stream::GetStats(nlohmann::ordered_json* statsjson){

	std::string preprocdir = this->rootfolder + "/preprocessing";
	std::string refpickdir = this->rootfolder + "/reference_pick_extract";
	std::string opticsdir  = this->rootfolder + "/assign_optics";

	nlohmann::ordered_json guistats;

	if(fileExists(this->rootfolder + "/.guistats.json")){
		std::ifstream statsfile(this->rootfolder + "/.guistats.json");
		guistats = nlohmann::ordered_json::parse(statsfile);
		statsfile.close();
	}

	// data status
	if(!statsjson->contains("data")){
		statsjson->emplace("data", nlohmann::ordered_json::object());
	}

	if(!statsjson->at("data").contains("status")){
		statsjson->at("data").emplace("status", "queued");
	}

	if(fileExists(this->rootfolder + "/workspace.simple")){
		statsjson->at("data")["status"] = "running";
	}

	// preproc status
	if(!statsjson->contains("preproc")){
		statsjson->emplace("preproc", nlohmann::ordered_json::object());
	}

	if(fileExists(this->rootfolder + "/nice_preproc.exit")){
		std::string buffer;

		std::ifstream exitfile(this->rootfolder + "/nice_preproc.exit");
		getline (exitfile, buffer);
		exitfile.close();
				
		int exitcode = std::stoi(buffer);

		if(exitcode == 0){
			statsjson->at("preproc")["status"] = "stopped";
		}else{
			statsjson->at("preproc")["status"] = "error";
		}
		
	}else if(fileExists(this->rootfolder + "/.preproc.json")){
		statsjson->at("preproc")["status"] = "queued";
	}else if(folderExists(preprocdir)){
		if(this->TestStatus("preproc")){
			statsjson->at("preproc")["status"] = "running";
		}else{
			statsjson->at("preproc")["status"] = "error";
		}
	}

	if(fileExists(preprocdir + "/.guistats.json")){
		std::ifstream statsfile(this->rootfolder + "/preprocessing/.guistats.json");
		nlohmann::ordered_json preprocstats = nlohmann::ordered_json::parse(statsfile);
		statsfile.close();

		if(!statsjson->contains("sections")) statsjson->emplace("sections", nlohmann::ordered_json::object());
		statsjson->at("sections")["micrographs"] = preprocstats["micrographs"];
	}

	if(fileExists(this->rootfolder + "/nice_preproc.log")){
		statsjson->at("preproc")["log"] = this->rootfolder + "/nice_preproc.log";
	}

	if(fileExists(this->rootfolder + "/nice_preproc.error")){
		statsjson->at("preproc")["error"] = this->rootfolder + "/nice_preproc.error";
	}

	if(fileExists(preprocdir + "/micrographs.star")){
		statsjson->at("preproc")["micsstar"] = preprocdir + "/micrographs.star";
	}

	// refpick status
	if(!statsjson->contains("refpick")){
		statsjson->emplace("refpick", nlohmann::ordered_json::object());
	}

	if(fileExists(this->rootfolder + "/nice_refpick.exit")){
		std::string buffer;

		std::ifstream exitfile(this->rootfolder + "/nice_refpick.exit");
		getline (exitfile, buffer);
		exitfile.close();
				
		int exitcode = std::stoi(buffer);

		if(exitcode == 0){
			statsjson->at("refpick")["status"] = "stopped";
		}else{
			statsjson->at("refpick")["status"] = "error";
		}
		
	}else if(fileExists(this->rootfolder + "/.refpick.json")){
		statsjson->at("refpick")["status"] = "queued";
	}else if(folderExists(refpickdir)){
		if(this->TestStatus("refpick")){
			statsjson->at("refpick")["status"] = "running";
		}else{
			statsjson->at("refpick")["status"] = "error";
		}
	}

	if(fileExists(refpickdir + "/.guistats.json")){
		std::ifstream statsfile(refpickdir + "/.guistats.json");
		nlohmann::ordered_json refpickstats = nlohmann::ordered_json::parse(statsfile);
		statsfile.close();

		if(!statsjson->contains("sections")) statsjson->emplace("sections", nlohmann::ordered_json::object());
		statsjson->at("sections")["picking"] = refpickstats["micrographs"];
	}

	if(fileExists(this->rootfolder + "/nice_refpick.log")){
		statsjson->at("refpick")["log"] = this->rootfolder + "/nice_refpick.log";
	}

	if(fileExists(this->rootfolder + "/nice_refpick.error")){
		statsjson->at("refpick")["error"] = this->rootfolder + "/nice_refpick.error";
	}

	if(fileExists(refpickdir + "/micrographs.star")){
		statsjson->at("refpick")["micsstar"] = refpickdir + "/micrographs.star";
	}

	// optics status
	if(!statsjson->contains("optics")){
		statsjson->emplace("optics", nlohmann::ordered_json::object());
	}

	if(fileExists(this->rootfolder + "/nice_optics.exit")){
		std::string buffer;

		std::ifstream exitfile(this->rootfolder + "/nice_optics.exit");
		getline (exitfile, buffer);
		exitfile.close();
				
		int exitcode = std::stoi(buffer);

		if(exitcode == 0){
			statsjson->at("optics")["status"] = "stopped";
		}else{
			statsjson->at("optics")["status"] = "error";
		}
		
	}else if(fileExists(this->rootfolder + "/.optics.json")){
		statsjson->at("optics")["status"] = "queued";
	}else if(folderExists(opticsdir)){
		if(this->TestStatus("optics")){
			statsjson->at("optics")["status"] = "running";
		}else{
			statsjson->at("optics")["status"] = "error";
		}
	}

	if(fileExists(opticsdir + "/.guistats.json")){
		std::ifstream statsfile(opticsdir + "/.guistats.json");
		nlohmann::ordered_json opticsstats = nlohmann::ordered_json::parse(statsfile);
		statsfile.close();

		if(!statsjson->contains("sections")) statsjson->emplace("sections", nlohmann::ordered_json::object());
		statsjson->at("sections")["optics"] = opticsstats["optics"];
	}

	if(fileExists(this->rootfolder + "/nice_optics.log")){
		statsjson->at("optics")["log"] = this->rootfolder + "/nice_optics.log";
	}

	if(fileExists(this->rootfolder + "/nice_optics.error")){
		statsjson->at("optics")["error"] = this->rootfolder + "/nice_optics.error";
	}

	if(fileExists(opticsdir + "/optics.star")){
		statsjson->at("optics")["opticsstar"] = opticsdir + "/optics.star";
	}
	std::cout << " " <<statsjson->dump(2)<<std::endl;
	
	return true;
}

bool SIMPLE_Stream::Dispatch(){

	if(folderExists(this->rootfolder)){

		bool preprocupdate = false;
		bool refpickupdate = false;
		bool opticsupdate = false;

		if(fileExists(this->rootfolder + "/.preproc.json")) preprocupdate = true;
		if(fileExists(this->rootfolder + "/.refpick.json")) refpickupdate = true;
		if(fileExists(this->rootfolder + "/.optics.json" )) opticsupdate  = true;

		if(!preprocupdate && !refpickupdate && !opticsupdate) return true;

		if(fileExists(this->rootfolder + "/.control.json")){
			std::ifstream controlfile(this->rootfolder + "/.control.json");
			this->control = nlohmann::ordered_json::parse(controlfile);
			controlfile.close();
		}
		
		nlohmann::ordered_json clusterlist;
		
		this->core->SIMPLE_getClusters(&clusterlist);

		if(!clusterlist.contains("clusters")){
			this->core->logError("SIMPLE_Stream::Dispatch: clusters missing from clusterlist");
			return false;
		}

		if(!clusterlist["clusters"].is_array()){
			this->core->logError("SIMPLE_Stream::Dispatch: clusters is not an array");
			return false;
		}

		if(!clusterlist["clusters"][0].contains("template")){
			this->core->logError("SIMPLE_Stream::Dispatch: template missing from cluster");
			return false;
		}

		if(!clusterlist["clusters"][0]["template"].is_string()){
			this->core->logError("SIMPLE_Stream::Dispatch: template is not a string");
			return false;
		}

		std::string clustertemplate = clusterlist["clusters"][0]["template"].get<std::string>();

		if(preprocupdate){
			std::ifstream argsfile(this->rootfolder + "/.preproc.json");
			nlohmann::ordered_json jobargs = nlohmann::ordered_json::parse(argsfile);
			argsfile.close();

			if(!jobargs.contains("arguments")) return false;
			if(!jobargs.contains("prg"))       return false;

			if(this->TestStatus("preproc")) return false;

			if(!this->FillTemplate(clustertemplate, "preproc", jobargs["prg"].get<std::string>(), jobargs["arguments"])){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to init SIMPLE preproc job");
				return false;
			}
			if(!removeFile(this->rootfolder + "/.preproc.json")){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to remove SIMPLE preproc json");
				return false;
			}
			if(!this->control.contains("preproc")) this->control["preproc"] = {};
			this->control["preproc"]["arguments"] = jobargs["arguments"];
		}else if(refpickupdate){
			std::ifstream argsfile(this->rootfolder + "/.refpick.json");
			nlohmann::ordered_json jobargs = nlohmann::ordered_json::parse(argsfile);
			argsfile.close();

			if(!jobargs.contains("arguments")) return false;
			if(!jobargs.contains("prg"))       return false;

			if(this->TestStatus("refpick")) return false;

			if(!this->FillTemplate(clustertemplate, "refpick", jobargs["prg"].get<std::string>(), jobargs["arguments"])){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to init SIMPLE refpick job");
				return false;
			}
			if(!removeFile(this->rootfolder + "/.refpick.json")){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to remove SIMPLE refpick json");
				return false;
			}
			if(!this->control.contains("refpick")) this->control["refpick"] = {};
			this->control["refpick"]["arguments"] = jobargs["arguments"];
		}else if(opticsupdate){
			std::ifstream argsfile(this->rootfolder + "/.optics.json");
			nlohmann::ordered_json jobargs = nlohmann::ordered_json::parse(argsfile);
			argsfile.close();

			if(!jobargs.contains("arguments")) return false;
			if(!jobargs.contains("prg"))       return false;

			if(this->TestStatus("optics")) return false;

			if(!this->FillTemplate(clustertemplate, "optics", jobargs["prg"].get<std::string>(), jobargs["arguments"])){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to init SIMPLE assign optics job");
				return false;
			}
			if(!removeFile(this->rootfolder + "/.optics.json")){
				this->core->logError("SIMPLE_Stream::Dispatch: failed to remove SIMPLE optics json");
				return false;
			}
			if(!this->control.contains("optics")) this->control["optics"] = {};
			this->control["optics"]["arguments"] = jobargs["arguments"];
		}

		if(!clusterlist["clusters"][0].contains("submitcommand")){
			this->core->logError("SIMPLE_Stream::Dispatch: submitcommand missing from cluster");
			return false;
		}

		if(!clusterlist["clusters"][0]["submitcommand"].is_string()){
			this->core->logError("SIMPLE_Stream::Dispatch: submitcommand is not a string");
			return false;
		}

		std::string submitcommand = clusterlist["clusters"][0]["submitcommand"].get<std::string>();

		if(!clusterlist["clusters"][0].contains("statuscommand")){
			this->core->logError("SIMPLE_Stream::Dispatch: statuscommand missing from cluster");
			return false;
		}

		if(!clusterlist["clusters"][0]["statuscommand"].is_string()){
			this->core->logError("SIMPLE_Stream::Dispatch: statuscommand is not a string");
			return false;
		}

		std::string statuscommand = clusterlist["clusters"][0]["statuscommand"].get<std::string>();

		if(!clusterlist["clusters"][0].contains("cancelcommand")){
			this->core->logError("SIMPLE_Stream::Dispatch: cancelcommand missing from cluster");
			return false;
		}

		if(!clusterlist["clusters"][0]["cancelcommand"].is_string()){
			this->core->logError("SIMPLE_Stream::Dispatch: cancelcommand is not a string");
			return false;
		}

		std::string cancelcommand = clusterlist["clusters"][0]["cancelcommand"].get<std::string>();

		if(preprocupdate){
			if(!this->control.contains("preproc")) this->control["preproc"] = {};
			this->control["preproc"]["statuscommand"] = statuscommand;
			this->control["preproc"]["cancelcommand"] = cancelcommand;
		}

		if(refpickupdate){
			if(!this->control.contains("refpick")) this->control["refpick"] = {};
			this->control["refpick"]["statuscommand"] = statuscommand;
			this->control["refpick"]["cancelcommand"] = cancelcommand;
		}

		if(opticsupdate){
			if(!this->control.contains("optics")) this->control["optics"] = {};
			this->control["optics"]["statuscommand"] = statuscommand;
			this->control["optics"]["cancelcommand"] = cancelcommand;
		}

		if(preprocupdate || refpickupdate || opticsupdate){
			std::ofstream controlfile(this->rootfolder + "/.control.json");
    		controlfile << this->control;
    		controlfile.close();
    	}

    	if(preprocupdate){
    		if(fileExists(this->rootfolder + "/nice_preproc.pid"))  removeFile(this->rootfolder + "/nice_preproc.pid");
    		if(fileExists(this->rootfolder + "/nice_preproc.exit")) removeFile(this->rootfolder + "/nice_preproc.exit");

    		std::string systemcmd = submitcommand + " ./nice_preproc.script &";
			pid_t c_pid = fork(); 
		
			if (c_pid == -1) { 
	        	this->core->logError("SIMPLE_Stream::Dispatch: submitcommand is not a string");
				return false;
	    	} else if (c_pid > 0) { 
	       		this->core->logInfo("SIMPLE_Stream::Dispatch: submitting job " + this->rootfolder + " " + std::to_string(this->id));
	  			this->core->logInfo("SIMPLE_Stream::Dispatch: submitted job " + std::to_string(this->id));
	    	} else { 
				chdir(this->rootfolder.c_str());
				int a = std::system(systemcmd.c_str());
		       	exit(0);
	    	}
    	}else if(refpickupdate){
    		if(fileExists(this->rootfolder + "/nice_refpick.pid"))  removeFile(this->rootfolder + "/nice_refpick.pid");
    		if(fileExists(this->rootfolder + "/nice_refpick.exit")) removeFile(this->rootfolder + "/nice_refpick.exit");

    		std::string systemcmd = submitcommand + " ./nice_refpick.script &";
			pid_t c_pid = fork(); 
		
			if (c_pid == -1) { 
	        	this->core->logError("SIMPLE_Stream::Dispatch: submitcommand is not a string");
				return false;
	    	} else if (c_pid > 0) { 
	       		this->core->logInfo("SIMPLE_Stream::Dispatch: submitting job " + this->rootfolder + " " + std::to_string(this->id));
	  			this->core->logInfo("SIMPLE_Stream::Dispatch: submitted job " + std::to_string(this->id));
	    	} else { 
				chdir(this->rootfolder.c_str());
				int a = std::system(systemcmd.c_str());
		       	exit(0);
	    	}
    	}else if(opticsupdate){
    		if(fileExists(this->rootfolder + "/nice_optics.pid"))  removeFile(this->rootfolder + "/nice_optics.pid");
    		if(fileExists(this->rootfolder + "/nice_optics.exit")) removeFile(this->rootfolder + "/nice_optics.exit");

    		std::string systemcmd = submitcommand + " ./nice_optics.script &";
			pid_t c_pid = fork(); 
		
			if (c_pid == -1) { 
	        	this->core->logError("SIMPLE_Stream::Dispatch: submitcommand is not a string");
				return false;
	    	} else if (c_pid > 0) { 
	       		this->core->logInfo("SIMPLE_Stream::Dispatch: submitting job " + this->rootfolder + " " + std::to_string(this->id));
	  			this->core->logInfo("SIMPLE_Stream::Dispatch: submitted job " + std::to_string(this->id));
	    	} else { 
				chdir(this->rootfolder.c_str());
				int a = std::system(systemcmd.c_str());
		       	exit(0);
	    	}
    	}
	}

    return true;
}

bool SIMPLE_Stream::FillTemplate(std::string clustertemplate, std::string title, std::string prg, nlohmann::ordered_json jobargs){

	std::string simplepath;
	
	if(!this->core->getConfigValue ("simplepath", simplepath)){
		this->core->logError("SIMPLE_Stream::FillTemplate: failed to retrieve simplepath from config");
		return false;
	}

	if(!folderExists(simplepath)){
		this->core->logError("SIMPLE_Stream::FillTemplate: simplepath does not exist");
		return false;
	}

	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->core->logError("SIMPLE_Stream::FillTemplate: bin folder in simplepath does not exist");
		return false;
	}

	if(!jobargs.is_object()){
		this->core->logError("SIMPLE_Stream::FillTemplate: arguments is not an object");
		return false;
	}

	std::string commandstring;

	commandstring += '\n';
	commandstring += "export SIMPLE_PATH=" + simplepath;
	commandstring += '\n';

	std::string argstring;

	for (auto it = jobargs.begin(); it != jobargs.end(); ++it){
		
		std::string key = it.key();
		std::string value = it.value();
		
		if(key.find("nice") == std::string::npos && value != ""){
			argstring += " " + key + "=" + value;
		}
	}

	commandstring += '{';
	commandstring += '\n';
	commandstring += simplepathbin + "simple_exec prg=update_project projfile=workspace.simple";
	commandstring += " && ";
	commandstring += simplepathbin + "simple_stream prg=" + prg + argstring;
	commandstring += '\n';
	commandstring += "} >> nice_" + title + ".log 2>> nice_" + title + ".error";
	commandstring += '\n';
	commandstring += "echo $? > nice_" + title + ".exit";

	std::ifstream clusterfile(clustertemplate);

	if(!clusterfile){
		this->core->logError("SIMPLE_Stream::FillTemplate: failed to open template");
		return false;
	}

 	std::ostringstream clusterfiless;
    
    clusterfiless << clusterfile.rdbuf();

    std::string templatestring = clusterfiless.str();
	
	clusterfile.close();

	std::string replacestring = "XXXNICEXXX";

	templatestring.replace(templatestring.find(replacestring), replacestring.size(), commandstring);

	replacestring = "nice.pid";

	templatestring.replace(templatestring.find(replacestring), replacestring.size(), "nice_" + title + ".pid");

	std::string scriptfile = this->rootfolder + "/nice_" + title + ".script";

	std::ofstream scriptfilehandle(scriptfile);
	scriptfilehandle << templatestring << std::endl;
	scriptfilehandle.close();

	chmod(scriptfile.c_str(), S_IRWXU);

	return true;
}

// show preproc only send updated jobstats if different
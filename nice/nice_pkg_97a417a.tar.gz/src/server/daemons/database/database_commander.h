#ifndef DATABASE_COMMANDER
#define DATABASE_COMMANDER

#include <iostream>
#include <thread>
#include <sys.h>
#include <filesystem.h>
#include <db.h>

class DatabaseCommander {
	private:
		std::string pg_ctl_path;
		std::string postgres_db;
		std::thread workerthread;
		void ApplySchema();
		bool InitLocalDB();
		
	public:
		DatabaseCommander(bool local);
		void Start();
		void Stop();
		int Status();
		bool WasRunning = false;
};

#endif
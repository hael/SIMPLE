#include "single.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Single::Single(){
	this->module = "SINGLE";
}

bool Single::ReadJobJson(){
	// read config
    nlohmann::ordered_json config = RetreiveConfig();

    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return false;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }
    std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand = "SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_private_exec prg=print_ui_json";
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		return false;
    }
	char buffer[1028];
    std::string ui_json;
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }
	int exitcode = WEXITSTATUS(pclose(cmdpipe));
	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to generate simple ui json");
		return false;
	}
	// Remove Execution line
	ui_json.resize(ui_json.find_last_of("****") - 3);

	if(!nlohmann::ordered_json::accept(ui_json)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid ui json");
		return false;
	}
	
	try{
		this->ui = nlohmann::ordered_json::parse(ui_json);
	}catch (const nlohmann::ordered_json::parse_error& e){
	    spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to parse ui_json");
	    return false;
	}

	for (auto it : ui){
		nlohmann::ordered_json jobjson = it;
		// store job info
		nlohmann::ordered_json joblistelement;
		if(!jobjson.contains("program") || !jobjson["program"].is_object()){
			continue;
		}
		if(jobjson["program"].contains("name") && jobjson["program"]["name"].is_string()){
			joblistelement["name"] = jobjson["program"]["name"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("descr_long") && jobjson["program"]["descr_long"].is_string()){
			joblistelement["descr_long"] = jobjson["program"]["descr_long"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("descr_short") && jobjson["program"]["descr_short"].is_string()){
			joblistelement["descr_short"] = jobjson["program"]["descr_short"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("advanced") && jobjson["program"]["advanced"].is_boolean()){
			joblistelement["advanced"] = jobjson["program"]["advanced"];
		}else{
			continue;
		}
		joblistelement["module"] = "SINGLE";
		if(jobjson["program"].contains("executable") && jobjson["program"]["executable"].is_string() && (jobjson["program"]["executable"].get<std::string>() == "single_exec" || jobjson["program"]["executable"].get<std::string>() == "all")){
			this->joblist.push_back(joblistelement);
		}
		// store job args
		nlohmann::ordered_json argslistelement;
		for (auto& [key, obj] : jobjson.items()){
			if(key != "program"){
				argslistelement[key] = obj;
			}
		}
		this->jobargs[joblistelement["name"].get<std::string>()] = argslistelement;
	}

	return true;
}

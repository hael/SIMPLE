#ifndef WORKSPACE_H
#define WORKSPACE_H

#include <iostream>
#include <json.hpp>
#include <json_helpers.h>
#include <filesystem.h>
#include <db.h>
#include <spdlog/spdlog.h>
#include <project.h>
#include <simple.h>

class Workspace : public Project {
	public:
		int         workspace_id;     // unique id
		int         display_id;       // id within project
		std::string workspace_folder; // full path to workspace folder
		std::string workspace_name;

		Workspace();
		Workspace(int project_id);
		Workspace(nlohmann::ordered_json args);
		bool LoadWorkspace(int workspace_id);
		bool LoadLastAccessedWorkspace();
		int CreateWorkspace();
		nlohmann::ordered_json NewWorkspace();
		nlohmann::ordered_json ListAllWorkspaces();
		nlohmann::ordered_json ListRecentWorkspaces();
		nlohmann::ordered_json StatWorkspace();
		nlohmann::ordered_json AccessWorkspace();
		nlohmann::ordered_json Rename(nlohmann::ordered_json args);
		nlohmann::ordered_json ClearTrash();
		nlohmann::ordered_json ClearProjectTrash();
};

#endif
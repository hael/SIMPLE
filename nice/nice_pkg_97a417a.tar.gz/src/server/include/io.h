#ifndef IO_H
#define IO_H

#include <iostream>
#include <fstream>
#include <thread>
#include <cmath>
#include <filesystem.h>
#include <json_helpers.h>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/rotating_file_sink.h>

inline static std::string ReadTextFile(std::string path){
	//log to stdout as command line 
	if(!fileExists(path)){
		return "";
	}
	std::string filestring;
	std::ifstream file;
	try{
		file.open(path);

		if(!file){
			std::cout << "fstream failed to open file" << std::endl;
			return "";
		}

	 	std::ostringstream filess;
	    filess << file.rdbuf();
	    filestring = filess.str();
	}catch (std::ifstream::failure e) {
   		std::cout << "fstream failure to open cluster template" << std::endl;
  	}
	
	if(file.is_open()) file.close();

	return filestring;
}

inline static nlohmann::ordered_json StatLog(nlohmann::ordered_json args){
	nlohmann::ordered_json returnjson;
	returnjson["stdout"] = "";
	returnjson["stderr"] = "";
	if(json_test_string(args, "stdout") && fileExists(args["stdout"].get<std::string>())){
		returnjson["stdout"] = ReadTextFile(args["stdout"].get<std::string>());
	}
	if(json_test_string(args, "stderr") && fileExists(args["stderr"].get<std::string>())){
		returnjson["stderr"] = ReadTextFile(args["stderr"].get<std::string>());
	}
	returnjson["success"] = true;
	return returnjson;
}

inline static nlohmann::ordered_json StatDir(nlohmann::ordered_json args){
	nlohmann::ordered_json returnjson;
	int pagesize = 100;
	if(!json_test_string(args, "dir")){
		returnjson["error"]   = "directory missing from request";
		returnjson["success"] = false;
		return returnjson;
	}

	if(!json_test_int(args, "page")){
		returnjson["error"]   = "page missing from request";
		returnjson["success"] = false;
		return returnjson;
	}

	std::string dir = args["dir"].get<std::string>();
	int page = args["page"].get<int>();

	if(!folderExists(dir)){
		returnjson["error"]   = "directory does not exist";
		returnjson["success"] = false;
		return returnjson;
	}

	std::vector<std::string> dirs, files;

	if(!ls1fDir(dir, &dirs, &files)){
		returnjson["error"]   = "failed to fast list directory";
		returnjson["success"] = false;
		return returnjson;
	}

	std::sort(dirs.begin(), dirs.end());
	std::sort(files.begin(), files.end());

	int idx_start = page * pagesize;
	int idx_end   = ((page + 1) * pagesize);

	std::vector<std::string> pagedirs;
	std::vector<std::string> pagefiles;

	if(idx_start < dirs.size()){
		if(idx_end < dirs.size()){
			pagedirs.assign(dirs.begin() + idx_start, dirs.begin() + idx_end);
			idx_start = 0;
			idx_end   = 0;
		}else{
			pagedirs.assign(dirs.begin() + idx_start, dirs.end());
			idx_start = 0;
			idx_end   = idx_end - dirs.size();
		}
	}else{
		idx_start = 0 - dirs.size();
		idx_end   = idx_end - dirs.size();
	}

	if(idx_end > 0){
		if(idx_end < files.size()){
			pagefiles.assign(files.begin() + idx_start, files.begin() + idx_end);
		}else{
			pagefiles.assign(files.begin() + idx_start, files.end());
		}
	}

 	returnjson["dirs"]   = {};

 	for (auto it = pagedirs.begin(); it != pagedirs.end(); ++it) {
 		nlohmann::ordered_json pagedirinfo;
 		pagedirinfo["name"] = *it;
 		std::time_t atimet;
 		if(writeTime(dir  + "/" + *it, atimet)){
 			pagedirinfo["mtime"] = atimet;
 		}else{
 			pagedirinfo["mtime"] = 0;
 		}
  		returnjson["dirs"].push_back(pagedirinfo);
	}

 	returnjson["files"]   = {};

 	for (auto it = pagefiles.begin(); it != pagefiles.end(); ++it) {
 		nlohmann::ordered_json pagefileinfo;
 		pagefileinfo["name"] = *it;
 		std::time_t atimet;
 		if(writeTime(dir  + "/" + *it, atimet)){
 			pagefileinfo["mtime"] = atimet;
 		}else{
 			pagefileinfo["mtime"] = 0;
 		}
 		std::string filesize;
		if(humanFileSize(dir  + "/" + *it, filesize)){
 			pagefileinfo["size"] = filesize;
 		}else{
 			pagefileinfo["size"] = "0";
 		}
  		returnjson["files"].push_back(pagefileinfo);
	}

	float npages = (dirs.size() + files.size()) / float(pagesize);
	returnjson["npages"]  = std::ceil(npages);
	//returnjson["dirs"]    = pagedirs;
	//returnjson["files"]   = pagefiles;
	returnjson["success"] = true;
	return returnjson;
}

#endif
#include <imager.h>

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Imager::Imager (std::string thumbnail_uid) {
    this->type          = FAILED;
    pqxx::result thumbnail = sql_nontx_result(std::string_view{"SELECT blob FROM thumbnails WHERE uid='" + thumbnail_uid + "';"});

    if(thumbnail.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retreive thumbnail from database");
        return;
    }

    if(thumbnail[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - thumbnail blob is null");
        return;
    }

    std::basic_string<std::byte> blob = thumbnail[0][0].as<std::basic_string<std::byte>>();

    this->binary_data = new char[blob.length()];
    this->datalength = blob.length();
    memcpy(this->binary_data, blob.data(), blob.length());
    this->thumbnail_uid = thumbnail_uid;
    this->type          = THUMBNAIL_JPEG;
}

Imager::Imager (int i, std::string path) {
    this->type = FAILED;

    if(!fileExists(path)){
        if(i == 0){}
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image path does not exist " + path);
        return;
    }

    // get and check file size
    std::uintmax_t file_size = fileSize(path);
    if(file_size == 0){
        spdlog::get("Core")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file has zero size");
        return;
    }

    // declare blob
    std::basic_string<std::byte> blob;
    blob.resize(file_size);
    // read binary image
    std::ifstream image_file;
    image_file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
    try{
        image_file.open(path, std::ios_base::binary);
        image_file.read(reinterpret_cast<char*>(blob.data()), file_size);
        image_file.close();
    }catch (std::ifstream::failure e) {
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fstream failure to open image file");
        return;
    }

    this->binary_data = new char[blob.length()];
    this->datalength = blob.length();
    memcpy(this->binary_data, blob.data(), blob.length());
    if(i == 1){
        this->type = THUMBNAIL_JPEG;
    }else if(i == 2){
        this->type = BINARY;
    }
    
}

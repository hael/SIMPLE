#include "simple.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Simple::Simple(){
	this->module = "SIMPLE";
}

bool Simple::ReadJobJson(){
	// read config
    nlohmann::ordered_json config = RetreiveConfig();

    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return false;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }
    std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand = "SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_private_exec prg=print_ui_json";
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		return false;
    }
	char buffer[1028];
    std::string ui_json;
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }
	int exitcode = WEXITSTATUS(pclose(cmdpipe));
	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to generate simple ui json");
		return false;
	}
	// Remove Execution line
	ui_json.resize(ui_json.find_last_of("****") - 3);

	if(!nlohmann::ordered_json::accept(ui_json)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid ui json");
		return false;
	}
	
	try{
		this->ui = nlohmann::ordered_json::parse(ui_json);
	}catch (const nlohmann::ordered_json::parse_error& e){
	    spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to parse ui_json");
	    return false;
	}

	for (auto it : ui){
		nlohmann::ordered_json jobjson = it;
		// store job info
		nlohmann::ordered_json joblistelement;
		if(!jobjson.contains("program") || !jobjson["program"].is_object()){
			continue;
		}
		if(jobjson["program"].contains("name") && jobjson["program"]["name"].is_string()){
			joblistelement["name"] = jobjson["program"]["name"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("descr_long") && jobjson["program"]["descr_long"].is_string()){
			joblistelement["descr_long"] = jobjson["program"]["descr_long"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("descr_short") && jobjson["program"]["descr_short"].is_string()){
			joblistelement["descr_short"] = jobjson["program"]["descr_short"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("advanced") && jobjson["program"]["advanced"].is_boolean()){
			joblistelement["advanced"] = jobjson["program"]["advanced"];
		}else{
			continue;
		}
		joblistelement["module"] = "SIMPLE";
		this->joblist.push_back(joblistelement);

		// store job args
		nlohmann::ordered_json argslistelement;
		for (auto& [key, obj] : jobjson.items()){
			if(key != "program"){
				argslistelement[key] = obj;
			}
		}
		this->jobargs[joblistelement["name"].get<std::string>()] = argslistelement;
	}

	return true;
}

bool Simple::InitialiseWorkspace(std::string path){
	// read config
    nlohmann::ordered_json config = RetreiveConfig();
    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return false;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }
    std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand    = "cd " + path + " && SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=new_project dir=" + path;
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		return false;
    }
	char buffer[1028];

    std::string ui_json;

    while (!feof(cmdpipe)) {
    	fgets(buffer, sizeof(buffer), cmdpipe);
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));

	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to initialise SIMPLE workspace");
		return false;
	}
	
	std::string source = path + "/" + basename(path) + ".simple";
	std::string destination = path + "/workspace.simple";
	
	if(!moveFolder(source, destination)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to rename project file");
		return false;
	}

	spdlog::get("Core")->info(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - SIMPLE workspace initiated " + path);
	return true;
}

nlohmann::ordered_json Simple::GetArguments(std::string type){
	nlohmann::ordered_json returnjson;
	if(type == "stream"){
		returnjson = this->streamarguments;
	}else{
		this->ReadJobJson();
		if(json_test_object(this->jobargs, type)) returnjson = this->jobargs[type];
	}
	return returnjson;
}

std::vector<int> Simple::Queue(std::string type, std::string jobfolder, nlohmann::ordered_json args, int template_id, int parent_jobid, std::string parent_jobfolder, std::string comm_addr_str, bool local){
	std::vector<int> processes;
	// read config
    nlohmann::ordered_json config = RetreiveConfig();
	if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return processes;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }
    std::string simple_path = config["simple_path"].get<std::string>();

	if(type == "stream"){
		// generate template
		JobTemplate* job_template;
		if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "template_id")){
			job_template = new JobTemplate(config["simple_stream"]["template_id"].get<int>());
		}else if(template_id > 0){
			job_template = new JobTemplate(template_id);
		}else if(local){
			job_template = new JobTemplate(local);
		}else{
			job_template = new JobTemplate();
		}

		Process* dataprocess     = new Process("data");
		Process* preprocprocess  = new Process("preprocessing");
		Process* opticsprocess   = new Process("opticsgrouping");
		Process* inipickprocess  = new Process("initialpicking");
		Process* refgenprocess   = new Process("referencegeneration");
		Process* refpickprocess  = new Process("referencepicking");
		Process* stream2dprocess = new Process("stream2d");
		Process* stream3dprocess = new Process("stream3d");

		// set some hard coded options for streaming
		nlohmann::ordered_json data_args = args["jobargs"];
		dataprocess->AddExecArguments("SIMPLE", "simple_stream", jobfolder, data_args);
		dataprocess->MarkFinished();

		// preprocessing
		nlohmann::ordered_json preprocess_args = args["jobargs"];
		preprocess_args["niceprocid"] = preprocprocess->process_id;
		preprocess_args["niceserver"] = comm_addr_str;
		preprocess_args["fraca"] = "0.1";
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "preprocess_nparts")){
			preprocess_args["nparts"] = config["simple_stream"]["preprocess_nparts"].get<int>();
		}else{
			preprocess_args["nparts"] = "20";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "preprocess_nthr")){
			preprocess_args["nthr"] = config["simple_stream"]["preprocess_nthr"].get<int>();
		}else{
			preprocess_args["nthr"] = "4";
		}
		preprocess_args["outdir"]          = this->preprocess_dir;
		preprocess_args["projfile_optics"] = this->optics_dir + "/workspace.simple";
		if(preprocess_args.contains("refs2d")) preprocess_args.erase("refs2d");

		// preexec
		std::string preexeccommand = "cp -v ../workspace.simple .\n";
		if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "preprocess_partition")){
			preexeccommand += "export SIMPLE_STREAM_PREPROC_PARTITION=" + config["simple_stream"]["preprocess_partition"].get<std::string>() + "\n";
		}
		preexeccommand += simple_path + "/bin/simple_exec prg=update_project projfile=workspace.simple >> nice_" + preprocprocess->name + ".log 2>> nice_" + preprocprocess->name + ".error\n";
		
		preprocprocess->AddExecArguments("SIMPLE", "simple_stream prg=preproc", jobfolder, preprocess_args, preexeccommand, job_template->template_id);
		preprocprocess->MarkQueued(dataprocess->process_id);

		// optics grouping
		nlohmann::ordered_json optics_args = {};
		optics_args["niceprocid"] = opticsprocess->process_id;
		optics_args["niceserver"] = comm_addr_str;
		optics_args["dir_target"] = this->preprocess_dir;
		optics_args["outdir"]     = this->optics_dir;
		opticsprocess->AddExecArguments("SIMPLE", "simple_stream prg=assign_optics", jobfolder, optics_args, "", job_template->template_id);
		opticsprocess->MarkQueued(preprocprocess->process_id, true);

		// initial picking
		if(json_test_string(args["jobargs"], "refs2d")){
			inipickprocess->MarkSkipped();
		}else{
			nlohmann::ordered_json inipick_args = {};
			inipick_args["niceprocid"]  = inipickprocess->process_id;
			inipick_args["niceserver"]  = comm_addr_str;
			inipick_args["dir_target"]  = this->preprocess_dir;
			inipick_args["outdir"]      = this->inipick_dir;
			inipick_args["moldiam"]     = 100;
			inipick_args["moldiam_max"] = 500;
			inipick_args["nmoldiams"]   = 5;
			inipick_args["ninit"]       = 20;
			inipick_args["ring"]        = "yes";
			inipick_args["interactive"] = "yes";
			inipick_args["pick_roi"]    = "yes";
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "initialpick_nparts")){
				inipick_args["nparts"] = config["simple_stream"]["initialpick_nparts"].get<int>();
			}else{
				inipick_args["nparts"] = "10";
			}
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "initialpick_nthr")){
				inipick_args["nthr"] = config["simple_stream"]["initialpick_nthr"].get<int>();
			}else{
				inipick_args["nthr"] = "8";
			}
			// preexec
			preexeccommand = "";
			if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "pick_partition")){
				preexeccommand += "export SIMPLE_STREAM_PICK_PARTITION=" + config["simple_stream"]["pick_partition"].get<std::string>() + "\n";
			}

			inipickprocess->AddExecArguments("SIMPLE", "simple_stream prg=pick_extract", jobfolder, inipick_args, preexeccommand, job_template->template_id);
			inipickprocess->MarkQueued(opticsprocess->process_id, true);
		}

		// reference generation
		if(json_test_string(args["jobargs"], "refs2d")){
			refgenprocess->MarkSkipped();
		}else{
			nlohmann::ordered_json refgen_args = {};
			refgen_args["niceprocid"]  = refgenprocess->process_id;
			refgen_args["niceserver"]  = comm_addr_str;
			refgen_args["dir_target"]  = this->inipick_dir;
			refgen_args["outdir"]      = this->refgen_dir;
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refgen_nparts")){
				refgen_args["nparts"] = config["simple_stream"]["refgen_nparts"].get<int>();
			}else{
				refgen_args["nparts"] = "1";
			}
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refgen_nthr")){
				refgen_args["nthr"] = config["simple_stream"]["refgen_nthr"].get<int>();
			}else{
				refgen_args["nthr"] = "8";
			}
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refgen_nthr2D")){
				refgen_args["nthr2D"] = config["simple_stream"]["refgen_nthr2D"].get<int>();
			}else{
				refgen_args["nthr2D"] = "8";
			}
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refgen_ncls")){
				refgen_args["ncls"] = config["simple_stream"]["refgen_ncls"].get<int>();
			}else{
				refgen_args["ncls"] = "50";
			}
			if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refgen_nptcls_per_cls")){
				refgen_args["nptcls_per_cls"] = config["simple_stream"]["refgen_nptcls_per_cls"].get<int>();
			}else{
				refgen_args["nptcls_per_cls"] = "100";
			}
			// preexec
			preexeccommand = "";
			if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "refgen_partition")){
				preexeccommand += "export SIMPLE_STREAM_REFGEN_PARTITION=" + config["simple_stream"]["refgen_partition"].get<std::string>() + "\n";
			}

			refgenprocess->AddExecArguments("SIMPLE", "simple_stream prg=gen_picking_refs", jobfolder, refgen_args, preexeccommand, job_template->template_id);
			refgenprocess->MarkQueued(inipickprocess->process_id, false);
		}
		
		// reference based picking
		nlohmann::ordered_json refpick_args = {};
		refpick_args["niceprocid"]      = refpickprocess->process_id;
		refpick_args["niceserver"]      = comm_addr_str;
		refpick_args["dir_target"]      = this->preprocess_dir;
		refpick_args["outdir"]          = this->refpick_dir;
		refpick_args["projfile_optics"] = this->optics_dir + "/workspace.simple";
		refpick_args["pick_roi"]        = "yes";
		if(json_test_string(args["jobargs"], "refs2d")){
			refpick_args["pickrefs"] = args["jobargs"]["refs2d"];
		}else{
			refpick_args["pickrefs"] = this->refgen_dir + "/selected_references.mrcs";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refpick_nparts")){
			refpick_args["nparts"] = config["simple_stream"]["refpick_nparts"].get<int>();
		}else{
			refpick_args["nparts"] = "8";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "refpick_nthr")){
			refpick_args["nthr"] = config["simple_stream"]["refpick_nthr"].get<int>();
		}else{
			refpick_args["nthr"] = "8";
		}
		//astigthreshold + ctfresthreshold + icefracthreshold
		// preexec
		preexeccommand = "";
		if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "pick_partition")){
			preexeccommand += "export SIMPLE_STREAM_PICK_PARTITION=" + config["simple_stream"]["pick_partition"].get<std::string>() + "\n";
		}

		refpickprocess->AddExecArguments("SIMPLE", "simple_stream prg=pick_extract", jobfolder, refpick_args, preexeccommand, job_template->template_id);

		if(json_test_string(args["jobargs"], "refs2d")){
			refpickprocess->MarkQueued(opticsprocess->process_id, true);
		}else{
			refpickprocess->MarkQueued(refgenprocess->process_id, false);
		}

		// stream 2D
		nlohmann::ordered_json stream2d_args = {};
		stream2d_args["niceprocid"]      = stream2dprocess->process_id;
		stream2d_args["niceserver"]      = comm_addr_str;
		stream2d_args["dir_target"]      = this->refpick_dir;
		stream2d_args["outdir"]          = this->stream2d_dir;
		stream2d_args["projfile_optics"] = this->optics_dir + "/workspace.simple";
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nparts")){
			stream2d_args["nparts"] = config["simple_stream"]["stream2d_nparts"].get<int>();
		}else{
			stream2d_args["nparts"] = "10";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nparts_chunk")){
			stream2d_args["nparts_chunk"] = config["simple_stream"]["stream2d_nparts_chunk"].get<int>();
		}else{
			stream2d_args["nparts_chunk"] = "1"; // shmem by default
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nparts_pool")){
			stream2d_args["nparts_pool"] = config["simple_stream"]["stream2d_nparts_pool"].get<int>();
		}else{
			stream2d_args["nparts_pool"] = "10";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nthr")){
			stream2d_args["nthr"] = config["simple_stream"]["stream2d_nthr"].get<int>();
		}else{
			stream2d_args["nthr"] = "8";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_ncls")){
			stream2d_args["ncls"] = config["simple_stream"]["stream2d_ncls"].get<int>();
		}else{
			stream2d_args["ncls"] = "200";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_ncls_start")){
			stream2d_args["ncls_start"] = config["simple_stream"]["stream2d_ncls_start"].get<int>();
		}else{
			stream2d_args["ncls_start"] = "50";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nptcls_per_cls")){
			stream2d_args["nptcls_per_cls"] = config["simple_stream"]["stream2d_nptcls_per_cls"].get<int>();
		}else{
			stream2d_args["nptcls_per_cls"] = "0"; // auto estimation
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_nchunks")){
			stream2d_args["nchunks"] = config["simple_stream"]["stream2d_nchunks"].get<int>();
		}else{
			stream2d_args["nchunks"] = "5";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream2d_lpthres")){
			stream2d_args["lpthres"] = config["simple_stream"]["stream2d_lpthres"].get<int>();
		}else{
			//stream2d_args["lpthres"] = "200";
		}
		// advanced params
		if(json_test_string(args["jobargs"], "abinitalgorithm"))          stream2d_args["abinitalgorithm"]          = args["jobargs"]["abinitalgorithm"];
		if(json_test_string(args["jobargs"], "dynreslim"))                stream2d_args["dynreslim"]                = args["jobargs"]["dynreslim"];
		if(json_test_string(args["jobargs"], "stream_mean_threshold"))    stream2d_args["stream_mean_threshold"]    = args["jobargs"]["stream_mean_threshold"];
		if(json_test_string(args["jobargs"], "stream_rel_var_threshold")) stream2d_args["stream_rel_var_threshold"] = args["jobargs"]["stream_rel_var_threshold"];
		if(json_test_string(args["jobargs"], "stream_abs_var_threshold")) stream2d_args["stream_abs_var_threshold"] = args["jobargs"]["stream_abs_var_threshold"];
		if(json_test_string(args["jobargs"], "stream_minmax_threshold"))  stream2d_args["stream_minmax_threshold"]  = args["jobargs"]["stream_minmax_threshold"];
		if(json_test_string(args["jobargs"], "stream_tvd_theshold"))      stream2d_args["stream_tvd_theshold"]      = args["jobargs"]["stream_tvd_theshold"]; // spelling mistake within simple!
		if(json_test_string(args["jobargs"], "pool_threshold_factor"))    stream2d_args["pool_threshold_factor"]    = args["jobargs"]["pool_threshold_factor"];

		preexeccommand = "";
		if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "stream2d_chunk_partition")){
			preexeccommand += "export SIMPLE_STREAM_CHUNK_PARTITION=" + config["simple_stream"]["stream2d_chunk_partition"].get<std::string>() + "\n";
		}
		if(json_test_object(config, "simple_stream") && json_test_string(config["simple_stream"], "stream2d_pool_partition")){
			preexeccommand += "export SIMPLE_STREAM_POOL_PARTITION=" + config["simple_stream"]["stream2d_pool_partition"].get<std::string>() + "\n";
		}

		stream2dprocess->AddExecArguments("SIMPLE", "simple_stream prg=cluster2D_stream", jobfolder, stream2d_args, preexeccommand, job_template->template_id);
		stream2dprocess->MarkQueued(refpickprocess->process_id, true);

		// stream 3D
		nlohmann::ordered_json stream3d_args = {};
		stream3d_args["niceprocid"]      = stream3dprocess->process_id;
		stream3d_args["niceserver"]      = comm_addr_str;
		stream3d_args["dir_target"]      = this->stream2d_dir;
		stream3d_args["outdir"]          = this->stream3d_dir;
		stream3d_args["nptcls"]          = "0"; // read from 2D
		stream3d_args["pgrp"]            = "c1";
		stream3d_args["mskdiam"]         = "0"; // read from 2D
		stream3d_args["cavg_ini"]        = "yes";
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream3d_nthr")){
			stream3d_args["nthr"] = config["simple_stream"]["stream3d_nthr"].get<int>();
		}else{
			stream3d_args["nthr"] = "8";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream3d_nparts")){
			stream3d_args["nparts"] = config["simple_stream"]["stream3d_nparts"].get<int>();
		}else{
			stream3d_args["nparts"] = "10";
		}
		if(json_test_object(config, "simple_stream") && json_test_int(config["simple_stream"], "stream3d_nthr_ini3d")){
			stream3d_args["nthr_ini3D"] = config["simple_stream"]["stream3d_nthr_ini3d"].get<int>();
		}else{
			stream3d_args["nthr_ini3D"] = "8";
		}

		preexeccommand = "";
		
		stream3dprocess->AddExecArguments("SIMPLE", "simple_stream prg=abinitio3D_stream", jobfolder, stream3d_args, preexeccommand, job_template->template_id);
		stream3dprocess->MarkQueued(stream2dprocess->process_id, true);

		processes.push_back(dataprocess->process_id);
		processes.push_back(preprocprocess->process_id);
		processes.push_back(opticsprocess->process_id);
		processes.push_back(inipickprocess->process_id);
		processes.push_back(refgenprocess->process_id);
		processes.push_back(refpickprocess->process_id);
		processes.push_back(stream2dprocess->process_id);
		processes.push_back(stream3dprocess->process_id);

		delete dataprocess;
		delete preprocprocess;
		delete opticsprocess;
		delete inipickprocess;
		delete refgenprocess;
		delete refpickprocess;
		delete stream2dprocess;
		delete stream3dprocess;

		delete job_template;
	}else{
		// generate template
		JobTemplate* job_template;
		if(template_id > 0){
			job_template = new JobTemplate(template_id);
		}else if (local){
			job_template = new JobTemplate(local);	
		}else{
			job_template = new JobTemplate();
		}
		Process* process = new Process(type);
		
		// static arguments
		nlohmann::ordered_json job_args = args["jobargs"];
		job_args["niceprocid"]          = process->process_id;
		job_args["niceserver"]      	= comm_addr_str;
		job_args["mkdir"]            	= "no";
		job_args["projfile"]            = "workspace.simple";
		//job_args["projfile_optics"] 	= this->optics_dir + "/workspace.simple";

		if(json_test_array(args, "selection") && json_test_int(args, "selection_length") && json_test_string(job_args, "infile")){
			// write selection file
			int selection_length = args["selection_length"].get<int>();
			std::string selection_path = jobfolder + "/" + job_args["infile"].get<std::string>();
			int* selectionmap = new int[selection_length];
			for(int i = 0; i < selection_length; i++){
				selectionmap[i] = 0;
			}
			for (auto it : args["selection"]){
				int clsid = it;
				selectionmap[clsid - 1] = 1; // minus 1 to convert to 0 base
			}
			std::ofstream selectionfilehandle(selection_path);
			for(int i = 0; i < selection_length; i++){
				selectionfilehandle << selectionmap[i] << std::endl;
			}
			selectionfilehandle.close();
			delete [] selectionmap;
		}

		std::string output_redirect = " >> nice_" + process->name + ".log 2>> nice_" + process->name + ".error\n";

		if(parent_jobid < 0){
			std::string preexeccommand = "cp -v ../workspace.simple .\n";
			preexeccommand += simple_path + "/bin/simple_exec prg=update_project projfile=workspace.simple" + output_redirect;
			process->AddExecArguments("SIMPLE", "simple_exec prg=" + type, jobfolder, job_args, preexeccommand, job_template->template_id);
			process->MarkQueuedJob(parent_jobid);
		}else if (fileExists(parent_jobfolder + "/workspace.simple")){
			std::string preexeccommand = "cp -v " + parent_jobfolder + "/workspace.simple .\n";
			preexeccommand += simple_path + "/bin/simple_exec prg=update_project projfile=workspace.simple" + output_redirect;
			process->AddExecArguments("SIMPLE", "simple_exec prg=" + type, jobfolder, job_args, preexeccommand, job_template->template_id);
			process->MarkQueuedJob(parent_jobid);
		}else{
			std::string preexeccommand = "cp -v " + parent_jobfolder + "/workspace.simple .\n";
			preexeccommand += simple_path + "/bin/simple_exec prg=update_project projfile=workspace.simple" + output_redirect;
			process->AddExecArguments("SIMPLE", "simple_exec prg=" + type, jobfolder, job_args, preexeccommand, job_template->template_id);
			process->MarkFailed();
		}

		processes.push_back(process->process_id);
		delete job_template;
		delete process;
	}

	return processes;
}

void Simple::Dispatch(int process_id, bool restart, bool local){
	nlohmann::ordered_json config = RetreiveConfig();

	if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }

    std::string simple_path = config["simple_path"].get<std::string>();

	Process* process = new Process(process_id);

	if(process->process_folder == ""){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing process folder");
		process->MarkFailed();
		delete process;
		return;
	}
	if(process->template_id < 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - missing template id");
		process->MarkFailed();
		delete process;
		return;
	}
	if(!ensureFolder(process->process_folder)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - unable to create process folder");
		process->MarkFailed();
		delete process;
		return;
	}
	if(!json_test_string(config, "simple_path")){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - simple_path missing from config");
		process->MarkFailed();
		delete process;
		return;
	}
	
	JobTemplate* job_template;

	if(local){
		job_template = new JobTemplate(local);
	}else{
		job_template = new JobTemplate(process->template_id);
	}

	std::string output_redirect = " >> nice_" + process->name + ".log 2>> nice_" + process->name + ".error\n";
	std::string commandstring;

	// environment variables
	commandstring += "export SIMPLE_PATH=" + simple_path + "\n";
	commandstring += "export SIMPLE_EMAIL=''\n";

	int nparts = 0;
	if(json_test_int(process->arguments, "nparts")){
		nparts = process->arguments["nparts"].get<int>();
	}else if(json_test_string(process->arguments, "nparts")){
		nparts = std::stoi(process->arguments["nparts"].get<std::string>());
	}else if(json_test_int(process->arguments, "nparts_chunk")){
		nparts = process->arguments["nparts_chunk"].get<int>();
	}else if(json_test_string(process->arguments, "nparts_chunk")){
		nparts = std::stoi(process->arguments["nparts_chunk"].get<std::string>());
	}

	if(nparts > 1){
		if(job_template->submission_command == "sbatch"){
			commandstring += "export SIMPLE_QSYS=slurm\n";
		}else if(job_template->submission_command == "nohup_slurm"){
			commandstring += "export SIMPLE_QSYS=slurm\n";
			job_template->submission_command = "nohup";
		}else{
			commandstring += "export SIMPLE_QSYS=local\n";
		}
	}else{
		commandstring += "export SIMPLE_QSYS=local\n";
	}

	if(json_test_string(config, "simple_default_partition")){
		commandstring += "export SIMPLE_QSYS_PARTITION=" + config["simple_default_partition"].get<std::string>() + "\n";
	}

	if(!json_test_bool(config, "simple_default_partition_time") || !config["simple_default_partition_time"].get<bool>()){
		commandstring += "export SIMPLE_DEFAULT_PARTITION_TIME=true\n";
	}

	// update args for restart
	if(restart){
		if(process->name == "preprocessing" 
		|| process->name == "initialpicking"
		|| process->name == "referencegeneration"
		|| process->name == "stream2D"
		|| process->name == "opticsgrouping"
		|| process->name == "referencepicking"){
			if(json_test_string(process->arguments, "outdir")){
				process->arguments["dir_exec"] = process->arguments["outdir"];
				process->arguments.erase("outdir");
			}
		}
	}

	// update arguments 
    process->arguments = this->ProcessArguments(process->arguments, process->name);

	// log time and host
	commandstring += "echo Nice script running on $HOSTNAME at $(date)" + output_redirect;
	// pre exec command
	if(process->pre_exec_command != ""){
		commandstring += process->pre_exec_command;
	}
	// update project
	//commandstring += simple_path + "/bin/simple_exec prg=update_project projfile=workspace.simple" + output_redirect;
	// add executable
	commandstring += simple_path + "/bin/" + process->executable;
	// add executable arguments
	for (auto& [key, val] : process->arguments.items()){
		if(val.is_string()){
			commandstring += " " + key + "=" + val.get<std::string>();
		}else if(val.is_number_integer()){
			commandstring += " " + key + "=" + std::to_string(val.get<int>());
		}else if(val.is_number_float()){
			commandstring += " " + key + "=" + std::to_string(val.get<float>());
		}
	}

	commandstring += output_redirect;

	int nthr_master = 1;

	if(json_test_int(process->arguments, "nthr_ini3D")){
		nthr_master = process->arguments["nthr_ini3D"].get<int>();
	}else if(json_test_string(process->arguments, "nthr_ini3D")){
		nthr_master = std::stoi(process->arguments["nthr_ini3D"].get<std::string>());
	}

	if(json_test_int(process->arguments, "nthr")){
		if(process->arguments["nthr"].get<int>() > nthr_master) nthr_master = process->arguments["nthr"].get<int>();
	}else if(json_test_string(process->arguments, "nthr")){
		if(std::stoi(process->arguments["nthr"].get<std::string>()) > nthr_master) nthr_master = std::stoi(process->arguments["nthr"].get<std::string>());
	}

	job_template->Substitute(commandstring, nthr_master);
	if(job_template->Write(process->process_folder, "nice_" + process->name +".script")){
		if(job_template->Submit()){
			process->MarkSubmitted();
		}else{
			spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to submit template");
		}
	}else{
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to write template");
		process->MarkFailed();
	}

	delete job_template;
	delete process;

}

void Simple::LinkStream(std::string job_folder){
	if(folderExists(job_folder + "/" + stream2d_dir) && fileExists(job_folder + "/" + stream2d_dir + "/workspace.simple")){
		if(fileExists(job_folder + "/workspace.simple")) moveFolder(job_folder + "/workspace.simple", job_folder + "/workspace.simple.bak");
		if(linkExists(job_folder + "/workspace.simple")) moveFolder(job_folder + "/workspace.simple", job_folder + "/workspace.simple.bak");
		linkFile(job_folder + "/" + stream2d_dir + "/workspace.simple", job_folder + "/workspace.simple");
	}
}

nlohmann::ordered_json Simple::ProcessArguments(nlohmann::ordered_json args, std::string name){
    if(name == "preprocessing"){
    	bool flipx = false;
    	bool flipy = false;
    	if(json_test_bool(args, "flipgainx")){
    		flipx = args["flipgainx"].get<bool>();
    		args.erase("flipgainx");
    	}
    	if(json_test_bool(args, "flipgainy")){
    		flipy = args["flipgainy"].get<bool>();
    		args.erase("flipgainy");
    	}
    	if(flipx && flipy){
    		args["flipgain"] = "xy";
     	}else if(flipx){
    		args["flipgain"] = "x";
     	}else if(flipy){
    		args["flipgain"] = "y";
     	}
     	if(json_test_string(args, "scale")){
    		std::string scale = args["scale"].get<std::string>();
    		if(scale == "1X"){
    			args.erase("scale");
    		}else if(scale == "2X"){
    			args["scale"] = 0.5;
    		}else if(scale == "4X"){
    			args["scale"] = 0.25;
    		}
    	}
    }
    
    if(json_test_string(args, "abinitalgorithm")){
    	if(name == "stream2D" && args["abinitalgorithm"].get<std::string>() != ""){
    		args["algorithm"] = args["abinitalgorithm"].get<std::string>();
    	}
		args.erase("abinitalgorithm");
    }

    for(auto& [key, val] : args.items()){
        if(val.is_boolean()){
            bool val_bool = val.get<bool>();
            if(val_bool){
            	args[key] = "yes";
            }else{
                args[key] = "no";
            }
        }
    }
	return args;
}

nlohmann::ordered_json Simple::ProjectHeaderJson(std::string path, bool folder){

	nlohmann::ordered_json returnjson;

	nlohmann::ordered_json config = RetreiveConfig();

    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return returnjson;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }

	std::string projectpath;

    if(folder){
    	projectpath = path + "/workspace.simple";
    }else{
    	projectpath = path;
    }

	if(!fileExists(projectpath) && !linkExists(projectpath)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - project file does not exist");
        return returnjson;
	}

    std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand    = " SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=print_project_info json=yes";
	jobcommand += " projfile=" + projectpath;

	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		return returnjson;
    }
	char buffer[1028];
    std::string ui_json;
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }
	int exitcode = WEXITSTATUS(pclose(cmdpipe));
	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve project data");
		return returnjson;
	}
	// Remove Execution line
	ui_json.resize(ui_json.find_first_of("****"));

	if(!nlohmann::ordered_json::accept(ui_json)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid project data json");
		return returnjson;
	}
	
	nlohmann::ordered_json proj_json;

	try{
		proj_json = nlohmann::ordered_json::parse(ui_json);
	}catch (const nlohmann::ordered_json::parse_error& e){
	    spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to parse project data json");
	    return returnjson;
	}

	if(json_test_object(proj_json, "mic") && json_test_int(proj_json["mic"], "n")){
		if(!json_test_object(returnjson, "views")) returnjson["views"] = {};
		if(!json_test_object(returnjson["views"], "micrographs")) returnjson["views"]["micrographs"] = {};
		if(!json_test_object(returnjson["views"]["micrographs"] , "micrographs")) returnjson["views"]["micrographs"]["micrographs"]  = {};
		if(!json_test_object(returnjson["views"]["micrographs"]["micrographs"] , "micrographs")) returnjson["views"]["micrographs"]["micrographs"]["micrographs"] = {};
		returnjson["views"]["micrographs"]["micrographs"]["micrographs"]["value"] = proj_json["mic"]["n"].get<int>();
		returnjson["views"]["micrographs"]["micrographs"]["micrographs"]["type"]  = "hidden";
		if(json_test_array(proj_json["mic"], "numeric_keys")){
			if(!json_test_object(returnjson["views"]["micrographs"], "interactive_plot")) returnjson["views"]["micrographs"]["interactive_plot"] = {};
			returnjson["views"]["micrographs"]["interactive_plot"]["keys"] = proj_json["mic"]["numeric_keys"];
			returnjson["views"]["micrographs"]["interactive_plot"]["type"] = "plot_interactive";
		}
	}

	if(json_test_object(proj_json, "cls2D") && json_test_int(proj_json["cls2D"], "n")){
		if(!json_test_object(returnjson, "views")) returnjson["views"] = {};
		if(!json_test_object(returnjson["views"], "cls2D")) returnjson["views"]["cls2D"] = {};
		if(!json_test_object(returnjson["views"]["cls2D"] , "2D")) returnjson["views"]["cls2D"]["2D"]  = {};
		if(!json_test_object(returnjson["views"]["cls2D"]["2D"] , "number_classes")) returnjson["views"]["cls2D"]["2D"]["number_classes"] = {};
		returnjson["views"]["cls2D"]["2D"]["number_classes"]["value"] = proj_json["cls2D"]["n"].get<int>();
		returnjson["views"]["cls2D"]["2D"]["number_classes"]["type"]  = "hidden";
		if(json_test_array(proj_json["cls2D"], "numeric_keys")){
			if(!json_test_object(returnjson["views"]["cls2D"], "interactive_plot")) returnjson["views"]["cls2D"]["interactive_plot"] = {};
			returnjson["views"]["cls2D"]["interactive_plot"]["keys"] = proj_json["cls2D"]["numeric_keys"];
			returnjson["views"]["cls2D"]["interactive_plot"]["type"] = "plot_interactive";
		}
	}

	if(json_test_object(proj_json, "optics") && json_test_int(proj_json["optics"], "n")){
		if(!json_test_object(returnjson, "views")) returnjson["views"] = {};
		if(!json_test_object(returnjson["views"], "optics")) returnjson["views"]["optics"] = {};
		if(!json_test_object(returnjson["views"]["optics"] , "optics")) returnjson["views"]["optics"]["optics"]  = {};
		if(!json_test_object(returnjson["views"]["optics"]["optics"] , "optics_groups_assigned")) returnjson["views"]["optics"]["optics"]["optics_groups_assigned"] = {};
		returnjson["views"]["optics"]["optics"]["optics_groups_assigned"]["value"] = proj_json["optics"]["n"].get<int>();
		returnjson["views"]["optics"]["optics"]["optics_groups_assigned"]["type"]  = "integer";
		if(json_test_array(proj_json["optics"], "numeric_keys")){
			if(!json_test_object(returnjson["views"]["optics"], "interactive_plot")) returnjson["views"]["optics"]["interactive_plot"] = {};
			returnjson["views"]["optics"]["interactive_plot"]["keys"] = proj_json["optics"]["numeric_keys"];
			returnjson["views"]["optics"]["interactive_plot"]["type"] = "plot_interactive";
		}
	}

	if(json_test_object(proj_json, "ptcl2D") && json_test_int(proj_json["ptcl2D"], "n")){
		if(!json_test_object(returnjson, "views")) returnjson["views"] = {};
		if(!json_test_object(returnjson["views"], "particles")) returnjson["views"]["particles"] = {};
		if(!json_test_object(returnjson["views"]["particles"] , "particles")) returnjson["views"]["particles"]["particles"]  = {};
		if(!json_test_object(returnjson["views"]["particles"]["particles"] , "number_particles")) returnjson["views"]["particles"]["particles"]["number_particles"] = {};
		returnjson["views"]["particles"]["particles"]["number_particles"]["value"] = proj_json["ptcl2D"]["n"].get<int>();
		returnjson["views"]["particles"]["particles"]["number_particles"]["type"]  = "integer";
	}

	if(json_test_object(proj_json, "vols") && json_test_int(proj_json["vols"], "n")){
		if(!json_test_object(returnjson, "views")) returnjson["views"] = {};
		if(!json_test_object(returnjson["views"], "vols")) returnjson["views"]["vols"] = {};
		if(!json_test_object(returnjson["views"]["vols"] , "volumes")) returnjson["views"]["vols"]["volumes"]  = {};
		if(!json_test_object(returnjson["views"]["vols"]["volumes"] , "number_volumes")) returnjson["views"]["vols"]["volumes"]["number_volumes"] = {};
		returnjson["views"]["vols"]["volumes"]["number_volumes"]["value"] = proj_json["vols"]["n"].get<int>();
		returnjson["views"]["vols"]["volumes"]["number_volumes"]["type"]  = "integer";
	}

	return returnjson;
}

bool Simple::ProjectDataJson(nlohmann::ordered_json* returnjson, std::string path, nlohmann::ordered_json args, bool folder){
	// read config
    nlohmann::ordered_json config = RetreiveConfig();

    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return false;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }

    int fromp = 0;
    int top   = 0;
	if(json_test_int(args, "fromp") && json_test_int(args, "top")){
		fromp = args["fromp"].get<int>();
		top   = args["top"].get<int>();
	}

	bool sort_asc = true;
	if(json_test_bool(args, "sortasc")) sort_asc = args["sortasc"].get<bool>();

	bool sort = false;
	std::string sortkey;
	if(json_test_string(args, "sortkey")){
		sort    = true;
		sortkey = args["sortkey"].get<std::string>();
	}

	bool hist = false;
	if(json_test_bool(args, "hist")) hist = args["hist"].get<bool>();

	std::string oritype;
	if(json_test_string(args, "oritype")){
		oritype = args["oritype"].get<std::string>();
	}else{
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - oritype missing from request");
        return false;
	}

	std::string projectpath;

	if(folder){
		projectpath = path + "/workspace.simple";
	}else{
		projectpath = path;
	}

	if(! fileExists(projectpath) && !linkExists(projectpath)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - project file does not exist");
        return false;
	}

    std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand    = " SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=print_project_field json=yes";
	jobcommand += " oritype=" + oritype;
	jobcommand += " projfile=" + projectpath;
	if(sort){
		jobcommand += " sort=" + sortkey;
		if(sort_asc){
			jobcommand += " sort_asc=yes";
		}else{
			jobcommand += " sort_asc=no";
		}
	}
	
	if(hist){
		jobcommand += " hist=yes";
	}

	if(fromp > 0 && top > 0){
		jobcommand += " fromp=" + std::to_string(fromp);
		jobcommand += " top=" + std::to_string(top);
	}

	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		return false;
    }
	char buffer[1028];
    std::string ui_json;
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }
	int exitcode = WEXITSTATUS(pclose(cmdpipe));
	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve project data");
		return false;
	}
	// Remove Execution line
	ui_json.resize(ui_json.find_first_of("****"));

	if(!nlohmann::ordered_json::accept(ui_json)){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - invalid project data json");
		return false;
	}
	
	try{
		returnjson->emplace("fielddata", nlohmann::ordered_json::parse(ui_json));
	}catch (const nlohmann::ordered_json::parse_error& e){
	    spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to parse project data json");
	    return false;
	}

	return true;
}

nlohmann::ordered_json Simple::StatProjectFile(nlohmann::ordered_json args){

    nlohmann::ordered_json returnjson;

    if(!json_test_string(args, "projfile")){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile missing from args");
    	returnjson["success"] = false;  
    	return returnjson;
    }

    std::string projfile = args["projfile"].get<std::string>();

    if(!fileExists(projfile) && !linkExists(projfile)){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile does not exist");
    	returnjson["success"] = false;  
    	return returnjson;
    }
   
    nlohmann::ordered_json processes_json = {};
    nlohmann::ordered_json process_json   = {};

    process_json["id"]   = 1;
	process_json["stat"] = this->ProjectHeaderJson(projfile, false);

	processes_json["projfile"] = process_json;

    returnjson["jobstats"] = {};
    returnjson["jobstats"]["id"]        = 1;
    returnjson["jobstats"]["displayid"]  = 1;
    returnjson["jobstats"]["projfile"]  = projfile;
    returnjson["jobstats"]["type"]      = projfile;
    returnjson["jobstats"]["status"]    = "finished";
    returnjson["jobstats"]["processes"] = processes_json;
    returnjson["success"] = true;   

    return returnjson;
}

nlohmann::ordered_json Simple::StatProjectFileData(nlohmann::ordered_json args){
    nlohmann::ordered_json returnjson;

    if(!json_test_string(args, "projfile")){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile missing from args");
    	returnjson["success"] = false;  
    	return returnjson;
    }

    std::string projfile = args["projfile"].get<std::string>();

    if(!fileExists(projfile) && !linkExists(projfile)){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile does not exist");
    	returnjson["success"] = false;  
    	return returnjson;
    }

    returnjson["success"] = true;

    if(!this->ProjectDataJson(&returnjson, projfile, args, false)){
        returnjson["success"] = false; 
    }

    return returnjson;
}

nlohmann::ordered_json Simple::ProjfileSelection(nlohmann::ordered_json args){
    
    nlohmann::ordered_json returnjson;

    // read config
    nlohmann::ordered_json config = RetreiveConfig();

    if(!config.contains("simple_path")){
    	if(getenv("SIMPLE_PATH") == NULL){
    		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to get simple path");
    		return false;
    	}
        config["simple_path"] = getenv("SIMPLE_PATH");
    }

    if(!json_test_string(args, "projfile")){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile missing from args");
    	returnjson["success"] = false;  
    	return returnjson;
    }

    if(!json_test_object(args, "jobargs")){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - jobargs missing from args");
    	returnjson["success"] = false;  
    	return returnjson;
    }

	std::string projfile = args["projfile"].get<std::string>();
    std::string projdir  = parentPath(projfile);
	nlohmann::ordered_json job_args = args["jobargs"];

	if(!fileExists(projfile) && !linkExists(projfile)){
    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - projfile does not exist");
    	returnjson["success"] = false;  
    	return returnjson;
    }

    if(json_test_int(args, "selection_length")){

		int selection_length = args["selection_length"].get<int>();

	    if(!json_test_array(args, "selection")){
	    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - selection missing from args");
	    	returnjson["success"] = false;  
	    	return returnjson;
	    }

	    if(!json_test_string(args["jobargs"], "infile")){
	    	spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - infile missing from jobargs");
	    	returnjson["success"] = false;  
	    	return returnjson;
	    }

	    if(selection_length > 0){
			// write selection file
			std::string selection_path = projdir + "/" + job_args["infile"].get<std::string>();
			job_args["infile"] = selection_path;

			int* selectionmap = new int[selection_length];
			for(int i = 0; i < selection_length; i++){
				selectionmap[i] = 0;
			}
			for (auto it : args["selection"]){
				int clsid = it;
				selectionmap[clsid - 1] = 1; // minus 1 to convert to 0 base
			}

			if(fileExists(selection_path)) removeFile(selection_path);

			std::ofstream selectionfilehandle(selection_path);
			for(int i = 0; i < selection_length; i++){
				selectionfilehandle << selectionmap[i] << std::endl;
			}
			selectionfilehandle.close();
			delete [] selectionmap;
		}
	}
	
	// perform selection - happens on master node atm

	std::string simplepath    = config["simple_path"].get<std::string>();
    std::string simplepathbin = simplepath + "/bin/";
	std::string jobcommand    = " SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=selection mkdir=no projfile=" + projfile ;

	for (auto& [key, val] : job_args.items()){
		if(val.is_string()){
			jobcommand += " " + key + "=" + val.get<std::string>();
		}else if(val.is_number_integer()){
			jobcommand += " " + key + "=" + std::to_string(val.get<int>());
		}else if(val.is_number_float()){
			jobcommand += " " + key + "=" + std::to_string(val.get<float>());
		}
	}

	FILE* cmdpipe = popen(jobcommand.c_str(), "r");
 	if (cmdpipe == nullptr) {
 		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - popen failed");
		returnjson["success"] = false;  
    	return returnjson;
    }

	char buffer[1028];
    std::string stdout;
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) stdout += buffer;
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));
	if(exitcode != 0){
		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to perform selection");
		returnjson["success"] = false;  
    	return returnjson;
	}

    returnjson["success"] = true;
    
    return returnjson;
}
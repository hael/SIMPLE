title: codecov.yml

This is the [Codecov](https://codecov.io/gh/jacobwilliams/json-fortran) configuration file.

```yml
{!codecov.yml!}
```

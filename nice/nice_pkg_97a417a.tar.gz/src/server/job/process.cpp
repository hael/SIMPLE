#include "process.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

Process::Process(int process_id){
	this->process_id = -1;
	this->template_id = -1;
	this->process_folder = "";
	this->executable = "";
	this->arguments = {};
	this->updatearguments = {};
	this->uservals = {};
	this->status = "";

	pqxx::result process = sql_nontx_result(std::string_view{"SELECT folder,executable,name,templateid,preexeccommand,arguments,status,uservals,updatearguments FROM processes WHERE id=" + std::to_string(process_id) + ";"});
	if(process.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve single process from database");
        return;
    }
    if(process[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process folder is null");
        return;
    }
 	if(process[0][1].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process executable is null");
        return;
    }
    if(process[0][2].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process name is null");
        return;
    }
	if(process[0][3].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process templateid is null");
        return;
    }
	
	this->process_id     = process_id;
    this->process_folder = process[0][0].as<std::string>();
	this->executable     = process[0][1].as<std::string>();
	this->name           = process[0][2].as<std::string>();
	this->template_id    = process[0][3].as<int>();

	if(!process[0][4].is_null()){
        this->pre_exec_command = process[0][4].as<std::string>();
    }

	if(!process[0][5].is_null()){
		if(nlohmann::ordered_json::accept(process[0][5].as<std::string>())){
			this->arguments = nlohmann::ordered_json::parse(process[0][5].as<std::string>());
		}
	}

	if(!process[0][6].is_null()){
		this->status = process[0][6].as<std::string>();
	}

	if(!process[0][7].is_null()){
		if(nlohmann::ordered_json::accept(process[0][7].as<std::string>())){
			this->uservals = nlohmann::ordered_json::parse(process[0][7].as<std::string>());
		}
	}
	if(!process[0][8].is_null()){
		if(nlohmann::ordered_json::accept(process[0][8].as<std::string>())){
			this->updatearguments = nlohmann::ordered_json::parse(process[0][8].as<std::string>());
		}
	}

}

Process::Process(nlohmann::ordered_json args, int i){ // i does nothing except distinguish override
	this->process_id = -1;
	this->template_id = -1;
	this->process_folder = "";
	this->executable = "";
	this->arguments = {};
	this->updatearguments = {};
	this->uservals = {};
	this->status = "";

	if(json_test_int(args, "currentprocessid")){
		int process_id = args["currentprocessid"].get<int>();

		pqxx::result process = sql_nontx_result(std::string_view{"SELECT folder,executable,name,templateid,preexeccommand,arguments,status,uservals,updatearguments FROM processes WHERE id=" + std::to_string(process_id) + ";"});
		if(process.size() != 1){
	        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve single process from database");
	        return;
	    }

	    if(process[0][0].is_null()){
	        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process folder is null");
	        return;
	    }
	 	if(process[0][1].is_null()){
	        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process executable is null");
	        return;
	    }
	    if(process[0][2].is_null()){
	        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process name is null");
	        return;
	    }
		if(process[0][3].is_null()){
	        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - process templateid is null");
	        return;
	    }
	
		this->process_id     = process_id;
	    this->process_folder = process[0][0].as<std::string>();
		this->executable     = process[0][1].as<std::string>();
		this->name           = process[0][2].as<std::string>();
		this->template_id    = process[0][3].as<int>();

		if(!process[0][4].is_null()){
	        this->pre_exec_command = process[0][4].as<std::string>();
	    }

		if(!process[0][5].is_null()){
			if(nlohmann::ordered_json::accept(process[0][5].as<std::string>())){
				this->arguments = nlohmann::ordered_json::parse(process[0][5].as<std::string>());
			}
		}

		if(!process[0][6].is_null()){
			this->status = process[0][6].as<std::string>();
		}

		if(!process[0][7].is_null()){
			if(nlohmann::ordered_json::accept(process[0][7].as<std::string>())){
				this->uservals = nlohmann::ordered_json::parse(process[0][7].as<std::string>());
			}
		}

		if(!process[0][8].is_null()){
			if(nlohmann::ordered_json::accept(process[0][8].as<std::string>())){
				this->updatearguments = nlohmann::ordered_json::parse(process[0][8].as<std::string>());
			}
		}


	}
}

Process::Process (std::string name) {
	this->process_id = -1;
	this->template_id = -1;
	this->process_folder = "";
	this->executable = "";
	this->arguments = {};
	this->updatearguments = {};
	this->uservals = {};
	this->status = "";

    pqxx::result new_process = sql_result(std::string_view{"INSERT INTO processes (name,status) VALUES ('" + name + "','building') RETURNING id;"});

    if(new_process.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to insert process into database");
        return;
    }

    if(new_process[0][0].is_null()){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted process id is null");
        return;
    }

    int process_id = new_process[0][0].as<int>();

    if(process_id < 0){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - inserted process id is invalid");
        return;
    }
    this->name       = name;
    this->process_id = process_id;
}

void Process::AddExecArguments(std::string module, std::string executable, std::string execdir, nlohmann::ordered_json jobargs, std::string preexeccommand, int template_id){
	this->executable     = executable;
	this->process_folder = execdir;
	this->arguments      = jobargs;
	sql_request(std::string_view{"UPDATE processes SET arguments='" + jobargs.dump() + "',executable='"+ executable + "',module='" + module + "',folder='" + execdir + "',preexeccommand='" + preexeccommand + "',templateid=" + std::to_string(template_id) + " WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkFinished(){
	sql_request(std::string_view{"UPDATE processes SET status='finished',endtime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkStopped(){
	sql_request(std::string_view{"UPDATE processes SET status='stopped',endtime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkFailed(){
	sql_request(std::string_view{"UPDATE processes SET status='failed',endtime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkSubmitted(){
	sql_request(std::string_view{"UPDATE processes SET status='submitted',restart=FALSE WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkSkipped(){
	sql_request(std::string_view{"UPDATE processes SET status='skipped' WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::MarkQueued(int dependent_id, bool start_when_running){
	if(start_when_running){
		sql_request(std::string_view{"UPDATE processes SET status='queued',startrunning=TRUE,dependentid=" +  std::to_string(dependent_id) + ",queuetime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
	}else{
		sql_request(std::string_view{"UPDATE processes SET status='queued',startrunning=FALSE,dependentid=" +  std::to_string(dependent_id) + ",queuetime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
	}
}

void Process::MarkQueuedJob(int dependent_jobid){
	sql_request(std::string_view{"UPDATE processes SET status='queued',startrunning=FALSE,dependentjobid=" +  std::to_string(dependent_jobid) + ",queuetime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
}

void Process::UpdateHeartbeat(){
	sql_request(std::string_view{"UPDATE processes SET heartbeattime=NOW() WHERE id=" + std::to_string(this->process_id) + ";" });
	sql_request(std::string_view{"UPDATE processes SET status='failed',endtime=NOW() WHERE status='running' AND heartbeattime < NOW() - INTERVAL '1 minutes' AND endtime IS NULL;" });
}

nlohmann::ordered_json Process::UpdateArguments(nlohmann::ordered_json args){
	nlohmann::ordered_json returnjson;
	if(json_test_object(args, "updatearguments")){
		this->updatearguments.merge_patch(args["updatearguments"]);
		sql_request(std::string_view{"UPDATE processes SET updatearguments='" + this->updatearguments.dump(0) + "' WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_object(args, "arguments")){
		this->arguments.merge_patch(args["arguments"]);
		sql_request(std::string_view{"UPDATE processes SET arguments='" + this->arguments.dump(0) + "' WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_object(args, "uservals")){
		if(json_test_object(args, "uservals_replace") && args["uservals_replace"].get<bool>()){
			this->uservals = args["uservals"];
		}else{
			this->uservals.merge_patch(args["uservals"]);
		}
		sql_request(std::string_view{"UPDATE processes SET uservals='" + this->uservals.dump(0) + "' WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_bool(args, "start") && args["start"].get<bool>()){
		sql_request(std::string_view{"UPDATE processes SET startrunning=TRUE WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_bool(args, "restart") && args["restart"].get<bool>()){
		sql_request(std::string_view{"UPDATE processes SET status='restarting',userinput=FALSE,endtime=NULL,restart=TRUE WHERE id=" + std::to_string(this->process_id) + ";" });
		sql_request(std::string_view{"DELETE FROM thumbnails WHERE processid=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_bool(args, "restart_wait") && args["restart_wait"].get<bool>()){
		sql_request(std::string_view{"UPDATE processes SET userinput=FALSE,endtime=NULL,restart=TRUE WHERE id=" + std::to_string(this->process_id) + ";" });
		sql_request(std::string_view{"DELETE FROM thumbnails WHERE processid=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_bool(args, "stop") && args["stop"].get<bool>()){
		sql_request(std::string_view{"UPDATE processes SET status='stopping' WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	if(json_test_bool(args, "userinput")){
		if(args["userinput"].get<bool>()){
			sql_request(std::string_view{"UPDATE processes SET userinput=TRUE WHERE id=" + std::to_string(this->process_id) + ";" });
		}else{
			sql_request(std::string_view{"UPDATE processes SET userinput=FALSE WHERE id=" + std::to_string(this->process_id) + ";" });
		}
	}
	returnjson["success"] = true;
    return returnjson;
}

nlohmann::ordered_json Process::GetUpdates(){
	nlohmann::ordered_json returnjson;

	pqxx::result process = sql_nontx_result(std::string_view{"SELECT updatearguments FROM processes WHERE id=" + std::to_string(this->process_id) + ";"});
	if(process.size() != 1){
        spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - failed to retrieve single process from database");
        returnjson["success"] = false;
        return returnjson;
    }

    if(process[0][0].is_null()){
        // ok as there arent any
        returnjson["success"] = true;
        return returnjson;
    }
 	
 	std::string jsonstring = process[0][0].as<std::string>();
 	if(nlohmann::ordered_json::accept(jsonstring)){
 		nlohmann::ordered_json updatejson = nlohmann::ordered_json::parse(jsonstring);
 		// clear updates
 		sql_request(std::string_view{"UPDATE processes SET updatearguments=NULL WHERE id=" + std::to_string(this->process_id) + ";" });
		returnjson["success"] = true;
 		returnjson["update"] = updatejson;
 		returnjson["success"] = true;
 		return returnjson;
 	}
	returnjson["success"] = false;
    return returnjson;
}

void Process::SetUserInput(bool user_input){
	if(user_input){
		sql_request(std::string_view{"UPDATE processes SET userinput=TRUE WHERE id=" + std::to_string(this->process_id) + ";" });
	}else{
		sql_request(std::string_view{"UPDATE processes SET userinput=FALSE WHERE id=" + std::to_string(this->process_id) + ";" });
	}
	
}

void Process::UpdateStats(nlohmann::ordered_json process_json, TSQueue<nlohmann::ordered_json>* q, TSVector<std::string>* uids){

	auto start = std::chrono::high_resolution_clock::now();
	time_t current_time = time(NULL);
 
 	json_recursive_iterate(process_json, [this, q, uids](nlohmann::ordered_json::const_iterator it){
	    if(it->is_object() && it->contains("last_snapshot_id")){
	    	if(it->at("last_snapshot_id").is_object() && it->at("last_snapshot_id").contains("value")){
	    		this->SetSnapshot(*it);
	    	}
	    }
    });

	if(this->snapshot_jobdisplayid > 0){
    	process_json["views"]["cls2D"]["snapshot"]["last_snapshot_id"]["value"] = this->snapshot_jobdisplayid;
    }

    if(json_test_bool(process_json, "user_input")){
    	bool user_input = process_json["user_input"].get<bool>();
    	process_json.erase("user_input");
    	if(user_input){
			SetUserInput(true);
    	}else{
    		SetUserInput(false);
    	}
    }

    if(json_test_string(process_json, "status")){
    	std::string status = process_json["status"].get<std::string>();
    	process_json.erase("status");
    	if(this->status == "stopping" && status != "stopped") status = "stopping";
    	sql_request(std::string_view{"UPDATE processes SET heartbeattime=NOW(),starttime=COALESCE(starttime, Now()),status='" + status + "',stat='" + process_json.dump() + "' WHERE id=" + std::to_string(this->process_id) + ";" });
    	if(status == "finished"){
    		this->MarkFinished();
    	}else if(status == "stopped"){
    		this->MarkStopped();
    	} 
    }

    json_recursive_iterate(process_json, [this, q, uids](nlohmann::ordered_json::const_iterator it){
    	if(it->is_object() && it->contains("uid") && it->contains("type") && (it->at("type").get<std::string>() == "thumbnail" || it->at("type").get<std::string>() == "thumbnail_grid")){
    		nlohmann::ordered_json thumbnailer_json = it.value();
    		thumbnailer_json["process_id"] = this->process_id;
    		
    		if(!json_test_int(thumbnailer_json, "id")){
			    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - id missing from thumbnail_json");
			    return; 
			}
			// test thumbnail static id exists
			if(!json_test_int(thumbnailer_json, "static_id")){
			    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - static_id missing from thumbnail_json");
			    return; 
			}
			// test thumbnail uid exists
			if(!json_test_string(thumbnailer_json, "uid")){
			    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uid missing from thumbnail_json");
			    return; 
			}
			// test thumbnail path exists
			if(!json_test_string(thumbnailer_json, "path")){
			    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - path missing from thumbnail_json");
			    return; 
			}
			// get thumbnail parameters
			int thumbnail_id          = thumbnailer_json["id"].get<int>();
			int thumbnail_static_id   = thumbnailer_json["static_id"].get<int>();
			std::string thumbnail_uid = thumbnailer_json["uid"].get<std::string>();
			std::string image_path    = thumbnailer_json["path"].get<std::string>();

			if(!uids->contains(thumbnailer_json["uid"].get<std::string>(), true)){
			    // Update thumbnail if changed
			    pqxx::result thumbnail = sql_result("SELECT id,uid FROM thumbnails WHERE processid=" + std::to_string(this->process_id) + " AND staticid=" + std::to_string(thumbnail_static_id) + ";");
			    
			    if(thumbnail.size() == 0){
					pqxx::result new_thumbnail = sql_result("INSERT INTO thumbnails (thumbnailid,staticid,processid,uid,path) VALUES (" + std::to_string(thumbnail_id) + "," + std::to_string(thumbnail_static_id) + "," + std::to_string(this->process_id) + ",'" + thumbnail_uid + "','" + image_path + "') RETURNING id;");
				    if(new_thumbnail.size() == 1 && !new_thumbnail[0][0].is_null()){
						int dbid = new_thumbnail[0][0].as<int>();
						thumbnailer_json["dbid"] = dbid;
						q->push(thumbnailer_json);
				    }
				}else if(thumbnail.size() == 1){
					if(!thumbnail[0][0].is_null() && !thumbnail[0][1].is_null()){
						int id = thumbnail[0][0].as<int>();
						std::string uid = thumbnail[0][1].as<std::string>();
						if(uid != thumbnail_uid){
							sql_request("UPDATE thumbnails SET blob=null,uid='" + thumbnail_uid + "',thumbnailid=" + std::to_string(thumbnail_id) + ",path='" + image_path + "' WHERE id="+ std::to_string(id) + ";");
							thumbnailer_json["dbid"] = id;
		    				q->push(thumbnailer_json);
		    			}
	    			}
				}
    		}
	    }
    });

    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
    std::cout << " updated stats in : " << duration.count() << " microseconds" << std::endl;
}

void Process::SetSnapshot(nlohmann::ordered_json snapshot){

	if(json_test_object(snapshot, "last_snapshot_id") && snapshot["last_snapshot_id"].contains("value")){
		
		int snapshot_jobid = snapshot["last_snapshot_id"]["value"].get<int>();
		
		pqxx::result job_info = sql_nontx_result(std::string_view{"SELECT displayid,status FROM jobs WHERE id=" + std::to_string(snapshot_jobid) + ";" });
		
		if(job_info.size() == 1){
			int display_id = 0;
		   	if(!job_info[0][0].is_null()){ 
		   		display_id = job_info[0][0].as<int>();
		   	}
		   	
		   	std::string status;
		   	if(!job_info[0][1].is_null()){
		    	status = job_info[0][1].as<std::string>();
		    }

		    if(display_id > 0) this->snapshot_jobdisplayid = display_id;

		    if(display_id > 0 && status == "queued" && json_test_object(snapshot, "snapshot_json")){
		    	nlohmann::ordered_json snapshot_json = snapshot["snapshot_json"];
		    	if(json_test_string(snapshot_json, "status")){
		    		std::string status = snapshot_json["status"].get<std::string>();
		    		Process* snapshot_process = new Process("snapshot");
		    		std::string processes_array = "ARRAY[" + std::to_string(snapshot_process->process_id) + ']'; 
		    		sql_request(std::string_view{"UPDATE jobs SET processes=" + processes_array + ",status='" + status + "' WHERE id=" + std::to_string(snapshot_jobid) + ";" });
		    		sql_request(std::string_view{"UPDATE processes SET heartbeattime=NOW(),starttime=COALESCE(starttime, Now()),endtime=COALESCE(starttime, Now()),status='" + status + "',stat='" + snapshot_json.dump() + "' WHERE id=" + std::to_string(snapshot_process->process_id) + ";" });
		    		this->SetUserInput(true);
		    		delete snapshot_process;
		    	}
		    }
		}
	}
}

void Process::SetThumbnail(nlohmann::ordered_json thumbnail_json, std::string boxfile){
	// seed srand
	time_t current_time = time(NULL);
	srand((unsigned) time(NULL));
    // test thumbnail id exists
    if(!json_test_int(thumbnail_json, "id")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - id missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 5 " << std::endl;
        return; 
    }
    // test thumbnail static id exists
    if(!json_test_int(thumbnail_json, "static_id")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - static_id missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 6" << std::endl;
        return; 
    }
    // test thumbnail uid exists
    if(!json_test_string(thumbnail_json, "uid")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uid missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 7 " << std::endl;
        return; 
    }
    // test thumbnail path exists
    if(!json_test_string(thumbnail_json, "path")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - path missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 8 " << std::endl;
        return; 
    }
    // test thumbnail dbid exists
    if(!json_test_int(thumbnail_json, "dbid")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - dbid missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 8 " << std::endl;
        return; 
    }

    // get thumbnail parameters
    int thumbnail_id          = thumbnail_json["id"].get<int>();
    int thumbnail_static_id   = thumbnail_json["static_id"].get<int>();
    int thumbnail_dbid        = thumbnail_json["dbid"].get<int>();
    std::string thumbnail_uid = thumbnail_json["uid"].get<std::string>();
    std::string image_path    = thumbnail_json["path"].get<std::string>();

	// return if file does not exist
	if(!fileExists(image_path)){
	    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file does not exist");
	    std::cout << "THUUMBNAIL RETURN 1 " << std::endl;
	    return;
	}
	    
	// get and check file size
	std::uintmax_t file_size = fileSize(image_path);
	if(file_size == 0){
	    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file has zero size");
	    std::cout << "THUUMBNAIL RETURN 2 " << std::endl;
	    return;
	}

    // declare blob
    std::basic_string<std::byte> blob;
    blob.resize(file_size);
    // read binary image
    std::ifstream image_file;
    image_file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
	try{
		image_file.open(image_path, std::ios_base::binary);
		image_file.read(reinterpret_cast<char*>(blob.data()), file_size);
	}catch (std::ifstream::failure e) {
   		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fstream failure to open scriptfile");
   		std::cout << "THUUMBNAIL RETURN 3 " << std::endl;
   		return;
  	}
	
	if(image_file.is_open()) image_file.close();
    spdlog::get("JobCollector")->info("image file "+ image_path +" read into buffer");

    nlohmann::ordered_json jpeg_comment;
    
    // read boxfile if present
    if(boxfile.size() > 0 && fileExists(boxfile)){
    	int box_idxs[5] = {0,1,2,3,5};
    	auto start = std::chrono::high_resolution_clock::now();
    	nlohmann::json boxes = readBoxFileInt(boxfile, box_idxs, 5);
    	auto stop = std::chrono::high_resolution_clock::now();
    	auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
        std::cout << " read boxfile in : " << duration.count() << " microseconds" << std::endl;
    	//jpeg_comment["boxes"] = boxes["boxes"];
    	jpeg_comment["boxes"] = {};
    	start = std::chrono::high_resolution_clock::now();
    	
    	nlohmann::ordered_json manual;
    	nlohmann::ordered_json gauss;
    	nlohmann::ordered_json ring;
    	nlohmann::ordered_json disk;

    	std::vector<int> diameters;
    	std::vector<nlohmann::ordered_json> manual_diameters;
    	std::vector<nlohmann::ordered_json> gauss_diameters;
    	std::vector<nlohmann::ordered_json> ring_diameters;
    	std::vector<nlohmann::ordered_json> disk_diameters;

    	for (nlohmann::ordered_json boxit : boxes["boxes"]){
    		int x   = boxit[0];
    		int y   = boxit[1];
    		int box = boxit[2];
    		int pickdiam = boxit[3];
    		int model = 0;
    		if(boxit.size() > 4) model = boxit[4];
    		std::vector<int>::iterator it = std::find(diameters.begin(), diameters.end(), pickdiam);
    		int arr_idx = 0;
    		if(it == diameters.end()){
    			diameters.push_back(pickdiam);
    			nlohmann::ordered_json manual_diameter_arr = {};
    			nlohmann::ordered_json gauss_diameter_arr = {};
    			nlohmann::ordered_json ring_diameter_arr = {};
    			nlohmann::ordered_json disk_diameter_arr = {};
    			manual_diameters.push_back(manual_diameter_arr);
				gauss_diameters.push_back(gauss_diameter_arr);
				ring_diameters.push_back(ring_diameter_arr);
				disk_diameters.push_back(disk_diameter_arr);
    			arr_idx = diameters.size() - 1;
    		}else{
				arr_idx = it - diameters.begin();
    		}
    	//	std::string diamsection = "D" + std::to_string(pickdiam);
    		if(model == 0){
    		//	if(!json_test_object(jpeg_comment["boxes"], "manual")) jpeg_comment["boxes"]["manual"] = {};
    		//	if(!json_test_array(jpeg_comment["boxes"]["manual"], diamsection)) jpeg_comment["boxes"]["manual"][diamsection] = {};
    		//	jpeg_comment["boxes"]["manual"][diamsection] += boxit;
    			manual_diameters.at(arr_idx) += boxit;	
    		}else if(model == 1){
    		//	if(!json_test_object(jpeg_comment["boxes"], "gauss"))  jpeg_comment["boxes"]["gauss"]  = {};
    		//	if(!json_test_array(jpeg_comment["boxes"]["gauss"], diamsection)) jpeg_comment["boxes"]["gauss"][diamsection] = {};
    		//	jpeg_comment["boxes"]["gauss"][diamsection] += boxit;
    			gauss_diameters.at(arr_idx)  += boxit;	
    		}else if(model == 2){
    		//	if(!json_test_object(jpeg_comment["boxes"], "ring"))   jpeg_comment["boxes"]["ring"]   = {};
    		//	if(!json_test_array(jpeg_comment["boxes"]["ring"], diamsection)) jpeg_comment["boxes"]["ring"][diamsection] = {};
    		//	jpeg_comment["boxes"]["ring"][diamsection] += boxit;
    			ring_diameters.at(arr_idx)  += boxit;	
    		}else if(model == 3){
    		//	if(!json_test_object(jpeg_comment["boxes"], "disk"))   jpeg_comment["boxes"]["disk"]   = {};
    		//	if(!json_test_array(jpeg_comment["boxes"]["disk"], diamsection)) jpeg_comment["boxes"]["disk"][diamsection] = {};
    		//	jpeg_comment["boxes"]["disk"][diamsection] += boxit;
    			disk_diameters.at(arr_idx)  += boxit;	
    		}
    	}

    	for(int i=0; i < diameters.size(); i++){
    		std::string diamsection = "D" + std::to_string(diameters[i]);
    		if(!manual_diameters.at(i).empty()) manual[diamsection] = manual_diameters.at(i);
    		if(!gauss_diameters.at(i).empty())  gauss[diamsection]  = gauss_diameters.at(i);
    		if(!ring_diameters.at(i).empty())   ring[diamsection]   = ring_diameters.at(i);
    		if(!disk_diameters.at(i).empty())   disk[diamsection]   = disk_diameters.at(i);	
    	}

    	if(!manual.empty()) jpeg_comment["boxes"]["manual"] = manual;
    	if(!gauss.empty())  jpeg_comment["boxes"]["gauss"]  = gauss;
    	if(!ring.empty())   jpeg_comment["boxes"]["ring"]   = ring;
    	if(!disk.empty())   jpeg_comment["boxes"]["disk"]   = disk;
		stop = std::chrono::high_resolution_clock::now();
    	duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
        std::cout << " processed boxes in : " << duration.count() << " microseconds" << std::endl;
    }

    // add sprite info if present
    if(json_test_int(thumbnail_json, "spriten") && json_test_int(thumbnail_json, "spritedim")){
		jpeg_comment["spriten"]   = thumbnail_json["spriten"];
		jpeg_comment["spritedim"] = thumbnail_json["spritedim"];
    }

    // add metadata if present
    if(json_test_object(thumbnail_json, "metadata")){
		jpeg_comment["metadata"] = thumbnail_json["metadata"];
    }

    if(!jpeg_comment.empty()){
    	std::string com_json = jpeg_comment.dump(0);
    	std::vector<std::uint8_t> msgpack = nlohmann::ordered_json::to_msgpack(jpeg_comment);
    	std::cout << "COM_JSON " << com_json.size() << " " << msgpack.size() << std::endl;
    	// insert json string into com section of jpeg
    	if(blob[0] == std::byte{0xff} && blob[1] == std::byte{0xd8} && blob[2] == std::byte{0xff} && blob[3] == std::byte{0xe0}){
    		std::basic_string<std::byte> blob_tmp;
    		blob_tmp = blob;
    		blob.clear();
	        unsigned short app0_len = Decode16((unsigned char*) &blob_tmp[4]);
	        int read_from = 4 + app0_len;
	        int insert_at = read_from;
	        //
	        int section_max = UINT16_MAX - 2;
	        int napp = (int) std::ceil((float) msgpack.size() / (float) section_max);
	    	//app1 section
	    	JPEG_App1_Section app1_section;
	        app1_section.app         = be_word(0xffe1);
	        app1_section.app_len     = be_word(sizeof(app1_section) - 2);
	        app1_section.napp        = napp;
	        app1_section.payload_len = msgpack.size();
	        // create output blob
	        int blob_size = blob_tmp.length() + sizeof(app1_section) + (napp * 4) + msgpack.size();
	        blob.resize(blob_size);
	        // write 1st part of header
			memcpy(&blob[0], blob_tmp.data(), read_from);
			// write app1
			memcpy(&blob[insert_at], (void*)&app1_section, sizeof(app1_section));
			insert_at = insert_at + sizeof(app1_section);
	        // write napp app sections
	        for(int i = 0; i < napp; i++){
	        	int msgpack_start = i * section_max;
	        	uint16_t appn_length;
	        	if(i == napp - 1){
	        		appn_length = msgpack.size() - msgpack_start;
	        	}else{
	        		appn_length = section_max;
	        	}
	        	JPEG_Section_Header appn_header;
	        	if(i == 0){
	        		appn_header.com = be_word(0xffe2);
	        	}else if(i == 1){
	        		appn_header.com = be_word(0xffe3);
	        	}else if(i == 2){
	        		appn_header.com = be_word(0xffe4);
	        	}else if(i == 3){
	        		appn_header.com = be_word(0xffe5);
	        	}else if(i == 4){
	        		appn_header.com = be_word(0xffe6);
	        	}else if(i == 5){
	        		appn_header.com = be_word(0xffe7);
	        	}else if(i == 6){
	        		appn_header.com = be_word(0xffe8);
	        	}else if(i == 7){
	        		appn_header.com = be_word(0xffe9);
	        	}
	        	appn_header.com_len = be_word(appn_length + 2);
	        	memcpy(&blob[insert_at], (void*)&appn_header, sizeof(appn_header));
	        	memcpy(&blob[insert_at + sizeof(appn_header)], &msgpack[msgpack_start], appn_length);
	        	insert_at = insert_at + appn_length + sizeof(appn_header);
	        }
	        // insert rest of blob
	        memcpy(&blob[insert_at], &blob_tmp.data()[read_from], blob_tmp.length() - read_from);
	    }
	}
	// update blob in database

    sql_request("UPDATE thumbnails SET blob=($1) WHERE id="+ std::to_string(thumbnail_dbid) + " AND uid='" + thumbnail_uid + "';" , blob);

    return;
}

/*void Process::SetThumbnail(nlohmann::ordered_json thumbnail_json, std::string boxfile){
	// seed srand
	time_t current_time = time(NULL);
	srand((unsigned) time(NULL));
    // test thumbnail id exists
    if(!json_test_int(thumbnail_json, "id")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - id missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 5 " << std::endl;
        return; 
    }
    // test thumbnail static id exists
    if(!json_test_int(thumbnail_json, "static_id")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - static_id missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 6" << std::endl;
        return; 
    }
    // test thumbnail uid exists
    if(!json_test_string(thumbnail_json, "uid")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - uid missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 7 " << std::endl;
        return; 
    }
    // test thumbnail path exists
    if(!json_test_string(thumbnail_json, "path")){
        spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - path missing from thumbnail_json");
        std::cout << "THUUMBNAIL RETURN 8 " << std::endl;
        return; 
    }

    // get thumbnail parameters
    int thumbnail_id          = thumbnail_json["id"].get<int>();
    int thumbnail_static_id   = thumbnail_json["static_id"].get<int>();
    std::string thumbnail_uid = thumbnail_json["uid"].get<std::string>();
    int existing_id           = 0;
    std::string image_path    = thumbnail_json["path"].get<std::string>();

    // Update thumbnail if changed
    pqxx::result thumbnail = sql_result("SELECT id,thumbnailid FROM thumbnails WHERE processid=" + std::to_string(this->process_id) + " AND staticid=" + std::to_string(thumbnail_static_id) + ";");
    if(thumbnail.size() > 1){
	    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - more that one result returned for process");
	    std::cout << "THUUMBNAIL RETURN 9 " << std::endl;
	    return;
	}
	std::cout << "THUUMBNAIL " << thumbnail.size() << std::endl;
    if(thumbnail.size() == 1){
    	if(!thumbnail[0][1].is_null() && thumbnail[0][1].as<int>() == thumbnail_id) return; // already in db
    	if(!thumbnail[0][0].is_null()){
    		std::cout << "THUUMBNAIL EXISTING " << thumbnail[0][0].as<int>() << std::endl;
    		existing_id = thumbnail[0][0].as<int>();
    	}else{
    		std::cout << "SELECT id,thumbnailid FROM thumbnails WHERE processid=" + std::to_string(this->process_id) + " AND staticid=" + std::to_string(thumbnail_static_id) + ";" << std::endl;
    	}
    }
	
	// return if file does not exist
	if(!fileExists(image_path)){
	    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file does not exist");
	    std::cout << "THUUMBNAIL RETURN 1 " << std::endl;
	    return;
	}
	    
	// get and check file size
	std::uintmax_t file_size = fileSize(image_path);
	if(file_size == 0){
	    spdlog::get("JobCollector")->error(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - image file has zero size");
	    std::cout << "THUUMBNAIL RETURN 2 " << std::endl;
	    return;
	}

    // declare blob
    std::basic_string<std::byte> blob;
    blob.resize(file_size);
    // read binary image
    std::ifstream image_file;
    image_file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
	try{
		image_file.open(image_path, std::ios_base::binary);
		image_file.read(reinterpret_cast<char*>(blob.data()), file_size);
	}catch (std::ifstream::failure e) {
   		spdlog::get("Core")->warn(STRINGIZE(__FILE__) ":" STRINGIZE(__LINE__) " - fstream failure to open scriptfile");
   		std::cout << "THUUMBNAIL RETURN 3 " << std::endl;
   		return;
  	}
	
	if(image_file.is_open()) image_file.close();
    spdlog::get("JobCollector")->info("image file "+ image_path +" read into buffer");

    nlohmann::ordered_json jpeg_comment;
    
    // read boxfile if present
    if(boxfile.size() > 0 && fileExists(boxfile)){
    	int box_idxs[5] = {0,1,2,3,5};
    	nlohmann::json boxes = readBoxFileInt(boxfile, box_idxs, 5);
    	//jpeg_comment["boxes"] = boxes["boxes"];
    	jpeg_comment["boxes"] = {};
    	for (nlohmann::ordered_json boxit : boxes["boxes"]){
    		int x   = boxit[0];
    		int y   = boxit[1];
    		int box = boxit[2];
    		int pickdiam = boxit[3];
    		int model = 0;
    		if(boxit.size() > 4) model = boxit[4];
    		std::string diamsection = "D" + std::to_string(pickdiam);
    		if(model == 0){
    			if(!json_test_object(jpeg_comment["boxes"], "manual")) jpeg_comment["boxes"]["manual"] = {};
    			if(!json_test_array(jpeg_comment["boxes"]["manual"], diamsection)) jpeg_comment["boxes"]["manual"][diamsection] = {};
    			jpeg_comment["boxes"]["manual"][diamsection] += boxit;
    		}else if(model == 1){
    			if(!json_test_object(jpeg_comment["boxes"], "gauss"))  jpeg_comment["boxes"]["gauss"]  = {};
    			if(!json_test_array(jpeg_comment["boxes"]["gauss"], diamsection)) jpeg_comment["boxes"]["gauss"][diamsection] = {};
    			jpeg_comment["boxes"]["gauss"][diamsection] += boxit;
    		}else if(model == 2){
    			if(!json_test_object(jpeg_comment["boxes"], "ring"))   jpeg_comment["boxes"]["ring"]   = {};
    			if(!json_test_array(jpeg_comment["boxes"]["ring"], diamsection)) jpeg_comment["boxes"]["ring"][diamsection] = {};
    			jpeg_comment["boxes"]["ring"][diamsection] += boxit;
    		}else if(model == 3){
    			if(!json_test_object(jpeg_comment["boxes"], "disk"))   jpeg_comment["boxes"]["disk"]   = {};
    			if(!json_test_array(jpeg_comment["boxes"]["disk"], diamsection)) jpeg_comment["boxes"]["disk"][diamsection] = {};
    			jpeg_comment["boxes"]["disk"][diamsection] += boxit;
    		}
    	}
    }

    // add sprite info if present
    if(json_test_int(thumbnail_json, "spriten") && json_test_int(thumbnail_json, "spritedim")){
		jpeg_comment["spriten"]   = thumbnail_json["spriten"];
		jpeg_comment["spritedim"] = thumbnail_json["spritedim"];
    }

    // add metadata if present
    if(json_test_object(thumbnail_json, "metadata")){
		jpeg_comment["metadata"] = thumbnail_json["metadata"];
    }

    if(!jpeg_comment.empty()){
    	std::string com_json = jpeg_comment.dump(0);
    	std::vector<std::uint8_t> msgpack = nlohmann::ordered_json::to_msgpack(jpeg_comment);
    	std::cout << "COM_JSON " << com_json.size() << " " << msgpack.size() << std::endl;
    	// insert json string into com section of jpeg
    	if(blob[0] == std::byte{0xff} && blob[1] == std::byte{0xd8} && blob[2] == std::byte{0xff} && blob[3] == std::byte{0xe0}){
    		std::basic_string<std::byte> blob_tmp;
    		blob_tmp = blob;
    		blob.clear();
	        unsigned short app0_len = Decode16((unsigned char*) &blob_tmp[4]);
	        int read_from = 4 + app0_len;
	        int insert_at = read_from;
	        //
	        int section_max = UINT16_MAX - 2;
	        int napp = (int) std::ceil((float) msgpack.size() / (float) section_max);
	    	//app1 section
	    	JPEG_App1_Section app1_section;
	        app1_section.app         = be_word(0xffe1);
	        app1_section.app_len     = be_word(sizeof(app1_section) - 2);
	        app1_section.napp        = napp;
	        app1_section.payload_len = msgpack.size();
	        // create output blob
	        int blob_size = blob_tmp.length() + sizeof(app1_section) + (napp * 4) + msgpack.size();
	        blob.resize(blob_size);
	        // write 1st part of header
			memcpy(&blob[0], blob_tmp.data(), read_from);
			// write app1
			memcpy(&blob[insert_at], (void*)&app1_section, sizeof(app1_section));
			insert_at = insert_at + sizeof(app1_section);
	        // write napp app sections
	        for(int i = 0; i < napp; i++){
	        	int msgpack_start = i * section_max;
	        	uint16_t appn_length;
	        	if(i == napp - 1){
	        		appn_length = msgpack.size() - msgpack_start;
	        	}else{
	        		appn_length = section_max;
	        	}
	        	JPEG_Section_Header appn_header;
	        	if(i == 0){
	        		appn_header.com = be_word(0xffe2);
	        	}else if(i == 1){
	        		appn_header.com = be_word(0xffe3);
	        	}else if(i == 2){
	        		appn_header.com = be_word(0xffe4);
	        	}else if(i == 3){
	        		appn_header.com = be_word(0xffe5);
	        	}else if(i == 4){
	        		appn_header.com = be_word(0xffe6);
	        	}else if(i == 5){
	        		appn_header.com = be_word(0xffe7);
	        	}else if(i == 6){
	        		appn_header.com = be_word(0xffe8);
	        	}else if(i == 7){
	        		appn_header.com = be_word(0xffe9);
	        	}
	        	appn_header.com_len = be_word(appn_length + 2);
	        	memcpy(&blob[insert_at], (void*)&appn_header, sizeof(appn_header));
	        	memcpy(&blob[insert_at + sizeof(appn_header)], &msgpack[msgpack_start], appn_length);
	        	insert_at = insert_at + appn_length + sizeof(appn_header);
	        }
	        // insert rest of blob
	        memcpy(&blob[insert_at], &blob_tmp.data()[read_from], blob_tmp.length() - read_from);
	    }
    	/
	}

    // update blob in database
    if(existing_id == 0){
    	std::cout << "THUMB SQL " << "INSERT INTO thumbnails (thumbnailid,staticid,processid,uid,path,blob) VALUES (" + std::to_string(thumbnail_id) + "," + std::to_string(thumbnail_static_id) + "," + std::to_string(this->process_id) + ",'" + thumbnail_uid + "','" + image_path + "',($1));" << std::endl;
		sql_request("INSERT INTO thumbnails (thumbnailid,staticid,processid,uid,path,blob) VALUES (" + std::to_string(thumbnail_id) + "," + std::to_string(thumbnail_static_id) + "," + std::to_string(this->process_id) + ",'" + thumbnail_uid + "','" + image_path + "',($1));", blob); 
    }else{
    	std::cout << "UPDATE thumbnails SET uid='" + thumbnail_uid + "',thumbnailid=" + std::to_string(thumbnail_id) + ",blob=($1) WHERE id="+ std::to_string(existing_id) + ";"  << std::endl;
    	sql_request("UPDATE thumbnails SET uid='" + thumbnail_uid + "',thumbnailid=" + std::to_string(thumbnail_id) + ",blob=($1) WHERE id="+ std::to_string(existing_id) + ";" , blob);
    }

    return;
}*/

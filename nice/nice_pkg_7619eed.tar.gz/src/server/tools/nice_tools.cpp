#include "nice_tools.h"

#define STRINGIZE_DETAIL(x) #x
#define STRINGIZE(x) STRINGIZE_DETAIL(x)

NiceTools::NiceTools(){
	this->module = "NICE";
}

std::vector<int> NiceTools::Queue(std::string type, std::string jobfolder, nlohmann::ordered_json args, int template_id, int parent_jobid, std::string parent_jobfolder, std::string comm_addr_str, bool local){
	std::vector<int> processes;
	if(type == "export_star"){
		Simple* simple = new Simple();
        processes = simple->Queue("export_starproject", jobfolder, args, -1, parent_jobid, parent_jobfolder, comm_addr_str, local);
        delete simple;
	}else if(type == "manual_picker"){
		if(folderExists(parent_jobfolder) && fileExists(parent_jobfolder + "/workspace.simple") && ! fileExists(jobfolder + "/workspace.simple")){
			copyFile(parent_jobfolder + "/workspace.simple", jobfolder + "/workspace.simple");
		}
		Process* process = new Process(type);
		process->MarkFinished();
		processes.push_back(process->process_id);
		delete process;
	}
	return processes;
}

nlohmann::ordered_json NiceTools::ProjectHeaderJson(std::string type, std::string path, bool folder){
	nlohmann::ordered_json returnjson;
	if(type == "export_star" || type == "manual_picker"){
		Simple* simple = new Simple();
		returnjson = simple->ProjectHeaderJson(path);
		delete simple;
	}
	return returnjson;
}

bool NiceTools::ProjectDataJson(nlohmann::ordered_json* returnjson, std::string type, std::string path, nlohmann::ordered_json args, bool folder){
	bool returnbool = false;
	if(type == "export_star" || type == "manual_picker"){
		Simple* simple = new Simple();
		returnbool = simple->ProjectDataJson(returnjson, path, args);
		delete simple;
	}
	return returnbool;
}
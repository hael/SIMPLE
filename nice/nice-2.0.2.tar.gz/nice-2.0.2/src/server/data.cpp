#include "core.hpp"

void Core::dataWorker(){
	while(true){
		usleep(5000000);
		this->logInfo("starting data worker cycle");
		this->cleanupCycle();
		this->deleteCycle();
		this->trashCycle();
		this->logInfo("completed data worker cycle");
	}
}

void Core::cleanupCycle(){

	std::string sql = "SELECT * FROM jobs WHERE status='cleanup';";
	
	std::vector<std::map<std::string, std::string>> cleanupjobs;

	if(!this->queryDB(sql, &cleanupjobs)){
		this->logError("cleanupCycle : server failed to reply: sql query failed");
		return;
	}

	for(auto &job : cleanupjobs){
		// UPDATE deleted here?

		if(job.find("workspaceid") == job.end()){
			this->logError("cleanupCycle : id missing for job");
			continue;
		}

		int workspaceid = std::stoi(job["workspaceid"]);

		std::map<std::string, std::string> workspace;

		if(!this->getWorkspace(workspaceid, "", "admin", &workspace)){
			this->logError("cleanupCycle : failed to retrieve workspace");
			continue;
		}

		if(workspace.find("project") == workspace.end()){
			this->logError("cleanupCycle : project missing for workspace");
			continue;
		}

		int projectid = std::stoi(workspace["project"]);

		std::map<std::string, std::string> project;

		if(!this->getProject(projectid, "", "admin", &project)){
			this->logError("cleanupCycle : failed to retrieve project");
			continue;
		}

		if(job.find("subfolder") == job.end()){
			this->logError("cleanupCycle : subfolder missing for job");
			continue;
		}

		if(job.find("module") == job.end()){
			this->logError("cleanupCycle : module missing for job");
			continue;
		}

		if(job.find("version") == job.end()){
			this->logError("cleanupCycle : version missing for job");
			continue;
		}

		if(workspace.find("subfolder") == workspace.end()){
			this->logError("cleanupCycle : subfolder missing for workspace");
			continue;
		}
		
		if(project.find("folder") == project.end()){
			this->logError("cleanupCycle : folder missing for project");
			continue;
		}

		std::string jobfolder   = project["folder"] + '/' + workspace["subfolder"] + '/' + job["subfolder"];
		std::string trashfolder = project["folder"] + '/' + workspace["subfolder"] + "/TRASH";
		std::string destinationfolder = project["folder"] + '/' + workspace["subfolder"] + "/TRASH/" + job["subfolder"];

		std::string module  = job["module"];
		std::string version = job["version"];

		if(!ensureFolder(trashfolder)){
			this->logError("cleanupCycle : failed to create trash folder : " + trashfolder);
			continue;
		}

		if(!folderExists(jobfolder)){
			this->logError("cleanupCycle : job folder does not exists : " + jobfolder);
			continue;
		}
		
		if(!moveFolder(jobfolder, destinationfolder)){
			this->logError("cleanupCycle : failed to move jobfolder to TRASH : " + jobfolder);
			continue;
		}

		if(module == "SIMPLE"){
			this->SIMPLE_cleanup(version);
		}
	
		//std::uintmax_t foldersize = folderSize(trashfolder);
		std::uintmax_t foldersize = 0;
		sql = "UPDATE workspaces SET trashusage=" + std::to_string(foldersize) + " WHERE id=" + std::to_string(workspaceid) + ";";
		
		if(!this->queryDB(sql)){
			this->logError("deleteCycle : Failed to set workspace trash usage for workspace " + std::to_string(workspaceid));
		}
	}

}

void Core::deleteCycle(){

	std::string sql = "SELECT * FROM jobs WHERE status='deleted' AND deleted=FALSE;";
	
	std::vector<std::map<std::string, std::string>> deletedjobs;

	if(!this->queryDB(sql, &deletedjobs)){
		this->logError("deleteCycle : server failed to reply: sql query failed");
		return;
	}

	for(auto &job : deletedjobs){

		if(job.find("id") == job.end()){
			this->logError("deleteCycle : id missing for job");
			continue;
		}

		int jobid = std::stoi(job["id"]);

		sql = "UPDATE jobs SET deleted=TRUE WHERE id=" + std::to_string(jobid) + ";";
		
		if(!this->queryDB(sql)){
			this->logError("deleteCycle : Failed to update job deleted status for job " + std::to_string(jobid));
		}

		if(job.find("workspaceid") == job.end()){
			this->logError("deleteCycle : id missing for job");
			continue;
		}

		int workspaceid = std::stoi(job["workspaceid"]);

		std::map<std::string, std::string> workspace;

		if(!this->getWorkspace(workspaceid, "", "admin", &workspace)){
			this->logError("deleteCycle : failed to retrieve workspace");
			continue;
		}

		if(workspace.find("project") == workspace.end()){
			this->logError("deleteCycle : project missing for workspace");
			continue;
		}

		int projectid = std::stoi(workspace["project"]);

		std::map<std::string, std::string> project;

		if(!this->getProject(projectid, "", "admin", &project)){
			this->logError("deleteCycle : failed to retrieve project");
			continue;
		}

		if(job.find("subfolder") == job.end()){
			this->logError("deleteCycle : subfolder missing for job");
			continue;
		}

		if(workspace.find("subfolder") == workspace.end()){
			this->logError("deleteCycle : subfolder missing for workspace");
			continue;
		}
		
		if(project.find("folder") == project.end()){
			this->logError("deleteCycle : folder missing for project");
			continue;
		}

		std::string jobfolder   = project["folder"] + '/' + workspace["subfolder"] + '/' + job["subfolder"];
		std::string trashfolder = project["folder"] + '/' + workspace["subfolder"] + "/TRASH";
		std::string destinationfolder = project["folder"] + '/' + workspace["subfolder"] + "/TRASH/" + job["subfolder"];

		if(!ensureFolder(trashfolder)){
			this->logError("deleteCycle : failed to create trash folder : " + trashfolder);
			continue;
		}

		if(!folderExists(jobfolder)){
			this->logError("deleteCycle : job folder does not exists : " + jobfolder);

			continue;
		}
		
		if(!moveFolder(jobfolder, destinationfolder)){
			this->logError("deleteCycle : failed to move jobfolder to TRASH : " + jobfolder);
			continue;
		}
	
		//std::uintmax_t foldersize = folderSize(trashfolder);
		std::uintmax_t foldersize = 0;
		sql = "UPDATE workspaces SET trashusage=" + std::to_string(foldersize) + " WHERE id=" + std::to_string(workspaceid) + ";";
		
		if(!this->queryDB(sql)){
			this->logError("deleteCycle : Failed to set workspace trash usage for workspace " + std::to_string(workspaceid));
		}


	}

}

void Core::trashCycle(){

}

/*
void Job::cleanupDelete() {
	
	logger->logInfo("Cleanup/Deletion thread started");
	
	while(true){
		
		usleep(5000000);
		logger->logInfo("Running cleanup/delete cycle");
				
		std::string sql = "SELECT * FROM jobs WHERE status='cleanup' OR status='deleted';";
		
		nlohmann::ordered_json resultjson;
		
		if(sqlite->query(sql, &resultjson)){
			
			for(auto it = std::begin(resultjson["result"]); it != std::end(resultjson["result"]); ++it) {
				nlohmann::ordered_json job = *it;
				
				if(job["status"].get<std::string>() == "cleanup" && job["cleanup"].get<std::string>() != "1"){
					cleanupWorker(job);
				}
				
				if(job["status"].get<std::string>() == "deleted" && job["deleted"].get<std::string>() != "1"){
					deleteWorker(job);
				}
			}
			
		}else{
			logger->logError("Failed to collect jobs from database");
		}
		
		sql = "SELECT * FROM workspaces WHERE emptytrash=TRUE;";
		resultjson.clear();
		
		if(sqlite->query(sql, &resultjson)){
			
			for(auto it = std::begin(resultjson["result"]); it != std::end(resultjson["result"]); ++it) {
				nlohmann::ordered_json job = *it;
				
				trashWorker(job);
			}
			
		}else{
			logger->logError("Failed to collect workspaces from database");
		}
	}
	
}
void Job::cleanupWorker(nlohmann::ordered_json jobinfo){
	
	Plugin* plugin;

	plugin = this->getPlugin(jobinfo["module"].get<std::string>(), jobinfo["version"].get<std::string>());
	
	std::string workspacefolder = project->getWorkspaceFolder(std::stoi(jobinfo["workspaceid"].get<std::string>()));
	std::string jobfolder = workspacefolder + "/" + jobinfo["subfolder"].get<std::string>();

	nlohmann::ordered_json files = plugin->getCleanupFiles(jobfolder, jobinfo["jobtype"].get<std::string>());
	if(files.contains("files") && files["files"].size() > 0){
		
		logger->logInfo("Cleaning up " + jobfolder);
		for(auto file : files["files"]){
			std::string destinationfile = file;
			destinationfile.replace(0, workspacefolder.size(), workspacefolder + "/TRASH/cleanup/");
			std::string destinationfolder = parentPath(destinationfile);
			ensureFolder(destinationfolder);
			moveFile(file, destinationfile);			
		}
		std::uintmax_t foldersize = folderSize(workspacefolder + "/TRASH");
		
		std::string sql = "UPDATE workspaces SET trashusage=" + std::to_string(foldersize) + " WHERE id=" + jobinfo["workspaceid"].get<std::string>() + ";";
		
		if(!sqlite->query(sql)){
			logger->logError("Failed to set workspace trash usage");
		}
	}
	
	std::uintmax_t foldersize = 0;
	
	if(folderExists(jobfolder)){
		foldersize = folderSize(jobfolder);
	}
		
	std::string sql = "UPDATE jobs SET status='" + jobinfo["statusbackup"].get<std::string>() + "',statusbackup='',cleanup=TRUE,diskusage=" + std::to_string(foldersize) + " WHERE id=" + jobinfo["id"].get<std::string>() + ";"; 	
	
	if(!sqlite->query(sql)){
		logger->logError("Failed to revert job status to backup");
	}
		
}


void Job::deleteWorker(nlohmann::ordered_json jobinfo) {
	
	nlohmann::ordered_json returnjson;
	
	std::string workspacefolder = project->getWorkspaceFolder(std::stoi(jobinfo["workspaceid"].get<std::string>()));
	std::string jobfolder = workspacefolder + "/" + jobinfo["subfolder"].get<std::string>();
	std::string destinationfolder = workspacefolder + "/TRASH/" + jobinfo["subfolder"].get<std::string>();
	
	if(!folderExists(workspacefolder + "/TRASH")){
		logger->logInfo("Creating " + workspacefolder + "/TRASH");
		ensureFolder(workspacefolder + "/TRASH");
	}
	
	if(folderExists(jobfolder)){
		logger->logInfo("Moving " + jobfolder + " to " + destinationfolder);
		moveFolder(jobfolder, destinationfolder);
	}
	
	std::uintmax_t foldersize = folderSize(workspacefolder + "/TRASH");
		
	std::string sql = "UPDATE workspaces SET trashusage=" + std::to_string(foldersize) + " WHERE id=" + jobinfo["workspaceid"].get<std::string>() + ";";
		
	if(!sqlite->query(sql)){
		logger->logError("Failed to set workspace trash usage");
	}
		
	sql = "UPDATE jobs SET deleted=TRUE,diskusage=0 WHERE id=" + jobinfo["id"].get<std::string>() + ";"; 	
	
	if(!sqlite->query(sql)){
		logger->logError("Failed to set job diskusage");
	}

}

void Job::trashWorker(nlohmann::ordered_json jobinfo) {
	
	nlohmann::ordered_json returnjson;

	std::string workspacefolder = project->getWorkspaceFolder(std::stoi(jobinfo["id"].get<std::string>()));
	
	if(folderExists(workspacefolder + "/TRASH")){
		logger->logInfo("Removing " + workspacefolder + "/TRASH");
		std::uintmax_t nremoved = deleteFolder(workspacefolder + "/TRASH");
		logger->logInfo("Removed " + std::to_string(nremoved) + " files from " + workspacefolder + "/TRASH");
	}
	
	std::string sql = "UPDATE workspaces SET trashusage=0,emptytrash=FALSE WHERE id=" + jobinfo["id"].get<std::string>() + ";";
		
	if(!sqlite->query(sql)){
		logger->logError("Failed to set workspace trash usage");
	}

}*/
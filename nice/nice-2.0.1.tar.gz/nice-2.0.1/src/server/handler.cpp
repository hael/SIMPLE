#include "handler.hpp"

Handler::Handler(Core* core){
	this->core = core;
	this->core->logInfo("initialising handler library");
	this->core->logInfo("handler library initialisation complete");
}

std::string Handler::handle(nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson = {};
	
	if(!requestjson->contains("cmd")){
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd missing from request";
		return returnjson.dump();
	}

	if(!requestjson->at("cmd").is_string()){
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd is not a string";
		return returnjson.dump();
	}

	if(requestjson->at("cmd").get<std::string>() == "recentprojects"){
		returnjson = this->RecentProjects(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "listworkspaces"){
		returnjson = this->ListWorkspaces(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "listprojects"){
		returnjson = this->ListProjects(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "createworkspace"){
		returnjson = this->CreateWorkspace(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "updateworkspace"){
		returnjson = this->UpdateWorkspace(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "activeworkspace"){
		returnjson = this->ActiveWorkspace(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "activeproject"){
		returnjson = this->ActiveProject(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "listjobs"){
		returnjson = this->ListJobs(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "renamejob"){
		returnjson = this->RenameJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "cleanupjob"){
		returnjson = this->CleanupJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "deletejob"){
		returnjson = this->DeleteJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "minimisejob"){
		returnjson = this->MinimiseJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "maximisejob"){
		returnjson = this->MaximiseJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "getjobs"){
		returnjson = this->GetJobs(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "getjoboptions"){
		returnjson = this->GetJobOptions(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "createjob"){
		returnjson = this->CreateJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "createproject"){
		returnjson = this->CreateProject(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "getfoldercontents"){
		returnjson = this->GetFolderContents(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "stopjob"){
		returnjson = this->StopJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "viewjob"){
		returnjson = this->ViewJob(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "getlog"){
		returnjson = this->GetLog(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "saveselection"){
		returnjson = this->SaveSelection(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "saveonlineselection"){
		returnjson = this->SaveOnlineSelection(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "saveboxes"){
		returnjson = this->SaveBoxes(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "savepick"){
		returnjson = this->SavePick(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "createcslink"){
		returnjson = this->CRYOSPARC_link(requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "additionalboxes"){
		returnjson = this->GetAdditionalBoxes(requestjson);	
	}else{
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd is not recognised";
	}
	
	return returnjson.dump();
}

void Handler::handlestream(struct thread_data* d, nlohmann::json* requestjson){

	nlohmann::ordered_json returnjson = {};
	std::string returnstring;

	if(!requestjson->contains("cmd")){
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("cmd").is_string()){
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if (requestjson->at("cmd").get<std::string>() == "getmics"){
		this->GetMics(d, requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "getcls2D"){
		this->GetCls2D(d, requestjson);	
	}else if (requestjson->at("cmd").get<std::string>() == "getoptics"){
		this->GetOptics(d, requestjson);		
	}else if (requestjson->at("cmd").get<std::string>() == "getimages"){
		this->GetImages(d, requestjson);
	}else if (requestjson->at("cmd").get<std::string>() == "createnicepicker"){
		this->CreateNicePicker(d, requestjson);		
	}else if (requestjson->at("cmd").get<std::string>() == "shownicepicker"){
		this->ShowNicePicker(d, requestjson);	
	}else{
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: cmd is not recognised";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}
	
	while (d->queue.tail != d->queue.head) usleep(100);

	returnstring = "C";

	mg_queue_printf(&d->queue, returnstring.c_str());
}

bool Handler::updateModified(int workspaceid, int projectid){

	std::string sql = "UPDATE projects SET modified=CURRENT_TIMESTAMP WHERE id=" + std::to_string(projectid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("updateModified : sql query failed");
		return false;
	}
	
	sql = "UPDATE workspaces SET modified=CURRENT_TIMESTAMP WHERE id=" + std::to_string(workspaceid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("updateModified : sql query failed");
		return false;
	}

	return true;	
}

bool Handler::SelectWorkspace(int projectid, int workspaceid, std::string username){

	std::string sql = "SELECT selectedworkspaceid FROM users WHERE name='" + username + "';";

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("SelectWorkspace : server failed to reply: sql query failed");
		return false;
	}

	nlohmann::ordered_json selectedworkspaces;

	if(returnvals.size() == 0){
		selectedworkspaces = {};
	}else{
		if(returnvals.size() > 1){
			this->core->logError("SelectWorkspace : server failed to reply: failed to find unique selectedworkspaceid. returning 1st result");
		}
		selectedworkspaces = nlohmann::ordered_json::parse(returnvals[0]["selectedworkspaceid"]);
	}

	if(selectedworkspaces.is_structured() == false){
		selectedworkspaces = {};
	}
	
	selectedworkspaces['P' + std::to_string(projectid)] = workspaceid;

	sql = "UPDATE users SET selectedworkspaceid='" + selectedworkspaces.dump() + "' WHERE name='" + username + "';";

	if(!this->core->queryDB(sql)){
		this->core->logError("SelectWorkspace : sql query failed");
		return false;
	}

	return true;

}


nlohmann::ordered_json Handler::RecentProjects(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("RecentProjects : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("RecentProjects : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("RecentProjects : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("RecentProjects : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	returnjson["projects"] = {};
	
	std::string sql;

	if(userlevel == "admin"){
		sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE ORDER BY modified DESC LIMIT 10;";
	}else if(userlevel == "user"){
	//	sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE AND (uid=" + loginuser->uid + " OR (gid=" + loginuser->gid + " AND gidaccess=true)) ORDER BY modified DESC LIMIT " + std::to_string(limit) + ";";
	}

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("RecentProjects : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	for (auto & project : returnvals){
		nlohmann::ordered_json projectjson = {project["name"], project["id"]};
		returnjson["projects"].push_back(projectjson);
	}
	
	returnjson["success"] = true;
	
	return returnjson;
}

nlohmann::ordered_json Handler::ListWorkspaces(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("ListWorkspaces : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ListWorkspaces : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("ListWorkspaces : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ListWorkspaces : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ListWorkspaces : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("ListWorkspaces : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int projectid = requestjson->at("projectid").get<int>();
	
	std::string sql;

	if(userlevel == "admin"){
		sql = "SELECT * FROM workspaces WHERE deleted IS NOT TRUE AND project=" + std::to_string(projectid) + " ORDER BY modified;";
	}else if(userlevel == "user"){
	//	sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE AND (uid=" + loginuser->uid + " OR (gid=" + loginuser->gid + " AND gidaccess=true)) ORDER BY modified DESC LIMIT " + std::to_string(limit) + ";";
	}

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ListWorkspaces : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	returnjson["workspaces"] = {};

	for (auto & workspace : returnvals){
		nlohmann::ordered_json workspacejson = {workspace["name"], workspace["id"]};
		returnjson["workspaces"].push_back(workspacejson);
	}
	
	returnjson["success"] = true;
	
	return returnjson;
}

nlohmann::ordered_json Handler::ListProjects(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("ListProjects : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ListProjects : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ListProjects : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ListProjects : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	returnjson["projects"] = {};
	
	std::string sql;

	if(userlevel == "admin"){
		sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE;";
	}else if(userlevel == "user"){
	//	sql = "SELECT * FROM projects WHERE deleted IS NOT TRUE AND (uid=" + loginuser->uid + " OR (gid=" + loginuser->gid + " AND gidaccess=true)) ORDER BY modified DESC LIMIT " + std::to_string(limit) + ";";
	}

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ListProjects : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	for (auto & project : returnvals){
		nlohmann::ordered_json projectjson = {project["name"], project["id"], project["description"], project["created"], project["modified"]};
		returnjson["projects"].push_back(projectjson);
	}
	
	returnjson["success"] = true;
	
	return returnjson;
}

nlohmann::ordered_json Handler::CreateWorkspace(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("CreateWorkspace : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("CreateWorkspace : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspacename")){
		this->core->logError("CreateWorkspace : server failed to reply: workspacename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspacename missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("CreateWorkspace : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("CreateWorkspace : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("CreateWorkspace : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspacename").is_string()){
		this->core->logError("CreateWorkspace : server failed to reply: workspacename is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspacename is not a string";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("CreateWorkspace : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	int projectid = requestjson->at("projectid").get<int>();

	std::map<std::string, std::string> project;

	if(!this->core->getProject(projectid, user, userlevel, &project)){
		this->core->logError("CreateWorkspace : server failed to reply: failed to get project");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to get project";
		return returnjson;
	}

	if(project.find("folder") == project.end()){
		this->core->logError("CreateWorkspace : server failed to reply: folder missing from project");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : folder missing from project";
		return returnjson;
	}

	std::string workspacename(requestjson->at("workspacename").get<std::string>());
	std::string projectfolder(project["folder"]);
	std::string subfolder = workspacename;

	std::replace(subfolder.begin(), subfolder.end(), ' ', '_');

	if(folderExists(projectfolder + "/" + subfolder)){
		int count = 1;
		while(folderExists(projectfolder + "/" + subfolder + "_" + std::to_string(count))){
			count += 1;
		}
		subfolder = subfolder + "_" + std::to_string(count);
		workspacename = workspacename + " " + std::to_string(count);
	}

	if(!ensureFolder(projectfolder + '/' + subfolder)){
		this->core->logError("CreateWorkspace : server failed to reply: failed to create workspace directory");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to create workspace directory";
		return returnjson;
	}

	if(this->core->SIMPLE_enabled){
		if(!this->core->SIMPLE_workspaceInit(projectfolder + '/' + subfolder)){
			this->core->logError("CreateWorkspace : failed to initialise SIMPLE workspace");
			returnjson["success"] = false;
			returnjson["error"] = "CreateWorkspace : failed to initialise SIMPLE workspace";
			return returnjson;
		}
	}

	if(this->core->RELION_enabled){
		if(!this->core->RELION_workspaceInit(projectfolder + '/' + subfolder)){
			this->core->logError("CreateWorkspace : failed to initialise RELION workspace");
			returnjson["success"] = false;
			returnjson["error"] = "CreateWorkspace : failed to initialise RELION workspace";
			return returnjson;
		}
	}
	
	std::string sql = "INSERT INTO workspaces (name, project, subfolder) VALUES ('" + workspacename + "'," + std::to_string(projectid) + ",'" + subfolder + "');";
	
	int workspaceid = -1;

	if(!this->core->queryDB(sql, &workspaceid)){
		this->core->logError("CreateWorkspace : server failed to reply: failed to insert workspace into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to insert workspace into database";
		return returnjson;
	}

	if(workspaceid < 0){
		this->core->logError("CreateWorkspace : failed to insert workspace into database");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to insert workspace into database";
		return false;
	}

	if(!this->SelectWorkspace(projectid, workspaceid, user)){
		this->core->logError("CreateWorkspace : server failed to reply: failed to select workspace");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to select workspace";
		return returnjson;

	}

	if(!this->updateModified(workspaceid, projectid)){
		this->core->logError("CreateWorkspace : server failed to reply: failed to update modification times");
		returnjson["success"] = false;
		returnjson["error"] = "CreateWorkspace : failed to update modification times";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"] = "workspace created with id " + std::to_string(workspaceid);
	returnjson["workspacename"] = workspacename;
	returnjson["workspaceid"] = workspaceid;
	
	return returnjson;
}

nlohmann::ordered_json Handler::UpdateWorkspace(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("UpdateWorkspace : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("UpdateWorkspace : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspacename")){
		this->core->logError("UpdateWorkspace : server failed to reply: workspacename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspacename missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("UpdateWorkspace : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("UpdateWorkspace : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("UpdateWorkspace : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("UpdateWorkspace : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspacename").is_string()){
		this->core->logError("UpdateWorkspace : server failed to reply: workspacename is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspacename is not a string";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("UpdateWorkspace : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("UpdateWorkspace : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());
	std::string workspacename(requestjson->at("workspacename").get<std::string>());
	
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();

	std::string sql = "UPDATE workspaces SET name='" + workspacename + "' WHERE id=" + std::to_string(workspaceid) + ";";
	
	if(!this->core->queryDB(sql)){
		this->core->logError("UpdateWorkspace : server failed to reply: failed to modify workspace in database");
		returnjson["success"] = false;
		returnjson["error"] = "UpdateWorkspace : failed to modify workspace in database";
		return returnjson;
	}

	this->updateModified(workspaceid, projectid);
	
	returnjson["success"] = true;
	returnjson["info"] = "workspace updated";
	returnjson["workspacename"] = workspacename;
	returnjson["workspaceid"] = workspaceid;
	
	return returnjson;
}

nlohmann::ordered_json Handler::ActiveWorkspace(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("ActiveWorkspace : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("ActiveWorkspace : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("ActiveWorkspace : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("ActiveWorkspace : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("ActiveWorkspace : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("ActiveWorkspace : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	std::string user(requestjson->at("user").get<std::string>());
	std::string userlevel(requestjson->at("userlevel").get<std::string>());

	int projectid = requestjson->at("projectid").get<int>();

	if(!this->SelectProject(projectid, user)){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to activate project");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to activate project";
		return returnjson;
	}

	std::string sql = "SELECT selectedworkspaceid FROM users WHERE name='" + user + "';";

	std::vector<std::map<std::string, std::string>> returnvals;

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ActiveWorkspace : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	if(returnvals.size() != 1){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to find active workspaceid");
		returnjson["success"] = true;
		returnjson["info"] = "failed to find active workspace. please select workspace";
		return returnjson;
	}

	nlohmann::ordered_json selectedworkspaces = nlohmann::ordered_json::parse(returnvals[0]["selectedworkspaceid"]);

	if(!selectedworkspaces.is_structured()){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to find structured workspaces");
		returnjson["success"] = true;
		returnjson["info"] = "failed to find active workspace. please select workspace";
		return returnjson;
	}

	if(!selectedworkspaces.contains("P" + std::to_string(projectid))){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to find active workspace");
		returnjson["success"] = true;
		returnjson["info"] = "failed to find active workspace. please select workspace";
		return returnjson;
	}

	if(!selectedworkspaces["P" + std::to_string(projectid)].is_number_integer()){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to find active workspaceid");
		returnjson["success"] = true;
		returnjson["info"] = "failed to find active workspaceid. please select workspace";
		return returnjson;
	}

	int workspaceid = selectedworkspaces["P" + std::to_string(projectid)].get<int>();

	returnvals.clear();

	sql = "SELECT * FROM workspaces WHERE deleted IS NOT TRUE AND id=" + std::to_string(workspaceid) + ";";

	if(!this->core->queryDB(sql, &returnvals)){
		this->core->logError("ActiveWorkspace : server failed to reply: sql query failed");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: sql query failed";
		return returnjson;
	}

	if(returnvals.size() != 1){
		this->core->logError("ActiveWorkspace : server failed to reply: failed to find active workspace");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: failed to find active workspace";
		return returnjson;
	}
	
	returnjson["success"] = true;
	returnjson["info"]    = "last workspace loaded";
	returnjson["workspacename"] = returnvals[0]["name"];
	returnjson["workspaceid"]   = returnvals[0]["id"];
	
	return returnjson;
}

nlohmann::ordered_json Handler::GetFolderContents(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetFolderContents : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetFolderContents : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("folder")){
		this->core->logError("GetFolderContents : server failed to reply: folder missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetFolderContents : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetFolderContents : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("folder").is_string()){
		this->core->logError("GetFolderContents : server failed to reply: folder is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder is not a string";
		return returnjson;
	}

	std::string folder(requestjson->at("folder").get<std::string>());

	if(folder == "default") folder = this->core->defaultpath;	

	if(!folderExists(folder)){
		this->core->logError("GetFolderContents : server failed to reply: folder does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: folder does not exist";
		return returnjson;
	}

	std::vector<std::vector<std::string>> foldersarr;
	std::vector<std::vector<std::string>> filesarr;

	if(!lsDir(folder, &foldersarr, &filesarr)){
		this->core->logError("GetFolderContents : server failed to reply: permission denied");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: permission denied";
		return returnjson;
	}

	nlohmann::json files   = {}; // not ordered so alphabetical!
	nlohmann::json folders = {};

	for(auto file : filesarr){
		files[file[0]] = file;
	}

	for(auto folder : foldersarr){
		folders[folder[0]] = folder;
	}

	returnjson["success"] = true;
	returnjson["files"]   = files;
	returnjson["folders"] = folders;
	returnjson["folder"]  = folder;
	returnjson["parentfolder"]  = parentPath(folder);
	returnjson["info"]    = "folder contents loaded";

	return returnjson;

}

nlohmann::ordered_json Handler::GetLog(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetLog : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetLog : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("filename")){
		this->core->logError("GetLog : server failed to reply: filename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetLog : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetLog : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("filename").is_string()){
		this->core->logError("GetLog : server failed to reply: filename is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename is not a string";
		return returnjson;
	}

	std::string filename(requestjson->at("filename").get<std::string>());

	if(!fileExists(filename)){
		this->core->logError("GetLog : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		return returnjson;
	}

	try{
		std::ifstream logfile(filename);

		if(!logfile){
			this->core->logError("GetLog : server failed to reply: failed to open file");
			returnjson["success"] = false;
			returnjson["error"] = "server failed to reply: failed to open file";
			return returnjson;
		}

	 	std::ostringstream logfiless;
	    
	    logfiless << logfile.rdbuf();

		returnjson["logtext"] = logfiless.str();
		
		logfile.close();

		returnjson["success"] = true;
		returnjson["info"]    = "log contents loaded";
	}catch(...){
		returnjson["success"] = false;
		returnjson["info"]    = "failed to retrieve log contents";
	}

	return returnjson;

}

nlohmann::ordered_json Handler::SaveSelection(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("SaveSelection : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("SaveSelection : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("module")){
		this->core->logError("SaveSelection : server failed to reply: filename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename missing from request";
		return returnjson;
	}

	if(!requestjson->contains("version")){
		this->core->logError("SaveSelection : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		return returnjson;
	}

	if(!requestjson->contains("datatype")){
		this->core->logError("SaveSelection : server failed to reply: datatype missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: datatype missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("SaveSelection : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("parentid")){
		this->core->logError("SaveSelection : server failed to reply: parentid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("SaveSelection : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("selection")){
		this->core->logError("SaveSelection : server failed to reply: selection missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selection missing from request";
		return returnjson;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("SaveSelection : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		return returnjson;
	}

	if(!requestjson->contains("selectionmap")){
		this->core->logError("SaveSelection : server failed to reply: selectionmap missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selectionmap missing from request";
		return returnjson;
	}

	if(!requestjson->contains("nall")){
		this->core->logError("SaveSelection : server failed to reply: nall missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: nall missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("SaveSelection : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("SaveSelection : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("SaveSelection : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("SaveSelection : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		return returnjson;
	}

	if(!requestjson->at("datatype").is_string()){
		this->core->logError("SaveSelection : server failed to reply: datatype is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: datatype is not a string";
		return returnjson;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		return returnjson;
	}

	if(!requestjson->at("parentid").is_number_integer()){
		this->core->logError("SaveSelection : server failed to reply: parentid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("SaveSelection : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("SaveSelection : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("nall").is_number_integer()){
		this->core->logError("SaveSelection : server failed to reply: nall is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: nall is not an integer";
		return returnjson;
	}

	if(!requestjson->at("selection").is_array()){
		this->core->logError("SaveSelection : server failed to reply: selection is not an array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selection is not an array";
		return returnjson;
	}

	if(!requestjson->at("selectionmap").is_array()){
		this->core->logError("SaveSelection : server failed to reply: selectionmap is not an array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selectionmap is not an array";
		return returnjson;
	}

	std::string module   = requestjson->at("module").get<std::string>();
	std::string version  = requestjson->at("version").get<std::string>();
	std::string datatype = requestjson->at("datatype").get<std::string>();
	std::string starfile = requestjson->at("starfile").get<std::string>();

	int parentid    = requestjson->at("parentid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();
	int nall 		= requestjson->at("nall").get<int>();

	if(module == "SIMPLE"){
		if(this->core->SIMPLE_selectionInit(requestjson)){
			returnjson = this->CreateJob(requestjson);
		}else{
			returnjson["success"] = false;
			returnjson["error"] = "failed to initialise selection job";
			return returnjson;
		}
		
	}else if(module == "RELION"){
		if(this->core->RELION_selectionInit(requestjson)){
			returnjson = this->CreateJob(requestjson);
		}else{
			returnjson["success"] = false;
			returnjson["error"] = "failed to initialise selection job";
			return returnjson;
		}
		
	}
	
	if(returnjson["success"]) returnjson["info"] = "selection job started";

	return returnjson;

}

nlohmann::ordered_json Handler::SaveOnlineSelection(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("SaveOnlineSelection : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("SaveOnlineSelection : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("module")){
		this->core->logError("SaveOnlineSelection : server failed to reply: filename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename missing from request";
		return returnjson;
	}

	if(!requestjson->contains("version")){
		this->core->logError("SaveOnlineSelection : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		return returnjson;
	}

	if(!requestjson->contains("datatype")){
		this->core->logError("SaveOnlineSelection : server failed to reply: datatype missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: datatype missing from request";
		return returnjson;
	}

	if(!requestjson->contains("projectid")){
		this->core->logError("SaveOnlineSelection : server failed to reply: projectid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("parentid")){
		this->core->logError("SaveOnlineSelection : server failed to reply: parentid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("workspaceid")){
		this->core->logError("SaveOnlineSelection : server failed to reply: workspaceid missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid missing from request";
		return returnjson;
	}

	if(!requestjson->contains("selection")){
		this->core->logError("SaveOnlineSelection : server failed to reply: selection missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selection missing from request";
		return returnjson;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("SaveOnlineSelection : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		return returnjson;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		return returnjson;
	}

	if(!requestjson->at("datatype").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: datatype is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: datatype is not a string";
		return returnjson;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("SaveOnlineSelection : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		return returnjson;
	}

	if(!requestjson->at("parentid").is_number_integer()){
		this->core->logError("SaveOnlineSelection : server failed to reply: parentid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: parentid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("projectid").is_number_integer()){
		this->core->logError("SaveOnlineSelection : server failed to reply: projectid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: projectid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("workspaceid").is_number_integer()){
		this->core->logError("SaveOnlineSelection : server failed to reply: workspaceid is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: workspaceid is not an integer";
		return returnjson;
	}

	if(!requestjson->at("selection").is_array()){
		this->core->logError("SaveOnlineSelection : server failed to reply: selection is not an array");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: selection is not an array";
		return returnjson;
	}

	std::string module   = requestjson->at("module").get<std::string>();
	std::string version  = requestjson->at("version").get<std::string>();
	std::string datatype = requestjson->at("datatype").get<std::string>();
	std::string starfile = requestjson->at("starfile").get<std::string>();

	int parentid    = requestjson->at("parentid").get<int>();
	int projectid   = requestjson->at("projectid").get<int>();
	int workspaceid = requestjson->at("workspaceid").get<int>();

	if(module == "SIMPLE"){
		if(this->core->SIMPLE_onlineSelection(requestjson)){
			returnjson["success"] = true;
		}else{
			returnjson["success"] = false;
			returnjson["error"] = "failed to initialise selection job";
			return returnjson;
		}
		
	}
	
	if(returnjson["success"]) returnjson["info"] = "selection started";

	return returnjson;

}

nlohmann::ordered_json Handler::GetAdditionalBoxes(nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetAdditionalBoxes : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		return returnjson;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetAdditionalBoxes : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		return returnjson;
	}

	if(!requestjson->contains("filename")){
		this->core->logError("GetAdditionalBoxes : server failed to reply: filename missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename missing from request";
		return returnjson;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetAdditionalBoxes : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		return returnjson;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetAdditionalBoxes : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		return returnjson;
	}

	if(!requestjson->at("filename").is_string()){
		this->core->logError("GetAdditionalBoxes : server failed to reply: filename is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: filename is not a string";
		return returnjson;
	}

	std::string filename = requestjson->at("filename").get<std::string>();

	if(fileExists(filename)){
		returnjson["coordinates"] = readHeaderlessSTAR(filename)["data"];
		returnjson["success"] = true;
		returnjson["info"] = "loaded additional boxes";
	}else{
		this->core->logError("GetAdditionalBoxes : " + filename + " does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
	}

	return returnjson;

}

void Handler::GetMics(struct thread_data* d, nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	std::string returnstring;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetMics : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetMics : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("GetMics : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("module")){
		this->core->logError("GetMics : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("GetMics : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("jobtype")){
		this->core->logError("GetMics : server failed to reply: jobtype missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetMics : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetMics : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("GetMics : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("GetMics : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("GetMics : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("jobtype").is_string()){
		this->core->logError("GetMics : server failed to reply: jobtype is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	std::string filename(requestjson->at("starfile").get<std::string>());
	std::string module  (requestjson->at("module").get<std::string>());
	std::string version (requestjson->at("version").get<std::string>());
	std::string jobtype (requestjson->at("jobtype").get<std::string>());

	if(!fileExists(filename)){
		this->core->logError("GetMics : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	nlohmann::ordered_json micsstar = readSTAR(filename);

	nlohmann::ordered_json globaljson;

	if(micsstar.contains("data_optics") && micsstar["data_optics"].is_object() 
    && micsstar["data_optics"].contains("loop") && micsstar["data_optics"]["loop"].is_array() ){
		globaljson["optics"] = micsstar["data_optics"]["loop"];
	}

	if(micsstar.contains("data_micrographs") && micsstar["data_micrographs"].is_object() 
    && micsstar["data_micrographs"].contains("loop") && micsstar["data_micrographs"]["loop"].is_array() 
    && micsstar["data_micrographs"]["loop"].size() > 0){
    	globaljson["keys"] = {};
    	for (auto& el : micsstar["data_micrographs"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}

	globaljson["nmics"] = micsstar["data_micrographs"]["loop"].size();

	if(module == "SIMPLE"){
		int nptcls = this->core->SIMPLE_micsptcls(version, &micsstar);
		if(nptcls > 0){
			globaljson["nptcls"] = nptcls;
		}
		int nmicsall = this->core->SIMPLE_micsall(version, &micsstar);
		if(nmicsall > 0){
			globaljson["nall"] = nmicsall;
		}
	}

	globaljson["paths"] = {};

	globaljson["images"] = {};

	if(module == "SIMPLE"){
		this->core->SIMPLE_images(version, jobtype, &globaljson);
	}

	returnstring = "M";

	mg_queue_printf(&d->queue, returnstring.c_str());

	char *queueptr;
	size_t msglen;

	std::vector<std::uint8_t> msgpack = nlohmann::json::to_msgpack(globaljson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();

	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	int chunksize = 50;

	int miccount  = 0;

	nlohmann::ordered_json pagejson;

	pagejson["startit"] = {};
	pagejson["paths"] = {};
	pagejson["data"] = {};

	for(auto mic : micsstar["data_micrographs"]["loop"]){

		if(miccount > 0 && miccount%chunksize == 0){
			pagejson["paths"] = globaljson["paths"];
			pagejson["endit"] = miccount;
			msgpack = nlohmann::json::to_msgpack(pagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();

			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);
			
			pagejson["data"] = {};
			pagejson["paths"] = {};
		}

		for (auto& el : mic.items()){
			
			std::string key = el.key();
			std::string value = el.value();

			if(globaljson["keys"][key] == "integer"){
				pagejson["data"][key] += std::stoi(value);
			}else if(globaljson["keys"][key] == "float"){
				pagejson["data"][key] += std::stof(value);
			}else{ //string
				if(value[0] != '/'){
					value = parentPath(parentPath(filename)) + "/" + value;
				}
				std::string parentpath = parentPath(value);
			 	auto findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				if(findpath == globaljson["paths"].end()){
					globaljson["paths"] += parentpath;
					findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				}

				nlohmann::ordered_json stringpath;
				stringpath["arr"] = {};
				stringpath["arr"] += findpath - globaljson["paths"].begin();
				stringpath["arr"] += basename(value);
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;

				if(module == "SIMPLE"){
					this->core->SIMPLE_paths(version, jobtype, key, stringpath, &pagejson["data"]);
				}else{
					pagejson["data"][key] += stringpath["arr"];
				}
			}

		}

		miccount++;
	}

	pagejson["paths"] = globaljson["paths"];
	pagejson["endit"] = miccount;

	msgpack = nlohmann::json::to_msgpack(pagejson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	returnjson["success"] = true;
	returnjson["info"]    = "micrographs contents loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}

void Handler::GetCls2D(struct thread_data* d, nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	std::string returnstring;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetCls2D : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetCls2D : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("GetCls2D : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("module")){
		this->core->logError("GetCls2D : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("GetCls2D : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("jobtype")){
		this->core->logError("GetCls2D : server failed to reply: jobtype missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetCls2D : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetCls2D : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("GetCls2D : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("GetCls2D : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("GetCls2D : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("jobtype").is_string()){
		this->core->logError("GetCls2D : server failed to reply: jobtype is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	std::string filename(requestjson->at("starfile").get<std::string>());
	std::string module  (requestjson->at("module").get<std::string>());
	std::string version (requestjson->at("version").get<std::string>());
	std::string jobtype (requestjson->at("jobtype").get<std::string>());

	if(!fileExists(filename)){
		this->core->logError("GetCls2D : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	nlohmann::ordered_json cls2Dstar = readSTAR(filename);

	if(cls2Dstar.contains("data_model_classes") && cls2Dstar["data_model_classes"].is_object()){
		cls2Dstar["data_clusters"] = cls2Dstar["data_model_classes"];
		cls2Dstar.erase("data_model_classes");
	}

	nlohmann::ordered_json globaljson;

	if(cls2Dstar.contains("data_clusters") && cls2Dstar["data_clusters"].is_object() 
    && cls2Dstar["data_clusters"].contains("loop") && cls2Dstar["data_clusters"]["loop"].is_array() 
    && cls2Dstar["data_clusters"]["loop"].size() > 0){
    	globaljson["keys"] = {};
    	for (auto& el : cls2Dstar["data_clusters"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}
	/*// relion
	else if(cls2Dstar.contains("data_model_classes") && cls2Dstar["data_model_classes"].is_object()
	&& cls2Dstar["data_model_classes"].contains("loop") && cls2Dstar["data_model_classes"]["loop"].is_array() 
    && cls2Dstar["data_model_classes"]["loop"].size() > 0){
    	globaljson["keys"] = {};
    	for (auto& el : cls2Dstar["data_model_classes"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}*/

	globaljson["ncls"] = cls2Dstar["data_clusters"]["loop"].size();

	if(module == "SIMPLE"){
		int nptcls = this->core->SIMPLE_cls2Dptcls(version, &cls2Dstar);
		if(nptcls > 0){
			globaljson["nptcls"] = nptcls;
		}
		int nclsall = this->core->SIMPLE_cls2Dclsall(version, &cls2Dstar);
		if(nclsall > 0){
			globaljson["nall"] = nclsall;
		}
	}else if(module == "RELION"){
		int nptcls = this->core->RELION_cls2Dptcls(version, filename, &cls2Dstar);
		if(nptcls > 0){
			globaljson["nptcls"] = nptcls;
		}
		int nclsall = this->core->RELION_cls2Dclsall(version, &cls2Dstar);
		if(nclsall > 0){
			globaljson["nall"] = nclsall;
		}
	}

	globaljson["paths"] = {};

	globaljson["images"] = {};

	if(module == "SIMPLE"){
		this->core->SIMPLE_images(version, jobtype, &globaljson);
	}else if(module == "RELION"){
		this->core->RELION_images(version, jobtype, &globaljson);
	}

	returnstring = "M";

	mg_queue_printf(&d->queue, returnstring.c_str());

	char *queueptr;
	size_t msglen;

	std::vector<std::uint8_t> msgpack = nlohmann::json::to_msgpack(globaljson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();

	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	int chunksize = 1000;

	int clscount  = 0;

	nlohmann::ordered_json pagejson;

	pagejson["startit"] = {};
	pagejson["paths"] = {};
	pagejson["data"] = {};

	for(auto cls : cls2Dstar["data_clusters"]["loop"]){

		if(clscount > 0 && clscount%chunksize == 0){
			pagejson["paths"] = globaljson["paths"];
			msgpack = nlohmann::json::to_msgpack(pagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();

			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);
			pagejson["endit"] = clscount;
			pagejson["data"] = {};
			pagejson["paths"] = {};
		}

		for (auto& el : cls.items()){
			
			std::string key = el.key();
			std::string value = el.value();

			if(globaljson["keys"][key] == "integer"){
				pagejson["data"][key] += std::stoi(value);
			}else if(globaljson["keys"][key] == "float"){
				pagejson["data"][key] += std::stof(value);
			}else{ //string
				auto atpath = value.find('@');
				int stkid = 0;
				if(atpath != std::string::npos){
					stkid = std::stoi(value.substr(0, atpath)) - 1;
					value = value.substr(atpath + 1);
				}
				if(value[0] != '/'){
					value = parentPath(parentPath(filename)) + "/" + value;
				}
				
				std::string parentpath = parentPath(value);
			 	auto findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				if(findpath == globaljson["paths"].end()){
					globaljson["paths"] += parentpath;
					findpath = std::find(globaljson["paths"].begin(), globaljson["paths"].end(), parentpath);
				}

				nlohmann::ordered_json stringpath;
				stringpath["arr"] = {};
				stringpath["arr"] += findpath - globaljson["paths"].begin();
				stringpath["arr"] += basename(value);
				stringpath["arr"] += stkid;
				stringpath["arr"] += 0;
				stringpath["arr"] += 0;

				if(module == "SIMPLE"){
					this->core->SIMPLE_paths(version, jobtype, key, stringpath, &pagejson["data"]); // Needs Sort
				}else{
					pagejson["data"][key] += stringpath["arr"];
				}
			}

		}

		clscount++;
	}

	pagejson["paths"] = globaljson["paths"];
	pagejson["endit"] = clscount;

	msgpack = nlohmann::json::to_msgpack(pagejson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	returnjson["success"] = true;
	returnjson["info"]    = "2D clusters contents loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}

void Handler::GetOptics(struct thread_data* d, nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	std::string returnstring;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetOptics : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetOptics : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("starfile")){
		this->core->logError("GetOptics : server failed to reply: starfile missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("module")){
		this->core->logError("GetOptics : server failed to reply: module missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("version")){
		this->core->logError("GetOptics : server failed to reply: version missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("jobtype")){
		this->core->logError("GetOptics : server failed to reply: jobtype missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetOptics : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetOptics : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("starfile").is_string()){
		this->core->logError("GetOptics : server failed to reply: starfile is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: starfile is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("module").is_string()){
		this->core->logError("GetOptics : server failed to reply: module is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: module is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("version").is_string()){
		this->core->logError("GetOptics : server failed to reply: version is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: version is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("jobtype").is_string()){
		this->core->logError("GetOptics : server failed to reply: jobtype is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: jobtype is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	std::string filename(requestjson->at("starfile").get<std::string>());
	std::string module  (requestjson->at("module").get<std::string>());
	std::string version (requestjson->at("version").get<std::string>());
	std::string jobtype (requestjson->at("jobtype").get<std::string>());

	if(!fileExists(filename)){
		this->core->logError("GetOptics : server failed to reply: file does not exist");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: file does not exist";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	nlohmann::ordered_json opticsstar = readSTAR(filename);

	nlohmann::ordered_json globaljson;

	if(opticsstar.contains("data_optics") && opticsstar["data_optics"].is_object() 
    && opticsstar["data_optics"].contains("loop") && opticsstar["data_optics"]["loop"].is_array() ){
    	globaljson["optics"] = opticsstar["data_optics"]["loop"];
    	globaljson["keys"] = {};
    	for (auto& el : opticsstar["data_optics"]["loop"][0].items()){

    		std::string key   = el.key();
    		std::string value = el.value();

    		int keytype = 0; //0 int, 1 float, 1 < string 

    		for (char const &ch : value) {
       			if (std::isdigit(ch) != 0 || ch == '-') {
          			keytype += 0;
   				}else{
   					keytype += 1;
   				}
 			}

 			if(keytype == 0){
				globaljson["keys"][key] = "integer";
 			}else if(keytype == 1){
 				globaljson["keys"][key] = "float";
 			}else{
 				globaljson["keys"][key] = "string";
 			}
    	}
	}

	globaljson["noptics"] = opticsstar["data_optics"]["loop"].size();

	returnstring = "M";

	mg_queue_printf(&d->queue, returnstring.c_str());

	char *queueptr;
	size_t msglen;

	std::vector<std::uint8_t> msgpack = nlohmann::json::to_msgpack(globaljson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();

	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

	nlohmann::ordered_json pagejson;

	pagejson["data"] = {};

	for(auto plotgroup : opticsstar.items()){
		std::string groupname = plotgroup.key();
		if(groupname.find("data_tiltgroup_") != std::string::npos){
			nlohmann::ordered_json groupdata = plotgroup.value();
			if(groupdata.contains("loop") && groupdata["loop"].is_array() && groupdata["loop"].size() > 0){
				if(groupdata["loop"][0].contains("_splBeamshiftX") &&
				   groupdata["loop"][0].contains("_splBeamshiftY") &&
				   groupdata["loop"][0].contains("_splTiltGroup")){
				   	nlohmann::ordered_json groupjson = {};
					groupjson["groupid"] = std::stoi(groupdata["loop"][0]["_splTiltGroup"].get<std::string>());
					groupjson["points"] = {};
					for(auto groupline : groupdata["loop"]){
						nlohmann::ordered_json xyjson = {};
						float shiftx = std::stof(groupline["_splBeamshiftX"].get<std::string>());
						float shifty = std::stof(groupline["_splBeamshiftY"].get<std::string>());
						xyjson["x"] = shiftx;
						xyjson["y"] = shifty;
						groupjson["points"] += xyjson;
					}
					msgpack = nlohmann::json::to_msgpack(groupjson);
					msgpack.insert(msgpack.begin(), 'P');
					msglen = msgpack.size();

					while (d->queue.tail != d->queue.head) usleep(100);
					mg_queue_book(&d->queue, &queueptr, msglen);
					memcpy(queueptr, &msgpack[0], msglen);
					mg_queue_add(&d->queue, msglen);
					
				}
			}
		}
	}

	returnjson["success"] = true;
	returnjson["info"]    = "micrographs contents loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}

void Handler::GetImages(struct thread_data* d, nlohmann::json* requestjson){
	
	nlohmann::ordered_json returnjson;
	std::string returnstring;
	
	if(!requestjson->contains("user")){
		this->core->logError("GetImages : server failed to reply: user missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("userlevel")){
		this->core->logError("GetImages : server failed to reply: userlevel missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("images")){
		this->core->logError("GetImages : server failed to reply: images missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: images missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->contains("targetheight")){
		this->core->logError("GetImages : server failed to reply: targetheight missing from request");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: targetheight missing from request";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("user").is_string()){
		this->core->logError("GetImages : server failed to reply: user is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: user is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("userlevel").is_string()){
		this->core->logError("GetImages : server failed to reply: userlevel is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: userlevel is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("images").is_array()){
		this->core->logError("GetImages : server failed to reply: images is not a string");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: images is not a string";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	if(!requestjson->at("targetheight").is_number_integer()){
		this->core->logError("GetImages : server failed to reply: targetheight is not an integer");
		returnjson["success"] = false;
		returnjson["error"] = "server failed to reply: targetheight is not an integer";
		returnstring = "P" + returnjson.dump();
		mg_queue_printf(&d->queue, returnstring.c_str());
		returnstring = "C";
		mg_queue_printf(&d->queue, returnstring.c_str());
		return;
	}

	int targetheight = requestjson->at("targetheight").get<int>();

	returnstring = "M";

	mg_queue_printf(&d->queue, returnstring.c_str());

	char *queueptr;
	size_t msglen;
	std::vector<std::uint8_t> msgpack;

	nlohmann::ordered_json imagejson;

	for(auto imageit : requestjson->at("images")){
		nlohmann::ordered_json image = imageit;
		imagejson = {};
		if(image.is_array() && image.size() == 6){
			Imager* imager = new Imager(this->core);
			if(!imager->read(image[1].get<std::string>(), targetheight, image[2].get<int>(), image[3].get<int>(), image[4].get<int>())){
				this->core->logError("GetImages : failed to image " + image[1].get<std::string>());
				delete imager;
				continue;
			}
			if(!imager->reduceSize()){
				this->core->logError("GetImages : failed to reduce size " + image[1].get<std::string>());
				delete imager;
				continue;
			}
			if(!imager->maxMinNormalize()){
				this->core->logError("GetImages : failed to normalise " + image[1].get<std::string>());
				delete imager;
				continue;
			}
			imagejson["image"] = imager->pack();
			imagejson["id"]    = image[0].get<std::string>(); 
			std::string coordinates = image[5].get<std::string>();

			if(coordinates != ""){
				std::vector<std::string> coordsarray = lineArray(coordinates, ',');
				for(auto coords : coordsarray){
					if(fileExists(coords)){	
						imagejson["image"]["coordinates"] = readHeaderlessSTAR(coords)["data"];
						break;
					}
				}
			}

			msgpack = nlohmann::json::to_msgpack(imagejson);
			msgpack.insert(msgpack.begin(), 'P');
			msglen = msgpack.size();

			while (d->queue.tail != d->queue.head) usleep(100);
			mg_queue_book(&d->queue, &queueptr, msglen);
			memcpy(queueptr, &msgpack[0], msglen);
			mg_queue_add(&d->queue, msglen);

			delete imager;
		}
	}

	returnjson["success"] = true;
	returnjson["info"]    = "images loaded";

	msgpack = nlohmann::json::to_msgpack(returnjson);
	msgpack.insert(msgpack.begin(), 'P');
	msglen = msgpack.size();
	while (d->queue.tail != d->queue.head) usleep(100);
	mg_queue_book(&d->queue, &queueptr, msglen);
	memcpy(queueptr, &msgpack[0], msglen);
	mg_queue_add(&d->queue, msglen);

}
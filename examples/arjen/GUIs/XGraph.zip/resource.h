//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XGraph.rc
//
#define IDR_MENU_MAIN                   101
#define IDD_DIALOG_ABOUT                102
#define IDI_ICON_MAIN                   103
#define IDD_FUNCTION                    104
#define IDR_ACCELTABLE                  105
#define IDC_FORMULA                     1001
#define IDC_X0                          1002
#define IDC_X1                          1003
#define IDC_LOCK                        1005
#define IDC_CUSTOM1                     1006
#define IDM_FILE_CLOSE                  40001
#define IDM_HELP_ABOUT                  40002
#define IDM_FILE_SAVEAS                 40003
#define IDM_COPY_WMF                    40004
#define IDM_COPY_BMP                    40005
#define IDM_VIEW_GRID                   40006
#define IDM_BK_COLOR                    40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

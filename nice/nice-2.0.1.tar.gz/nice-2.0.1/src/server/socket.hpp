#ifndef SOCKET
#define SOCKET

#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int SKTBUFFSIZE = 32767;

static bool send_socket_msg(std::string request, std::string& response){

    int status, valread, client_fd;
    struct sockaddr_in serv_addr;

    char buffer[SKTBUFFSIZE] = { 0 };

    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return false;
    }
 
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8090);
 
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        printf("\nInvalid address/ Address not supported \n");
        return false;
    }
 
    if ((status = connect(client_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr))) < 0) {
        printf("\nConnection Failed \n");
        return false;
    }

    send(client_fd, request.c_str(), request.size(), 0);
    printf("socket message sent\n");
    valread = read(client_fd, buffer, SKTBUFFSIZE - 1); // subtract 1 for the null terminator at the end
    close(client_fd);

    if(valread <= 0){
    	printf("\nFailed to read response\n");
    	return false;
    }else if (valread > SKTBUFFSIZE){
    	printf("\nResponse larger than buffer\n");
    	return false;
    }

    printf("%s\n", buffer);
    response = std::string(buffer);
    return true;
}


#endif
#include "nice.hpp"

Core* 	 core;

nlohmann::ordered_json users;

static struct user getUser(struct mg_http_message *hm) {
    char user[256], pass[256];
    struct user u;
    mg_http_creds(hm, user, sizeof(user), pass, sizeof(pass));

    if (user[0] != '\0'){
       std::string userstr(user);
       if(!users.contains(userstr)){
            nlohmann::ordered_json usercreds;
            if(!core->getUserCreds(userstr, &usercreds)){
                core->logError("Failed login attempt for user " + userstr);
                return u;
            }
            users[userstr] = usercreds;
       }
       if(!users.contains(userstr)){
            core->logError("Failed login attempt for user " + userstr + ". not in database");
            return u;
       }
       if(pass[0] != '\0'){
            // Both user and password are set, search by user/password
            std::string passstr(pass);
            if(users[userstr].contains("name")  && users[userstr]["name"].is_string()
             &&users[userstr].contains("level") && users[userstr]["level"].is_string()
             &&users[userstr].contains("pass")  && users[userstr]["pass"].is_string()
             &&users[userstr].contains("token") && users[userstr]["token"].is_string()){

                if(users[userstr]["name"].get<std::string>() == userstr && users[userstr]["pass"].get<std::string>() == passstr){
                    u.name = users[userstr]["name"].get<std::string>();
                    u.pass = users[userstr]["pass"].get<std::string>();
                    u.token = users[userstr]["token"].get<std::string>();
                    u.level = users[userstr]["level"].get<std::string>();
                    return u;
                }else{
                    core->logError("Failed login attempt for user " + userstr + ". incorrect username/password");
                    return u;
                }
            }else{
               core->logError("Failed login attempt for user " + userstr + ". not in users"); 
               return u;
            }
       }else{
            core->logError("Failed login attempt for user " + userstr + ". missing password");
            return u;
        }
    } else if (user[0] == '\0') {
        // Only password is set, search by token
        std::string tokenstr(pass);
        for(auto userjson : users){
            if(userjson.contains("token") && userjson["token"].is_string() && userjson["token"].get<std::string>() == tokenstr){
                u.name = userjson["name"].get<std::string>();
                u.pass = userjson["pass"].get<std::string>();
                u.token = userjson["token"].get<std::string>();
                u.level = userjson["level"].get<std::string>();
                return u;
            }
        }
        core->logError("Failed login attempt with token " + tokenstr + ". no credentials");
        return u;
    }

    core->logError("Failed login attempt. no credentials");

    return u;

}

static void start_thread(void *(*f)(void *), void *p) {
    pthread_t thread_id = (pthread_t) 0;
    pthread_attr_t attr;
    (void) pthread_attr_init(&attr);
    (void) pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&thread_id, &attr, f, p);
    pthread_attr_destroy(&attr);
}

static void* worker_thread(void* param) {
	Handler* handler = new Handler(core);
    struct thread_data* d = (struct thread_data*) param;
    int buffersize = 100000000;
    char* buf = new char[buffersize];
    mg_queue_init(&d->queue, buf, buffersize);  // Init queue
    // Send a response to the connection
    if (d->body.len == 0) {
        mg_queue_printf(&d->queue, "Send me POST data");
    } else {
		std::string requeststring(d->body.ptr, d->body.len);
		nlohmann::json requestjson = nlohmann::json::parse(requeststring);
        std::string username(d->user->name);
        std::string userlevel(d->user->level);
        requestjson["user"] = username;
        requestjson["userlevel"] = userlevel;
		std::string returnstring = 'S' + handler->handle(&requestjson);
        if(returnstring.length() < buffersize){
			mg_queue_printf(&d->queue, returnstring.c_str());
		}else{
			nlohmann::json errorjson;
			core->logError("message failed to send: larger than buffer");
			errorjson["success"] = false;
			errorjson["error"] = "server failed to reply: message larger than buffer";
			returnstring = errorjson.dump();
			mg_queue_printf(&d->queue, returnstring.c_str());
		}
        free((char *) d->body.ptr);
    }

    // Wait until connection reads our message, then it is safe to quit
    while (d->queue.tail != d->queue.head) usleep(1000);
    MG_INFO(("done, cleaning up..."));
    free(d);
    delete handler;
    delete [] buf;
    return NULL;
}

static void* worker_thread_stream(void* param) {
    Handler* handler = new Handler(core);
    struct thread_data* d = (struct thread_data*) param;
    //char buf[1000000];  // On-stack buffer for the message queue
    char* buf = new char[100000000];
    //mg_queue_init(&d->queue, buf, sizeof(buf));  // Init queue
    mg_queue_init(&d->queue, buf, 100000000);  // Init queue
    // Send a response to the connection
    if (d->body.len == 0) {
        mg_queue_printf(&d->queue, "Send me POST data");
    } else {
        std::string requeststring(d->body.ptr, d->body.len);
        free((char *) d->body.ptr);
        nlohmann::json requestjson = nlohmann::json::parse(requeststring);
        std::string username(d->user->name);
        std::string userlevel(d->user->level);
        requestjson["user"] = username;
        requestjson["userlevel"] = userlevel;
        handler->handlestream(d, &requestjson);
    }

    // Wait until connection reads our message, then it is safe to quit
    while (d->queue.tail != d->queue.head) usleep(1000);
    char *queueptr;
    while(mg_queue_next(&d->queue, &queueptr) > 0) usleep(100);
    MG_INFO(("done, cleaning up..."));
    free(d);
    delete handler;
    delete [] buf;
    return NULL;
}

// HTTP request callback
static void fn(struct mg_connection* c, int ev, void* ev_data, void* fn_data) {
    if (ev == MG_EV_HTTP_MSG) {
        // Received HTTP request. Allocate thread data and spawn a worker thread
        struct mg_http_message* hm = (struct mg_http_message*) ev_data;
        struct user u = getUser(hm);
        if(u.name == "" && mg_http_match_uri(hm, "/api/#")){
            mg_printf(c, "%s", "HTTP/1.1 403 Denied\r\nContent-Length: 0\r\n\r\n");
        }else if (mg_http_match_uri(hm, "/api/login")){
            mg_http_reply(c, 200, "Content-Type: application/json\r\n", "{%m:%m,%m:%m}\n", MG_ESC("user"), MG_ESC(u.name.c_str()), MG_ESC("token"), MG_ESC(u.token.c_str()));
        }else if (mg_http_match_uri(hm, "/api/handler")){
            struct thread_data* d = (struct thread_data*) calloc(1, sizeof(*d));
            d->body = mg_strdup(hm->body);   // Pass received body to the worker
            d->user = &u;   // Pass pointer to user to the worker
            start_thread(worker_thread, d);  // Start a thread
            *(void **) c->data = d;          // Memorise data pointer in c->data
        }else if (mg_http_match_uri(hm, "/api/handlerstream")){
            struct thread_data* d = (struct thread_data*) calloc(1, sizeof(*d));
            d->body = mg_strdup(hm->body);   // Pass received body to the worker
            d->user = &u;   // Pass pointer to user to the worker
            start_thread(worker_thread_stream, d);  // Start a thread
            *(void **) c->data = d;          // Memorise data pointer in c->data
        }else{
		    struct mg_http_serve_opts opts = {
                .root_dir = core->publicdir.c_str(),
                .mime_types = "wasm=application/wasm"};
		    mg_http_serve_dir(c, hm, &opts);
        }
    
    } else if (ev == MG_EV_POLL) {
        // Poll event. Delivered to us every mg_mgr_poll interval or faster
        struct thread_data *d = *(struct thread_data **) c->data;
        size_t len;
        char *buf;
        // Check if we have a message from the worker
        
        if (d != NULL && (len = mg_queue_next(&d->queue, &buf)) > 0) {

            if(buf[0] == 'S'){
                // Got message from worker. Send a response and cleanup
                mg_http_reply(c, 200, "Content-Type: application/json\r\n", "%.*s\n", (int) len - 1 , &buf[1]);
                mg_queue_del(&d->queue, len);  // Delete message
                *(void **) c->data = NULL;     // Forget about thread data
            }else if(buf[0] == 'M'){
                // Got message from worker. Send a response and cleanup
                mg_printf(c,"%s", "HTTP/1.1 200 OK\r\n""Cache-Control: no-cache\r\n"
                                  "Pragma: no-cache\r\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\r\n" 
                                  "Content-Type:application/octet-stream\r\nTransfer-Encoding: chunked\r\n"
                                  "\r\n");
                mg_queue_del(&d->queue, len);  // Delete message
            }else if(buf[0] == 'P'){

                z_stream zs;
                zs.zalloc = Z_NULL;
                zs.zfree = Z_NULL;
                zs.opaque = Z_NULL;
    
                deflateInit2(&zs, Z_DEFAULT_COMPRESSION, Z_DEFLATED, 15 | 16, 8, Z_DEFAULT_STRATEGY);
                
                zs.next_in = (unsigned char*) &buf[1];
                zs.avail_in = len - 1;

                int maxbufsize = deflateBound(&zs, len - 1);
                
                unsigned char* compressbuf = new unsigned char[maxbufsize];
                
                zs.avail_out = maxbufsize;
                zs.next_out = compressbuf;
                
                deflate(&zs, Z_FINISH);
                deflateEnd(&zs);
                
                int compressedsize = zs.total_out;

                std::cout << "COMPRESSION " << len - 1 << " " << compressedsize << std::endl;
                mg_http_write_chunk(c, (char*) &compressbuf[0], compressedsize);
                mg_queue_del(&d->queue, len);
                delete [] compressbuf;
            }else if(buf[0] == 'C'){
                mg_http_printf_chunk(c, ""); 
                mg_queue_del(&d->queue, len);  // Delete message
                c->is_draining = 1;
                *(void **) c->data = NULL;     // Forget about thread data
            }

        }
    }
    (void) fn_data;
}

int main(int argc, char* argv[]) {

    bool local = true;

    if(argc > 1){
        if(std::string(argv[1]) == "daemon"){
            local = false;
        }else{
            std::cout << "unknown argument " << argv[1] << std::endl;
            return 1;
        }
    }

    char self[2048] = { 0 };
    int nchar = readlink("/proc/self/exe", self, sizeof self);
    if (nchar < 0 || nchar >= sizeof self){
        std::cout << "Failed to obtain executable directory" << std::endl;
        return 1;
    }

    std::string executable(self);

    std::string bindir = std::string(weakly_canonical(std::filesystem::path(executable)).parent_path());

    core = new Core(bindir, local);
    
    std::string httpport;
    if(!core->getConfigValue("httpport", httpport)) core->logFatal("httpport not set in settings file");
    
    std::string serverurl = "http://0.0.0.0:" + httpport;
    
    core->logInfo("initialising http server on port " + httpport);
    
    struct mg_mgr mgr;
    mg_mgr_init(&mgr);
    mg_log_set(MG_LL_DEBUG);  // Set debug log level
    mg_http_listen(&mgr, serverurl.c_str(), fn, NULL);  // Create listener

    if(local){
        std::string url = "http://localhost:" + httpport;
        bool failed = true;
        if(!system("which gnome-open > /dev/null 2>&1")){
            std::string cmd = "gnome-open " + url;
            if(!system(cmd.c_str())) failed = false;
        }else if(!system("which xdg-open > /dev/null 2>&1")){
            std::string cmd = "xdg-open " + url;
            if(!system(cmd.c_str())) failed = false;
        }else if(!system("which gio > /dev/null 2>&1")){
            std::string cmd = "gio " + url;
            if(!system(cmd.c_str())) failed = false;
        }else if(!system("which open > /dev/null 2>&1")){
            std::string cmd = "open " + url;
            if(!system(cmd.c_str())) failed = false;
        }

        if(failed){
            core->logInfo("please open a browser at " + url);
        }
    }

    for (;;) mg_mgr_poll(&mgr, 10);  // Event loop. Use 10ms poll interval
    mg_mgr_free(&mgr);               // Cleanup
    
    return 0;
    }

#ifndef HANDLER
#define HANDLER

#include <pthread.h>
#include <string>
#include <iostream>
#include <unordered_map>
#include <mutex>  

extern "C" {
    #include "mongoose.h"
}

#include "json.hpp"
#include "nice.hpp"
#include "core.hpp"
#include "filesystem.hpp"
#include "star.hpp"
#include "imager.hpp"
#include "simple_stream.hpp"

class Handler {
	
	private:
		Core* core;
	public:
		Handler(Core* core);
		std::string handle(nlohmann::json* requestjson);
		void handlestream(struct thread_data* d, nlohmann::json* requestjson);
		bool SelectProject(int projectid, std::string username);
		bool SelectWorkspace(int projectid, int workspaceid, std::string username);
		bool getProject(int projectid, std::string username, std::string userlevel, std::vector<std::map<std::string, std::string>>* returnvals);
		bool updateModified(int workspaceid, int projectid);
		nlohmann::ordered_json RecentProjects  (nlohmann::json* requestjson);
		nlohmann::ordered_json ListWorkspaces  (nlohmann::json* requestjson);
		nlohmann::ordered_json ListProjects    (nlohmann::json* requestjson);
		nlohmann::ordered_json CreateWorkspace (nlohmann::json* requestjson);
		nlohmann::ordered_json UpdateWorkspace (nlohmann::json* requestjson);
		nlohmann::ordered_json CreateProject   (nlohmann::json* requestjson);
		nlohmann::ordered_json ActiveWorkspace (nlohmann::json* requestjson);
		nlohmann::ordered_json ActiveProject   (nlohmann::json* requestjson);
		nlohmann::ordered_json ListJobs  	   (nlohmann::json* requestjson);
		nlohmann::ordered_json RenameJob  	   (nlohmann::json* requestjson);
		nlohmann::ordered_json CleanupJob  	   (nlohmann::json* requestjson);
		nlohmann::ordered_json DeleteJob  	   (nlohmann::json* requestjson);
		nlohmann::ordered_json MinimiseJob     (nlohmann::json* requestjson);
		nlohmann::ordered_json MaximiseJob	   (nlohmann::json* requestjson);
		nlohmann::ordered_json GetJobs		   (nlohmann::json* requestjson);
		nlohmann::ordered_json GetJobOptions   (nlohmann::json* requestjson);
		nlohmann::ordered_json CreateJob       (nlohmann::json* requestjson);
		nlohmann::ordered_json CreateInteractiveJob       (nlohmann::json* requestjson);
		nlohmann::ordered_json GetFolderContents      (nlohmann::json* requestjson);
		nlohmann::ordered_json StopJob         (nlohmann::json* requestjson);
		nlohmann::ordered_json ViewJob         (nlohmann::json* requestjson);
		nlohmann::ordered_json GetLog          (nlohmann::json* requestjson);
		nlohmann::ordered_json SaveSelection   (nlohmann::json* requestjson);
		nlohmann::ordered_json SaveOnlineSelection   (nlohmann::json* requestjson);
		nlohmann::ordered_json SaveBoxes       (nlohmann::json* requestjson);
		nlohmann::ordered_json SavePick        (nlohmann::json* requestjson);
		nlohmann::ordered_json CRYOSPARC_link  (nlohmann::json* requestjson);
		nlohmann::ordered_json GetAdditionalBoxes  (nlohmann::json* requestjson);
		nlohmann::ordered_json SimpleStreamControl (nlohmann::json* requestjson);
		void GetMics            (struct thread_data* d, nlohmann::json* requestjson);
		void GetCls2D           (struct thread_data* d, nlohmann::json* requestjson);
		void GetOptics          (struct thread_data* d, nlohmann::json* requestjson);
		void GetImages          (struct thread_data* d, nlohmann::json* requestjson);
		void CreateNicePicker   (struct thread_data* d, nlohmann::json* requestjson);
		void ShowNicePicker     (struct thread_data* d, nlohmann::json* requestjson);
		void CreateSimpleStream (struct thread_data* d, nlohmann::json* requestjson);
		void ShowSimpleStream   (struct thread_data* d, nlohmann::json* requestjson);
		void GetThumbnail       (struct thread_data* d, nlohmann::json* requestjson);
};

#endif

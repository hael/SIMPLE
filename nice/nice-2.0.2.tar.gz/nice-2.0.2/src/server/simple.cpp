#include "core.hpp"
#include "star.hpp"

bool Core::SIMPLE_test(){
	
	std::string simplepath;
	
	if(!this->getConfigValue ("simplepath", simplepath)){
		this->logError("failed to retrieve simplepath from config. SIMPLE disabled");
		return false;
	}

	if(!folderExists(simplepath)){
		this->logError("simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string simpleclusterpath;
	
	if(!this->getConfigValue ("simpleclusterpath", simpleclusterpath)){
		this->logError("failed to retrieve simpleclusterpath from config. SIMPLE disabled");
		return false;
	}

	if(simpleclusterpath[0] == '/'){
		if(!folderExists(simpleclusterpath)){
			this->logError("simpleclusterpath does not exist. SIMPLE disabled");
			return false;
		}
	}else{
		if(!folderExists(this->bindir + "/" + simpleclusterpath)){
			this->logError("simpleclusterpath does not exist. SIMPLE disabled");
			return false;
		}
	}
	
	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->logError("bin folder in simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string jobcommand = "SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=list";
	
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");

 	if (cmdpipe == nullptr) {
        this->logError("popen failed. SIMPLE disabled");
		return false;
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));

	if(exitcode == 0){
		this->logInfo("SIMPLE enabled");
		return true;
	}else{
		this->logError("failed to execute test command. SIMPLE disabled");
		return false;
	}

}

bool Core::SIMPLE_getJobs(nlohmann::ordered_json* joblist){

	std::string simplepath;
	
	if(!this->getConfigValue ("simplepath", simplepath)){
		this->logError("failed to retrieve simplepath from config. SIMPLE disabled");
		return false;
	}

	if(!folderExists(simplepath)){
		this->logError("simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->logError("bin folder in simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string jobcommand = "SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_private_exec prg=print_ui_json";
	
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");

 	if (cmdpipe == nullptr) {
        this->logError("popen failed. SIMPLE disabled");
		return false;
    }

	char buffer[1028];
    std::string ui_json;
    
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));

	if(exitcode != 0){
		this->logError("failed to generate json ui");
		return false;
	}

	// Remove Execution line
	ui_json.resize(ui_json.find_last_of("****") - 3);

	nlohmann::ordered_json ui = nlohmann::ordered_json::parse(ui_json);
	nlohmann::ordered_json simplejoblist;

	for (auto it : ui){
		nlohmann::ordered_json jobjson = it;
		// store job info
		nlohmann::ordered_json joblistelement;

		if(!jobjson.contains("program") || !jobjson["program"].is_object()){
			continue;
		}

		if(jobjson["program"].contains("name") && jobjson["program"]["name"].is_string()){
			joblistelement["name"] = jobjson["program"]["name"];
		}else{
			continue;
		}
		
		if(jobjson["program"].contains("descr_long") && jobjson["program"]["descr_long"].is_string()){
			joblistelement["descr_long"] = jobjson["program"]["descr_long"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("descr_short") && jobjson["program"]["descr_short"].is_string()){
			joblistelement["descr_short"] = jobjson["program"]["descr_short"];
		}else{
			continue;
		}
		if(jobjson["program"].contains("advanced") && jobjson["program"]["advanced"].is_boolean()){
			joblistelement["advanced"] = jobjson["program"]["advanced"];
		}else{
			continue;
		}

		joblistelement["module"] = "SIMPLE";

		simplejoblist.push_back(joblistelement);
		
	}

	joblist->emplace("jobs", "");
	joblist->at("jobs") = simplejoblist;

	return true;
}

bool Core::SIMPLE_getJobOptions(std::string jobname, nlohmann::ordered_json* joboptions){

	std::string simplepath;
	
	if(!this->getConfigValue ("simplepath", simplepath)){
		this->logError("failed to retrieve simplepath from config. SIMPLE disabled");
		return false;
	}

	if(!folderExists(simplepath)){
		this->logError("simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->logError("bin folder in simplepath does not exist. SIMPLE disabled");
		return false;
	}

	std::string jobcommand = "SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_private_exec prg=print_ui_json";
	
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");

 	if (cmdpipe == nullptr) {
        this->logError("popen failed. SIMPLE disabled");
		return false;
    }

	char buffer[1028];
    std::string ui_json;
    
    while (!feof(cmdpipe)) {
    	if (fgets(buffer, sizeof(buffer), cmdpipe) != NULL) ui_json += buffer;
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));

	if(exitcode != 0){
		this->logError("failed to generate json ui");
		return false;
	}

	// Remove Execution line
	ui_json.resize(ui_json.find_last_of("****") - 3);

	nlohmann::ordered_json ui = nlohmann::ordered_json::parse(ui_json);

	if(!ui.contains(jobname) || !ui[jobname].is_object()){
		this->logError("program missing from UI");
		return false;
	}

	if(!ui[jobname].contains("program") || !ui[jobname]["program"].is_object()){
		this->logError("program field missing from UI");
		return false;
	}

	if(!ui[jobname]["program"].contains("executable") || !ui[jobname]["program"]["executable"].is_string()){
		this->logError("executable field missing from UI");
		return false;
	}

	nlohmann::ordered_json options;

	for (auto it = ui[jobname].begin(); it != ui[jobname].end(); ++it) {
		nlohmann::ordered_json jobjson = *it;

		if(it.key() != "program"){
			for (auto it2 = jobjson.begin(); it2 != jobjson.end(); ++it2) {
				
				nlohmann::ordered_json sectionjson = *it2;
				std::string guisubmenu = it.key();

				if(sectionjson.contains("gui_submenu") && sectionjson["gui_submenu"].is_string() ){
					guisubmenu = sectionjson["gui_submenu"].get<std::string>();
				}

				if(!options.contains(guisubmenu)){
					options[guisubmenu] = {};
				}
			
				options[guisubmenu] += sectionjson;
			}

		}
	}

	nlohmann::ordered_json clusters;

	clusters["key"] = "nicecluster";
	clusters["keytype"] = "multi";
	clusters["descr_short"] = "cluster";
	clusters["descr_long"] = "cluster to submit processes to";
	clusters["descr_placeholder"] = "";
	clusters["required"] = true;
	clusters["advanced"] = false;
	clusters["online"] = false;
	clusters["options"] = {};

	nlohmann::ordered_json clusterlist;

	this->SIMPLE_getClusters(&clusterlist);

	if(clusterlist.contains("clusters") && clusterlist["clusters"].is_array() && clusterlist["clusters"].size() > 0){
		for(auto cluster : clusterlist["clusters"]){
			if(cluster.contains("name") && cluster["name"].is_string()
			&& cluster.contains("template") && cluster["template"].is_string()){
				clusters["options"] += cluster["name"].get<std::string>();
			}
		}
		clusters["default"] = clusters["options"][0];
	}
	
	if(options.contains("compute")){
		options["compute"] += clusters;
	}else if (options.contains("computer controls")){
		options["computer controls"] += clusters;
	}else{
		options["compute"] += clusters;
	}

	tinyxml2::XMLElement* simplesitedefaults = this->xmldoc.FirstChildElement( "simplesitedefaults" );
    
    if(simplesitedefaults){
        tinyxml2::XMLElement* jobdefaults = simplesitedefaults->FirstChildElement(jobname.c_str());
        if (jobdefaults) {
            tinyxml2::XMLElement* defaultparam = jobdefaults->FirstChildElement();
            while (defaultparam) {
                std::string key = std::string(defaultparam->Name());
                std::string val = std::string(defaultparam->GetText());
              	for(auto submenu : options.items()){
              		if(options[submenu.key()].is_array()){
              			for(int i = 0; i < options[submenu.key()].size(); i++){
              				if(options[submenu.key()][i].is_object() && options[submenu.key()][i].contains("key") && options[submenu.key()][i]["key"].get<std::string>() == key){
              					options[submenu.key()][i]["default"] = val;
              					break;
              				}
              			}
              		}
              	}
                defaultparam = defaultparam->NextSiblingElement();
            }  
        }
    }

	std::string executable = ui[jobname]["program"]["executable"].get<std::string>();

	joboptions->emplace("executable", executable);

	joboptions->emplace("options", "");
	joboptions->at("options") = options;
		
	return true;
}

bool Core::SIMPLE_workspaceInit(std::string path){
	
	std::string simplepath;
	
	if(!this->getConfigValue ("simplepath", simplepath)){
		this->logError("SIMPLE_workspaceInit. failed to retrieve simplepath from config");
		return false;
	}

	if(!folderExists(simplepath)){
		this->logError("SIMPLE_workspaceInit. simplepath does not exist");
		return false;
	}

	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->logError("SIMPLE_workspaceInit. bin folder in simplepath does not exist");
		return false;
	}

	std::string jobcommand = "cd " + path + " && SIMPLE_PATH=" + simplepath + " SIMPLE_QSYS=local " + simplepathbin + "simple_exec prg=new_project dir=" + path;
	
	FILE* cmdpipe = popen(jobcommand.c_str(), "r");

 	if (cmdpipe == nullptr) {
        this->logError("SIMPLE_workspaceInit. popen failed");
		return false;
    }

	int exitcode = WEXITSTATUS(pclose(cmdpipe));

	if(exitcode != 0){
		this->logError("SIMPLE_workspaceInit. failed to execute command");
		return false;
	}
	
	std::string source = path + "/" + basename(path) + ".simple";
	std::string destination = path + "/workspace.simple";
	
	if(!moveFolder(source, destination)){
		this->logError("SIMPLE_workspaceInit. failed to rename project file");
		return false;
	}

	this->logInfo("SIMPLE workspace initiated");
	return true;
}

void Core::SIMPLE_cleanup(std::string version){
	
	
}

bool Core::SIMPLE_jobInit(std::string version, std::string type, std::string jobfolder, std::string clustertemplate, nlohmann::ordered_json jobargs, std::string parentsubfolder){

	std::string filledtemplate;
	std::string scriptfile = jobfolder + "/nice.script";

	if(!this->SIMPLE_fillTemplate(clustertemplate, type, jobargs, jobfolder, parentsubfolder, &filledtemplate)){
		this->logError("SIMPLE_jobInit: failed to substitute template");
		return false;
	}

	std::ofstream scriptfilehandle(scriptfile);
	scriptfilehandle << filledtemplate << std::endl;
	scriptfilehandle.close();

	chmod(scriptfile.c_str(), S_IRWXU);

	return true;
}

bool Core::SIMPLE_fillTemplate(std::string clustertemplate, std::string prg, nlohmann::ordered_json jobargs, std::string jobfolder, std::string parentsubfolder, std::string* returnstring){

	std::string simplepath;
	
	if(!this->getConfigValue ("simplepath", simplepath)){
		this->logError("failed to retrieve simplepath from config");
		return false;
	}

	if(!folderExists(simplepath)){
		this->logError("simplepath does not exist");
		return false;
	}

	std::string simplepathbin = simplepath + "/bin/";

	if(!folderExists(simplepathbin)){
		this->logError("bin folder in simplepath does not exist");
		return false;
	}

	if(!jobargs.is_object()){
		this->logError("SIMPLE_fillTemplate: arguments is not an object");
		return false;
	}

	std::string commandstring;

	commandstring += '\n';
	commandstring += "export SIMPLE_PATH=" + simplepath;
	commandstring += '\n';

	if(parentsubfolder.length() > 0){
		if(fileExists(jobfolder + "/../" + parentsubfolder + "/workspace.simple")){
			commandstring += "cp ../" + parentsubfolder + "/workspace.simple .";
		}else{
			commandstring += simplepathbin + "simple_exec prg=import_starproject import_dir=`pwd`/../" + parentsubfolder + " projfile=../workspace.simple mkdir=no > nice.log 2> nice.error";
		}
	}else{
		commandstring += "cp ../workspace.simple .";
	}

	commandstring += '\n';

	if(jobargs.contains("niceselection")){

		if(!jobargs["niceselection"].is_string()){
			this->logError("SIMPLE_fillTemplate: niceselection is not a string");
			return false;
		}

		std::string niceselection = jobargs["niceselection"].get<std::string>();

		if(!fileExists(niceselection)){
			this->logError("SIMPLE_fillTemplate: niceselection does not exist");
			return false;
		}

		commandstring += "mv " + niceselection + " nice_selection.txt";
		commandstring += '\n';

	}

	std::string executable;
	
	if(!jobargs.contains("niceexec")){
		this->logError("SIMPLE_fillTemplate: niceexec missing from job arguments");
		return false;
	}

	if(!jobargs["niceexec"].is_string()){
		this->logError("SIMPLE_fillTemplate: niceexec is not a string");
		return false;
	}

	executable = jobargs["niceexec"].get<std::string>();

	std::string argstring;

	for (auto it = jobargs.begin(); it != jobargs.end(); ++it){
		
		std::string key = it.key();
		std::string value = it.value();
		
		if(key != "nicecluster" && key != "niceexec" && key != "niceselection" && value != ""){
			argstring += " " + key + "=" + value;
		}
	}

	commandstring += '{';
	commandstring += '\n';
	commandstring += simplepathbin + "simple_exec prg=update_project projfile=workspace.simple";
	commandstring += " && ";
	commandstring += simplepathbin + executable + " prg=" + prg + " mkdir=no" + argstring;
	commandstring += " && ";

	if(jobargs.contains("niceselection") && jobargs.contains("oritype") && jobargs["oritype"].get<std::string>() == "cls2D"){
		commandstring += simplepathbin + "simple_private_exec prg=export_cavgs projfile=workspace.simple outstk=selected_clusters.mrc";
		commandstring += " && ";
	}

	commandstring += simplepathbin + "simple_exec prg=export_starproject mkdir=no projfile=workspace.simple";
	commandstring += '\n';
	commandstring += "} >> nice.log 2>> nice.error";
	commandstring += '\n';
	commandstring += "echo $? > nice.exit";

	std::ifstream clusterfile(clustertemplate);

	if(!clusterfile){
		this->logError("SIMPLE_fillTemplate: failed to open template");
		return false;
	}

 	std::ostringstream clusterfiless;
    
    clusterfiless << clusterfile.rdbuf();

    std::string templatestring = clusterfiless.str();
	
	clusterfile.close();

	std::string replacestring = "XXXNICEXXX";

	templatestring.replace(templatestring.find(replacestring), replacestring.size(), commandstring);

	returnstring->assign(templatestring);

	return true;
	
}

void Core::SIMPLE_getClusters(nlohmann::ordered_json* clusterlist){

	std::string simpleclusterpath;
	
	if(!this->getConfigValue ("simpleclusterpath", simpleclusterpath)){
		this->logError("SIMPLE_getClusters: failed to retrieve simpleclusterpath from config");
		return;
	}
	std::vector<std::string> clusters;

	if(simpleclusterpath[0] == '/'){
		if(!folderExists(simpleclusterpath)){
			this->logError("SIMPLE_getClusters: simpleclusterpath does not exist");
			return;
		}
		clusters = findFiles(simpleclusterpath, std::regex(".*cluster"));

	}else{
		if(!folderExists(this->bindir + "/" + simpleclusterpath)){
			this->logError("SIMPLE_getClusters: simpleclusterpath does not exist. SIMPLE disabled");
			return ;
		}
		clusters = findFiles(this->bindir + "/" + simpleclusterpath, std::regex(".*cluster"));
	}

	nlohmann::ordered_json clustersjson;
	clustersjson = {};

	std::string clusternamecomment   = "#NICE clustername";
	std::string submitcommandcomment = "#NICE submitcommand";
	std::string cancelcommandcomment = "#NICE cancelcommand";
	std::string statuscommandcomment = "#NICE statuscommand";
	std::string defaultcomment 	     = "#NICE defaultcluster";
	std::string replacestring 	     = "XXXNICEXXX";

	for(auto cluster : clusters){
		std::string buffer;
		bool defaultcluster = false;
		bool replacepresent = false;
		nlohmann::ordered_json clusterjson;
		
		clusterjson["template"] = cluster;

		std::ifstream clusterfile(cluster);

		while (getline (clusterfile, buffer)) {

			if(buffer.find(clusternamecomment) != std::string::npos){
				clusterjson["name"] = buffer.substr(buffer.find(clusternamecomment) + clusternamecomment.size() + 1);
			}else if(buffer.find(submitcommandcomment) != std::string::npos){
				clusterjson["submitcommand"] = buffer.substr(buffer.find(submitcommandcomment) + submitcommandcomment.size() + 1);
			}else if(buffer.find(cancelcommandcomment) != std::string::npos){
				clusterjson["cancelcommand"] = buffer.substr(buffer.find(cancelcommandcomment) + cancelcommandcomment.size() + 1);
			}else if(buffer.find(statuscommandcomment) != std::string::npos){
				clusterjson["statuscommand"] = buffer.substr(buffer.find(statuscommandcomment) + statuscommandcomment.size() + 1);
			}else if(buffer.find(defaultcomment) != std::string::npos){
				defaultcluster = true;
			}else if(buffer.find(replacestring) != std::string::npos){
				replacepresent = true;
			}
		}

		clusterfile.close();

		if(!replacepresent){
			this->logError("SIMPLE_getClusters: " + replacestring + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("name") && !clusterjson["name"].is_string()){
			this->logError("SIMPLE_getClusters: " + clusternamecomment + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("submitcommand") && !clusterjson["submitcommand"].is_string()){
			this->logError("SIMPLE_getClusters: " + submitcommandcomment + " missing from cluster " + cluster );
			continue;
		}
		
		if(!clusterjson.contains("cancelcommand") && !clusterjson["cancelcommand"].is_string()){
			this->logError("SIMPLE_getClusters: " + cancelcommandcomment + " missing from cluster " + cluster );
			continue;
		}

		if(!clusterjson.contains("statuscommand") && !clusterjson["statuscommand"].is_string()){
			this->logError("SIMPLE_getClusters: " + statuscommandcomment + " missing from cluster " + cluster );
			continue;
		}

		if(defaultcluster){
			clustersjson.insert(clustersjson.begin(), clusterjson);
		}else{
			clustersjson += clusterjson;
		}
	
	}

	clusterlist->emplace("clusters", "");
	clusterlist->at("clusters") = clustersjson;

}

void Core::SIMPLE_jobStop(std::string version, std::string type, std::string jobfolder, std::string cancelcommand, std::string statuscommand, std::time_t starttime){
	
	if(fileExists(jobfolder + "/nice.pid")){

		std::string buffer;
		std::ifstream pidfile(jobfolder + "/nice.pid");
		getline (pidfile, buffer);
		pidfile.close();
			
		if(buffer == "") return;

		int pid = std::stoi(buffer);

		this->statusAddCommand(statuscommand); // confirm command is in array after restart

		if(this->statusTest(statuscommand, pid, starttime)){
			this->logInfo("SIMPLE_jobStop : SIMPLE job running");
		}else{
			this->logError("SIMPLE_jobStop : SIMPLE job already dead");
			if(!fileExists(jobfolder + "/nice.exit")){
				std::ofstream exitfilehandle(jobfolder + "/nice.exit");
				exitfilehandle << 1 << std::endl;
				exitfilehandle.close();
			}
			return;
		}

		if (type.find("stream") != std::string::npos) {
			if(folderExists(jobfolder)){
				std::ofstream termhandle(jobfolder + "/SIMPLE_TERM_STREAM");
				termhandle.close();
			}
		}else{

			std::string killcommand = cancelcommand + " " + std::to_string(pid);

			FILE* killcmd = popen(killcommand.c_str(), "r");

			int killexitcode = WEXITSTATUS(pclose(killcmd));

			if(killexitcode == 0){
				this->logInfo("SIMPLE_jobStop : SIMPLE job killed");
				std::ofstream exitfilehandle(jobfolder + "/nice.exit");
				exitfilehandle << 1 << std::endl;
				exitfilehandle.close();
			}else{
				this->logError("SIMPLE_jobStop : failed to kill SIMPLE job");
			}
		}
	}

}

void Core::SIMPLE_images(std::string version, std::string type, nlohmann::ordered_json* returnjson){

	nlohmann::ordered_json images;
	images = {};

	if(returnjson->contains("nmics") /*&& (type == "preprocess_stream" || type == "preprocess_stream_dev")*/){
		
		nlohmann::ordered_json imagejson;
		
		imagejson["key"] = "_rlnMicrographName";
		imagejson["visible"] = true;
		images += imagejson;

		imagejson["key"] = "_rlnCtfPowerSpectrum";
		imagejson["visible"] = true;
		images += imagejson;

		imagejson["key"] = "_rlnMicrographCoordinates";
		imagejson["visible"] = true;
		images += imagejson;

		returnjson->at("keys").emplace("_splSpecPrePost", "string");
		imagejson["key"] = "_splSpecPrePost";
		imagejson["visible"] = false;
		images += imagejson;

		imagejson["key"] = "_rlnReferenceImage";
		imagejson["visible"] = true;
		images += imagejson;

	}else if(returnjson->contains("ncls")){
		
		nlohmann::ordered_json imagejson;
		
		imagejson["key"] = "_rlnReferenceImage";
		imagejson["visible"] = true;
		images += imagejson;

	}

	returnjson->at("images") = images;

}

void Core::SIMPLE_paths(std::string version, std::string type, std::string key, nlohmann::ordered_json stringpath, nlohmann::ordered_json* datajson){
	
	std::string intgsuffix  = "_intg.mrc";
	std::string thumbsuffix = "_thumb.jpg";
	
	if(type == "preprocess_stream" || type == "preprocess_stream_dev"){
		
		if(key == "_rlnMicrographName"){

			std::string filename = stringpath["arr"][1];

			filename.replace(filename.find(intgsuffix), intgsuffix.size(), thumbsuffix);

			stringpath["arr"][1] = filename;
			stringpath["arr"][2] = 0;
			stringpath["arr"][3] = 1;
			stringpath["arr"][4] = 2;

			if(!datajson->contains("_rlnMicrographName")){
				datajson->emplace("_rlnMicrographName", nlohmann::json::array());
			} 

			datajson->at("_rlnMicrographName") += stringpath["arr"];


			if(!datajson->contains("_splSpecPrePost")){
				datajson->emplace("_splSpecPrePost", nlohmann::json::array());
			} 

			stringpath["arr"][3] = 0;

			datajson->at("_splSpecPrePost") += stringpath["arr"];

		}else{
			if(!datajson->contains(key)){
				datajson->emplace(key, nlohmann::json::array());
			}
			datajson->at(key) += stringpath["arr"];
		}

	}else{
		if(!datajson->contains(key)){
			datajson->emplace(key, nlohmann::json::array());
		}
		datajson->at(key) += stringpath["arr"];
	}

}

int Core::SIMPLE_micsptcls(std::string version, nlohmann::ordered_json* micsstar){
	
	int returnval = 0;

	if(micsstar->contains("data_micrographs") && micsstar->at("data_micrographs").is_object()
    && micsstar->at("data_micrographs").contains("loop") && micsstar->at("data_micrographs")["loop"].is_array()
    && micsstar->at("data_micrographs")["loop"].size() > 0 && micsstar->at("data_micrographs")["loop"][0].contains("_splNumberParticles")){

		for(auto mic : micsstar->at("data_micrographs")["loop"]){
			int numptcls = std::stoi(mic["_splNumberParticles"].get<std::string>());
			returnval += numptcls;
		}

	}

	return returnval;
}

int Core::SIMPLE_cls2Dptcls(std::string version, nlohmann::ordered_json* cls2Dstar){
	
	int returnval = 0;

	if(cls2Dstar->contains("data_clusters") && cls2Dstar->at("data_clusters").is_object()
    && cls2Dstar->at("data_clusters").contains("loop") && cls2Dstar->at("data_clusters")["loop"].is_array()
    && cls2Dstar->at("data_clusters")["loop"].size() > 0 && cls2Dstar->at("data_clusters")["loop"][0].contains("_rlnClassDistribution")){

		for(auto mic : cls2Dstar->at("data_clusters")["loop"]){
			int numptcls = std::stoi(mic["_rlnClassDistribution"].get<std::string>());
			returnval += numptcls;
		}

	}

	return returnval;
}

int Core::SIMPLE_cls2Dclsall(std::string version, nlohmann::ordered_json* cls2Dstar){
	
	int returnval = 0;

	if(cls2Dstar->contains("data_clusters") && cls2Dstar->at("data_clusters").is_object()
    && cls2Dstar->at("data_clusters").contains("loop") && cls2Dstar->at("data_clusters")["loop"].is_array()
    && cls2Dstar->at("data_clusters")["loop"].size() > 0 && cls2Dstar->at("data_clusters")["loop"][0].contains("_splNClasses")){

		returnval = std::stoi(cls2Dstar->at("data_clusters")["loop"][0]["_splNClasses"].get<std::string>());

	}

	return returnval;
}

int Core::SIMPLE_micsall(std::string version, nlohmann::ordered_json* micsstar){
	
	int returnval = 0;

	if(micsstar->contains("data_micrographs") && micsstar->at("data_micrographs").is_object()
    && micsstar->at("data_micrographs").contains("loop") && micsstar->at("data_micrographs")["loop"].is_array()
    && micsstar->at("data_micrographs")["loop"].size() > 0 && micsstar->at("data_micrographs")["loop"][0].contains("_splNMics")){

		returnval = std::stoi(micsstar->at("data_micrographs")["loop"][0]["_splNMics"].get<std::string>());

	}

	return returnval;
}

bool Core::SIMPLE_suggestChild(std::string version, std::string jobtype, std::vector<std::map<std::string, std::string>> parent, std::string* suggestedjobtype, std::string* suggestedjobname){

	if(jobtype == "selection"){
		if(parent[0].find("suggested") != parent[0].end()){
			suggestedjobtype->assign("'" + parent[0]["suggested"] + "'");
		}else{
			return false;
		}
		if(parent[0].find("suggestedname") != parent[0].end()){
			suggestedjobname->assign("'" + parent[0]["suggestedname"] + "'");
		}else{
			return false;
		}
		return true;
	}else if(jobtype == "preprocess_stream"){
		suggestedjobtype->assign("'cluster2D'");
		suggestedjobname->assign("'2D'");
		return true;
	}else if(jobtype == "preprocess_stream_dev"){
		suggestedjobtype->assign("'cluster2D'");
		suggestedjobname->assign("'2D'");
		return true;
	}else if(jobtype == "import_movies"){
		suggestedjobtype->assign("'motion_correct'");
		suggestedjobname->assign("'MC'");
		return true;
	}else if(jobtype == "motion_correct"){
		suggestedjobtype->assign("'ctf_estimate'");
		suggestedjobname->assign("'CTF'");
		return true;
	}



	// need to work on this

	return false;

}

bool Core::SIMPLE_stopStatus(std::string version, std::string jobtype, std::string* stopstatus){

	if(jobtype == "preprocess_stream"){
		stopstatus->assign("finished");
		return true;
	}else if(jobtype == "preprocess_stream_dev"){
		stopstatus->assign("finished");
		return true;
	}

	return false;

}

bool Core::SIMPLE_selectionInit(nlohmann::json* requestjson){
	
	srand (time(NULL)); // add some entropy
	
	std::string starfile = requestjson->at("starfile").get<std::string>();

	if(starfile == "") return false;

	std::string selectionfile = parentPath(starfile) +"/nice.selection." + std::to_string(rand() % 1000);

	nlohmann::json arguments = {};

	arguments["infile"] = "nice_selection.txt";
	arguments["nicecluster"]   = "default";
	arguments["niceselection"] = selectionfile;

	if(requestjson->at("datatype").get<std::string>() == "cls2D"){

		arguments["oritype"] = "cls2D"; 

		std::ofstream selectionfilehandle(selectionfile);

		int nall = requestjson->at("nall").get<int>();

		std::vector<int> selection(nall, 0);

		for (int i = 0; i < requestjson->at("selection").size(); i++){
			if(requestjson->at("selection")[i].get<int>() > 1){
				selection[requestjson->at("selectionmap")[i].get<int>()] = 1;
			}else{
				selection[requestjson->at("selectionmap")[i].get<int>()] = 0;
			}
		}

		for(auto sel : selection){
			selectionfilehandle << sel << std::endl;
		}

		selectionfilehandle.close();

	}else if(requestjson->at("datatype").get<std::string>() == "mics"){
		
		arguments["oritype"] = "mic";
		
		std::ofstream selectionfilehandle(selectionfile);

		int nall = requestjson->at("nall").get<int>();

		std::vector<int> selection(nall, 0);

		for (int i = 0; i < requestjson->at("selection").size(); i++){
			if(requestjson->at("selection")[i].get<int>() > 1){
				selection[requestjson->at("selectionmap")[i].get<int>()] = 1;
			}else{
				selection[requestjson->at("selectionmap")[i].get<int>()] = 0;
			}
		}

		for(auto sel : selection){
			selectionfilehandle << sel << std::endl;
		}

		selectionfilehandle.close();
	}
	requestjson->emplace("type", "selection");
	requestjson->emplace("jobname", "");
	requestjson->emplace("executable","simple_exec");
	requestjson->emplace("arguments", arguments);

	return true;

}

bool Core::SIMPLE_onlineSelection(nlohmann::json* requestjson){
	
	srand (time(NULL)); // add some entropy
	
	std::string starfile = requestjson->at("starfile").get<std::string>();

	if(starfile == "") return false;
	
	std::string rejectionfile = parentPath(starfile) + "/SIMPLE_REJECT_CLS";

	std::ofstream rejectionfilehandle(rejectionfile);

	for (int i = 0; i < requestjson->at("selection").size(); i++){
		if(requestjson->at("selection")[i] < 2){
			rejectionfilehandle << "class=" << i + 1 << std::endl;
		}
	}

	rejectionfilehandle.close();

	return true;

}

bool Core::SIMPLE_progress(std::string jobfolder, int* progress){
	
	if(fileExists(jobfolder + "/.progress")){
		nlohmann::ordered_json newprogress = readHeaderlessSTAR(jobfolder + "/.progress");
		if(newprogress.contains("data") && newprogress["data"].is_array() && newprogress["data"].size() == 1 && newprogress["data"][0].size() == 1){

			float newprogressflt = std::stof(newprogress["data"][0][0].get<std::string>());
			*progress = std::ceil(newprogressflt * 100);
			return true;
		}

	}
	return false;

}
bool Core::SIMPLE_stats(std::string jobfolder, nlohmann::ordered_json* stats){

	bool returnval = true;

	if(fileExists(jobfolder + "/.guistats.json")){
		std::ifstream statsfile(jobfolder + "/.guistats.json");
		nlohmann::ordered_json statsjson = nlohmann::ordered_json::parse(statsfile);
		statsfile.close();
		if(statsjson.is_object()){
			stats->clear();
			stats->emplace("sections", nlohmann::ordered_json::object());
			stats->at("sections") = statsjson;
		}
	}
	std::cout << "STATS " << jobfolder << " " << stats->dump(2) << std::endl;

	return returnval;
}

#ifndef BOX_H
#define BOX_H

#include <string>
#include <iomanip>  
#include <json_helpers.h>

static std::vector<std::string> line2Array(std::string line, char delimiter){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == delimiter){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != delimiter){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static std::vector<std::string> line2Array(std::string line){
	
	std::vector<std::string> returnarray;
	int startit = 0;
	int endit = 0;
	
	for(startit = 0; startit < line.size(); startit++){
		if(line[startit] != ' '){
			break;
		}
	}
	
	for(endit = startit; endit < line.size(); endit++){
		if(line[endit] == ' '){
			if(line[startit] != '#' && line[startit] != ' ' && endit > startit){
				returnarray.push_back(line.substr(startit, endit - startit));
			}
			for(startit = endit; startit < line.size(); startit++){
				if(line[startit] != ' '){
					endit = startit;
					break;
				}
			}
		}
	}
	
	if(startit < endit){
		if(line[startit] != '#' && line[startit] != ' '){
			returnarray.push_back(line.substr(startit, endit - startit));
		}
	}
	
	return returnarray;
}

static nlohmann::ordered_json readBoxFile(std::string filename, int max_fields=0){

	nlohmann::ordered_json data;
	data["boxes"] = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;

	while(std::getline(buf, line)){
		
		std::vector<std::string> linearray;
		linearray = line2Array(line);
		nlohmann::ordered_json linejson = {};
		
		if(linearray.size() > 0){
			if(max_fields < 1){
				for(int i = 0; i < linearray.size(); i++){
					linejson += linearray[i];
				}
			}else{
				for(int i = 0; i < max_fields; i++){
					linejson += linearray[i];
				}
			}

		}
		data["boxes"] += linejson;
	}

	return data;

}

static nlohmann::ordered_json readBoxFileInt(std::string filename, int* fields, int fields_len){

	nlohmann::ordered_json data;
	data["boxes"] = {};
	
	std::stringstream buf; 
	std::ifstream input (filename.c_str()); 
	buf << input.rdbuf(); 
	
	std::string line;

	while(std::getline(buf, line)){
		
		std::vector<std::string> linearray;
		linearray = line2Array(line);
		nlohmann::ordered_json linejson = {};
		
		if(linearray.size() > 0){
			for(int i = 0; i < fields_len; i++){
				int field_idx = fields[i];
				if(field_idx < linearray.size()){
					linejson += std::floor(std::stof(linearray[field_idx]));
				}
			}
		}
		data["boxes"] += linejson;
	}

	return data;

}

inline static nlohmann::ordered_json SaveBoxes(nlohmann::ordered_json args){
	nlohmann::ordered_json returnjson;
	returnjson["success"] = false;

	if(json_test_string(args, "boxfile") && json_test_int(args, "boxsize") && json_test_array(args, "coordinates")){
		std::string boxfile = args["boxfile"].get<std::string>();
		int boxsize = args["boxsize"].get<int>();
		int halfboxsize = boxsize / 2;
		std::string parent = parentPath(boxfile);
		if(folderExists(parent)){
			std::ofstream output (boxfile.c_str(), std::ofstream::out|std::ofstream::trunc);
			if(output.is_open()){
				for(auto coord : args["coordinates"]){
					output << std::setw(7); 
					output << coord["x"].get<int>() - halfboxsize;
					output << std::setw(7); 
					output << coord["y"].get<int>() - halfboxsize;
					output << std::setw(7); 
					output << boxsize;
					output << std::setw(7); 
					output << boxsize;
					output << std::setw(7); 
					output << -3;
					output << std::endl;
				}
				output.close();
			}
		}

	}

	
	return returnjson;
}

#endif